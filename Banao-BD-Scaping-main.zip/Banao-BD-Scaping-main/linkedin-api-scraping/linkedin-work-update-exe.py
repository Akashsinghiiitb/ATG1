import time
import linkedin_api as lp
import json
import os
from datetime import datetime 
import requests as r
from log_generator import generate_log
from datetime import date, datetime

# Log file name
current_date = date.today()
current_time = datetime.now().strftime("%H:%M").replace(":", ",")
LOG_FILE = f"{current_time} {current_date} linkedin-work-update-exe"

def do_log(*message):
    output_data = ''
    for i in message:
        output_data += f"{i} "
    print(output_data)
    generate_log(output_data, LOG_FILE)


# Pass : xanak65933  ; User : xanak65933@fulwark.com
while True:
    try:
        user = input("email > ")
        password = input("password > ")
        token = input("token > ")
        api = lp.Linkedin(user,password)
        break
    except Exception as e:
        do_log("error logging in ", e)
        time.sleep(2) 
        os.system('cls')

#Get current user details 
profile = api.get_user_profile()


# Extracting URN of the current logged in user    
profile_urn = profile['miniProfile']['entityUrn'].split(':')[-  1]
messages = []
# Extracting the Public Identifier of the current logged in user
public_identifier = profile["miniProfile"]["publicIdentifier"]
do_log("Public Identifier :", public_identifier)
do_log("Profile URN :", profile_urn)

# Extracting all the conversations and their respective details
data = api.get_conversations()

def get_chats():
    if 'elements' in data:
        for i in range(len(data['elements'])):
            try:
                # Extracting URN of each message
                message_urn = data['elements'][i]['entityUrn'].split(':')[-  1]
                # Getting the details of each message using URN
                message_data = api.get_conversation(message_urn)
                for j in range(len(message_data['elements'])):
                    try:
                        message_detail = []
                        name = message_data['elements'][j]['from']['com.linkedin.voyager.messaging.MessagingMember']['nameInitials']
                        message = message_data['elements'][j]['eventContent']['com.linkedin.voyager.messaging.event.MessageEvent']['attributedBody']['text']
                        
                        message_time = message_data['elements'][j]['createdAt'] / 1000
                        message_date = datetime.fromtimestamp(message_time).strftime('%Y-%m-%d')
                        message_time = datetime.fromtimestamp(message_time).strftime('%H:%M:%S')
                        # Add formatted message to the list
                        message_detail.append({
                            'date': message_date,
                            'messageDetails' : [message],
                            'time': message_time
                        })
                        messages.append({
                            "name": name,
                            "messages": message_detail,
                        })

                        j += 1  # If you want messages of receiver (i.e. current logged in user's messages) also, increment by 1, else by 2
                    except:
                        pass
            except:
                pass
    else:
        do_log("No chat elements found.")

invites = []
get_chats()

def get_sent_invitations():
    invitations = api.get_sent_invitations()
    if invitations:
        for invitation in invitations:
            from_member = invitation['fromMember']
            sender_first_name = from_member['firstName']
            sender_last_name = from_member['lastName']
            sender_full_name = sender_first_name + ' ' + sender_last_name
            # Extract the full name of the recipient
            to_member = invitation['toMember']
            recipient_first_name = to_member['firstName']
            recipient_last_name = to_member['lastName']
            recipient_full_name = recipient_first_name + ' ' + recipient_last_name

            # Extract the sent time and convert it to a readable format
            sent_time = invitation['sentTime'] / 1000
            sent_time = datetime.fromtimestamp(sent_time).strftime('%Y-%m-%d')

            invites.append({
                # 'Sender:': sender_full_name,
                'name': recipient_full_name,
                'time': sent_time
            })
    else:
        invites.append("No invitations found")

get_sent_invitations()

acc = api.get_self_connections()


accepted_conn = []

for i in range(len(acc)):
    try:
        first_name = acc[i]['firstName']
        last_name = acc[i]['lastName']
        acc_time = datetime.now().strftime("%Y-%m-%d")  # No date time in accepted invites...So, used datetime.now()
        accepted_conn.append(
            {
                "name" : first_name+" "+last_name,
                "time" : acc_time
            }
        )
    except:
        pass

final_data = {
    "extension": "linkedin_work_update_exe",
    "version": "23.7.19",
    "connectionCount": len(accepted_conn),
    "accepted": accepted_conn,
    "invites": invites,
    "messageDetails": messages
}

do_log("THE REQUIRED DATA :-\n")
do_log(final_data)

headers = {'Auth':token}
res = r.post('https://bbd.atg.party/api/save-userStats2',json=final_data,headers=headers)
do_log(res.text)
input("Press ENTER to exit")