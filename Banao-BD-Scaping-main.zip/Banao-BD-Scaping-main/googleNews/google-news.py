import undetected_chromedriver.v2 as uc
from selenium.webdriver.common.by import By
import time
from log_generator import generate_log
from datetime import date, datetime

# Log file name
current_date = date.today()
current_time = datetime.now().strftime("%H:%M").replace(":", ",")
LOG_FILE = f"{current_time} {current_date} googleNews"

def do_log(*message):
    output_data = ''
    for i in message:
        output_data += f"{i} "
    print(output_data)
    generate_log(output_data, LOG_FILE)


## search 
class Search():

    def __init__(self,search_key):
        search = driver.find_element(By.XPATH,"//input[2]")
        search.send_keys(search_key)
        search_btn = driver.find_element(By.XPATH,"//button[@aria-label='Search']")
        search_btn.click()
        driver.implicitly_wait(5)
        driver.execute_script("window.scrollTo(0, 768*4);")

    def get_art_links(self):
        links = driver.find_elements(By.XPATH,"//article/a")
        for i in links[:5]:
            news_links.append(i.get_attribute('href'))
            do_log(i.get_attribute('href'))


class diff_link():
    
    def __init__(self): ## to get different domain links rather than current url domain on news page

        for news_url in news_links:
            try:
                driver.get(news_url)
            except:
                continue
            time.sleep(5)
            crnt_url = driver.current_url
            crnt_url = crnt_url.split('/')[2]
            crnt_url = crnt_url.split('.')
            
            if(crnt_url[0] == "www"):
                crnt_url = crnt_url[1]
            else:
                crnt_url = crnt_url[0]
                
            self.return_unmatch(crnt_url)


    def return_unmatch(self,arg):
        links = driver.find_elements(By.XPATH,"//p//a")
        for i in links:
            link = i.get_attribute('href')
            try:
                link = link.split('/')[2]
            except:
                pass
            
            try:
                match = arg in link
            except:
                continue

            if(match):
                pass
            else:
                diff_links.append(i.get_attribute('href'))


if __name__ == "__main__":
    driver = uc.Chrome()
    url = "https://news.google.com/"
    driver.get(url)
    driver.maximize_window()

    news_links = []
    search_key = "startup usa healthcare"
    search_key = input("Enter search Query: ")
    se = Search(search_key)   
    se.get_art_links()

    diff_links = []
    diff_link()

    do_log(len(diff_links))
    for i in diff_links:
        do_log(i)