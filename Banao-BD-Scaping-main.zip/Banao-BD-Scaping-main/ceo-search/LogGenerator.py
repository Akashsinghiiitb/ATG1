import logging
from datetime import date, datetime
import os

# Log file name
current_date = date.today()
current_time = datetime.now().strftime("%H:%M").replace(":", ",")
log_file_name = f"{current_time}_{current_date}_CEO_Scraping"
log_file_location = os.path.join('website', f"{log_file_name}.log")
log_file_location2 = f"{log_file_name}.log"

# Create a logger
logger = logging.getLogger('my_logger')
logger.setLevel(logging.DEBUG)

# Create a file handler to write log messages to the file
file_handler = None
try:
    file_handler = logging.FileHandler(log_file_location, mode='a', encoding='utf-8')
except FileNotFoundError:
    try:
        file_handler = logging.FileHandler(log_file_location2, mode='a', encoding='utf-8')
    except FileNotFoundError:
        pass

if file_handler:
    file_handler.setLevel(logging.DEBUG)
    
    # Create a formatter to specify the log message format
    formatter = logging.Formatter('%(asctime)s  %(message)s')
    file_handler.setFormatter(formatter)

    # Add the file handler to the logger
    logger.addHandler(file_handler)


def generate_log(message):
    logger.info(message)