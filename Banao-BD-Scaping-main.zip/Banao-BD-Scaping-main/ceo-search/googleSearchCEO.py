from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import DesiredCapabilities
from selenium.webdriver.common.proxy import Proxy, ProxyType
import time
import requests
from webdriver_manager.chrome import ChromeDriverManager
import os
from Log_generator import generate_log

start = time.time()
# BASE_URL = "http://127.0.0.1:8000"
BASE_URL = "https://bbd.atg.party"


os.system("cls")
print("Version:23.6.8 \nGreetings from Banao Technologies!\n"
"Please enter your Banao Token in the designated fields and relax while our program extracts the "
"necessary data for you. We respect your privacy and want to assure you that any data entered by you will be not stored in any way."
"Please note that this program is designed solely for the purpose of aiding Banao Technologies, and we strongly advise against using it for any other purpose.\n\n"
"NOTE : This script will take 3 hours to complete.")

token = input("Token > ")

# import chromedriver_binary

prefs = {"profile.default_content_setting_values.notifications": 2}
option=webdriver.ChromeOptions()
option.add_experimental_option("excludeSwitches", ["ignore-certificate-errors"])
option.add_argument('headless')
option.add_argument('--no-sandbox')
option.add_experimental_option("prefs", prefs)
#option.add_argument("--start-maximized")
#option.add_argument("--window-size=1920x1080")
option.add_argument("--disable-extensions")
option.add_argument("--disable-gpu")
option.add_argument("--disable-dev-shm-usage")
option.add_argument("disable-infobars")

def do_log(*message):
    output_data = ''
    for i in message:
        output_data += f"{i} "
    print(output_data)
    generate_log(output_data)

def getSearch(url):
    lst = []
    try:
        driver.get(url)
    except driver.exceptions.RequestException as e:
        do_log(e)

    time.sleep(3)
    links = driver.find_elements(By.XPATH, "//a")

    for i in links:
        link = i.get_attribute('href')
        link = str(link)
        if 'www.linkedin.com/in/' in link:
            lst.append(i)

    return lst


def getData(lst, id=None):
    r = []
    for i in lst:
        res = i.text.split(' - ')

        try:
            if len(res) > 0:
                resp = {
                    'origin': 'linkedin.com',
                    'name': res[0],
                    'position': res[1],
                    'url': i.get_attribute('href'),
                    'company_id':id
                }
                try:
                    resp1 = res[2].split('|')[0]
                    if 'LinkedIn\n' in resp1:
                        resp['company'] = resp1.split('LinkedIn\n')[0]
                    elif '\nhttps:' in resp1:
                        resp['company'] = resp1.split('\nhttps:')[0]
                    else:
                        resp['company'] = resp1

                    if 'LinkedIn' in resp['company']:
                        resp['company'] = ''
                except:
                    pass
                r.append(resp)
        except:
            pass
    return r


def mainFunc(noPostReq, run_id=None):

    try:
        companies, run_id_new = get_data()
    except:
        return 0, None
    if not run_id:
        run_id = run_id_new
    count = 0
    for company_obj in companies:
        company = company_obj['name']
        time.sleep(30)
        for ch in ['/', ',', '|', '.','?']:
            if ch in company:
                company = company.replace(ch, '')
        if '&' in company:
            company = company.replace('&', 'and')

        url = "https://duckduckgo.com/?q=ceo+at+" + \
            str(company) + "+site+linkedin.com&ia=web"

        lst = getSearch(url)
        do_log(count, "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
        search_res_lst = getData(lst, company_obj['id'])

        do_log(search_res_lst)
        try:
            noPostReq, run_id = post_data(search_res_lst, noPostReq, run_id)
        except Exception as e:
            do_log(e)
            pass
        count += 1
        time.sleep(10)
    return noPostReq, run_id


def post_data(detail, noPostReq, run_id):
    url = f"{BASE_URL}/api/postPeopleSearch"

    myobj = detail

    x = requests.post(url, json=myobj, headers={"auth":token})

    do_log(noPostReq, x.text)
    noPostReq = noPostReq + 1
    increase_run_count(run_id)
    return noPostReq, run_id

def increase_run_count(run_id):
    x = requests.post(f"{BASE_URL}/api/increment-run-count", json={'id':run_id}, headers={"auth":token})
    do_log(x.text)

def get_data():
    url = f"{BASE_URL}/api/getCompaniesToSearch?version=v3"
    do_log(locals())
    x = requests.get(url, headers={"auth":token})
    raw_data = x.json()
    data = raw_data["data"]
    run_id = raw_data["run_id"]
    do_log(token, run_id)
    do_log(data)

    return data, run_id

def do_kill():
    run_time = time.time() - start
    if run_time > 3*60*60:
        return True
    return False

if __name__ == "__main__":

    driver = webdriver.Chrome(ChromeDriverManager().install(), options=option)
    # driver = webdriver.Chrome(options=option)

    noPostReq = 1
    run_id = None
    while True:
        noPostReq, run_id = mainFunc(noPostReq, run_id)
        if do_kill() :
            break
    driver.quit()
    do_log("Time taken : ",round(time.time() - start,2))
    input("Press ANY key to exit .")
    pass