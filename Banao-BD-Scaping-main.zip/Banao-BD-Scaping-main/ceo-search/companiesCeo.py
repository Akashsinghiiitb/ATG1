from bs4 import BeautifulSoup
import requests
import time 

def getSearch(url):
    print('aa')
    try:
        # response = requests.get(url, headers=headers)
        response = requests.get(url)
    except requests.exceptions.RequestException as e:
        print(e)
        exit()
    
    time.sleep(3)
    htmlContent = response.content
    soup = BeautifulSoup(htmlContent, "html.parser")
    print(soup.text)
    links = soup.find_all("a")
    print(links)

    for i in links:
        link = i.get('href')
        if 'www.linkedin.com/in/' in link:
            lst.append(i)
    print(len(lst))

    return lst

def getData(lst):
    r = []
    for i in lst:
        res = i.text.split(' - ')
        print(i.text)
        # resp = res[0].replace('|','')
        # print(res)
        if len(res) > 0:
            print('*************************************')
            resp = {
                'name':res[0],
                'position':res[1],
            }
            try:
                resp['comapny'] = res[2].split('|')[0]
            except:
                pass
            r.append(resp)
    return r
        # print(resp)

    # for i in lst1:
    #     res1 = []
    #     res = i.split('-')
    #     while(" " in res):
    #         res.remove(" ")
    #     for r in res:
    #         r = r.strip()
    #         res1.append(r)
    #     if len(res1) == 2:
    # #         res1 = res1[1].split(',')
    #         pass
    #     elif len(res1) == 4:
    #         if res1[1] == 'Co':
    #             res1[1] = res1[1] + '-' + res1[2]
    #             res1.remove(res1[2])

        # print(res1)

    # return lst1


if __name__ == "__main__":
    
    companies = [
        # 'banao',
        'canva',
        'atg',
        'leetcode'
    ]
    lst = []

    for company in companies:
        lst = []
        url = "https://www.google.com/search?q=ceo+at+"+ str(company) + "+site%3Alinkedin.com&aqs=chrome..69i57.403j0j9&sourceid=chrome&ie=UTF-8"
        print(url)
        getSearch(url)
        print(getData(lst))
