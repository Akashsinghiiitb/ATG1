from selenium.webdriver.common.by import By
import time
import requests
import os
import random
from selenium import webdriver
from selenium.common.exceptions import WebDriverException
from Log_generator import generate_log
import threading
from selenium.common.exceptions import TimeoutException

start = time.time()
BASE_URL = "https://bbd.atg.party"

flag = 0

os.system("cls")
print(
    "Version:23.8.27 \nGreetings from Banao Technologies!\n"
    "Please enter your Banao Token in the designated fields and relax while our program extracts the "
    "necessary data for you. We respect your privacy and want to assure you that any data entered by you will be not stored in any way."
    "Please note that this program is designed solely for the purpose of aiding Banao Technologies, and we strongly advise against using it for any other purpose.\n\n"
    "NOTE : This script will take 3 hours to complete."
)

token = input("Token > ")

prefs = {"profile.default_content_setting_values.notifications": 2}
options = webdriver.EdgeOptions()
options.use_chromium = True
options.add_experimental_option("excludeSwitches", ["ignore-certificate-errors"])
options.add_experimental_option("prefs", prefs)
options.add_experimental_option("excludeSwitches", ["enable-logging"])
options.add_argument("--no-sandbox")
options.add_argument("--disable-extensions")
options.add_argument("--disable-gpu")
options.add_argument("--disable-dev-shm-usage")
options.add_argument("--disable-infobars")
options.add_argument("--log-level=1")
options.add_argument("--headless")


def do_log(*message):
    output_data = ""
    for i in message:
        output_data += f"{i} "
    print(output_data)
    generate_log(output_data)

def getSearch(url):
    lst = []
    try:
        driver.get(url)
        time.sleep(7)
        links = driver.find_elements(By.XPATH, "//a")
        for i in links:
            link = i.get_attribute("href")
            link = str(link)
            if "linkedin.com/in/" in link:
                lst.append(i)
    except TimeoutException:
        print("Page load timed out after 60 seconds")
    except WebDriverException as e:
        do_log(e)
    return lst


def getData(lst, id=None):
    r = []
    for i in lst:
        res = i.text.split(" - ")

        try:
            if len(res) > 0:
                resp = {
                    "origin": "linkedin.com",
                    "name": res[0],
                    "position": res[1],
                    "url": i.get_attribute("href"),
                }
                try:
                    resp1 = res[2].split("|")[0]
                    if "LinkedIn\n" in resp1:
                        resp["company"] = resp1.split("LinkedIn\n")[0]
                    elif "\nhttps:" in resp1:
                        resp["company"] = resp1.split("\nhttps:")[0]
                    else:
                        resp["company"] = resp1

                    if "LinkedIn" in resp["company"]:
                        resp["company"] = ""
                except:
                    pass
                r.append(resp)
        except:
            pass
    return r


def mainFunc(noPostReq, run_id=None):
    try:
        companies, run_id_new = get_data()
    except:
        return 0, None
    if not run_id:
        run_id = run_id_new
    count = 0
    for company_obj in companies:
        company = company_obj["name"]
        time.sleep(30)
        for ch in ["/", ",", "|", ".", "?", " ", "-"]:
            if ch in company:
                company = company.replace(ch, "+")
        if "&" in company:
            company = company.replace("&", "and")

        urls_lst = [
            "https://www.google.com/search?q="
            + str(company)
            + "+site+linkedin.com&ia=web",
            "https://duckduckgo.com/?q=" + str(company) + "+site+linkedin.com&ia=web",
            "https://swisscows.com/en/web?query=" + str(company) + "+site+linkedin.com",
            "https://www.ecosia.org/search?method=index&q="
            + str(company)
            + "+site+linkedin.com",
            "https://www.startpage.com/do/search?query="
            + str(company)
            + "+site+linkedin.com&lui=english",
            "https://you.com/search?q="
            + str(company)
            + "+site+linkedin.com&source=web",
            "https://search.brave.com/search?q="
            + str(company)
            + "+site+linkedin.com&source=web",
            "https://yandex.ru/search/?text="
            + str(company)
            + "+site+linkedin.com&ia=web&lr=112509",
            "https://search.yahoo.com/search?p="
            + str(company)
            + "+site+linkedin.com&ia=web",
            "https://www.bing.com/search?q="
            + str(company)
            + "+site+linkedin.com&ia=web",
        ]

        i = 0

        while i < 3:
            try:
                url = random.choice(urls_lst)
                do_log(url)
                lst = getSearch(url)
                do_log(
                    count, "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
                )
                search_res_lst = getData(lst, company_obj["id"])
                if len(search_res_lst) > 0:
                    break
                i += 1
            except Exception as e:
                do_log("Error during scraping:", e)
                i += 1


        do_log(search_res_lst)
        try:
            noPostReq, run_id = post_data(search_res_lst, noPostReq, run_id)
        except Exception as e:
            do_log(e)
            pass
        count += 1
        time.sleep(10)
    return noPostReq, run_id


def post_data(detail, noPostReq, run_id):
    url = f"{BASE_URL}/api/postPeopleSearch"

    myobj = detail

    x = requests.post(url, json=myobj, headers={"auth": token})

    do_log(noPostReq, x.text)
    noPostReq = noPostReq + 1
    increase_run_count(run_id)
    return noPostReq, run_id


def increase_run_count(run_id):
    x = requests.post(
        f"{BASE_URL}/api/increment-run-count",
        json={"id": run_id},
        headers={"auth": token},
    )

    do_log(x.text)


def get_data():
    url = f"{BASE_URL}/api/getCompaniesToSearch?version=v3"
    do_log(locals())
    id = 1
    x = requests.get(url, headers={"auth": token})
    raw_data = x.json()
    data = raw_data["data"]
    run_id = raw_data["run_id"]
    do_log(token, run_id)
    do_log(data)

    return data, run_id


def do_kill():
    run_time = time.time() - start
    if run_time > 3 * 60 * 60:
        return True
    return False


def loop_increase_count():
    while True:
        increase_run_count(run_id)
        time.sleep(120)
        if flag != 0:
            print("Thread exit")
            return


thread = threading.Thread(target=loop_increase_count)


if __name__ == "__main__":
    driver = webdriver.Edge(options=options)
    driver.set_page_load_timeout(60)
    noPostReq = 1
    run_id = None
    thread.start()
    try:
        while True:
            noPostReq, run_id = mainFunc(noPostReq, run_id)
            if do_kill():
                flag = 1
                break
    except WebDriverException as e:
        flag = 1
        do_log(e)
    finally:
        driver.quit()
        do_log("Time taken : ", round(time.time() - start, 2))
        flag = 1

        input("Press ANY key to exit .")
