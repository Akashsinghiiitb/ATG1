from selenium.webdriver.common.by import By
import time
from time import sleep
import requests
import os
import random
import bugsnag
import bugsnag.handlers
import bugsnag.wsgi
from selenium import webdriver
from selenium.common.exceptions import WebDriverException
from LogGenerator import generate_log
import threading
from selenium.common.exceptions import TimeoutException

start = time.time()
# BASE_URL = "https://bbd.atg.party"
BASE_URL = "http://127.0.0.1:8000"

flag = 0

os.system("cls")
print(
    "Version:24.5.3 \nGreetings from Banao Technologies!\n"
    "Please enter your Banao Token in the designated fields and relax while our program extracts the "
    "necessary data for you. We respect your privacy and want to assure you that any data entered by you will be not stored in any way."
    "Please note that this program is designed solely for the purpose of aiding Banao Technologies, and we strongly advise against using it for any other purpose.\n\n"
    "NOTE : This script will take 3 hours to complete."
)

token = input("Token > ")

prefs = {"profile.default_content_setting_values.notifications": 2}
options = webdriver.EdgeOptions()
options.use_chromium = True
options.add_experimental_option("excludeSwitches", ["ignore-certificate-errors"])
options.add_experimental_option("prefs", prefs)
options.add_experimental_option("excludeSwitches", ["enable-logging"])
options.add_argument("--no-sandbox")
options.add_argument("--disable-extensions")
options.add_argument("--disable-gpu")
options.add_argument("--disable-dev-shm-usage")
options.add_argument("--disable-infobars")
options.add_argument("--log-level=1")
# options.add_argument("--headless")

# Configure Bugsnag with  API key
bugsnag.configure(api_key="8ecc98361720afb87f0d8e8c495b49a4")

def do_log(*message):
    output_data = ""
    for i in message:
        output_data += f"{i} "
    print(output_data)
    generate_log(output_data)
    bugsnag.notify(Exception(output_data))
    


def getSearch(url):
    lst = []
    try:
        driver.get(url)
        time.sleep(7)
        links = driver.find_elements(By.XPATH, "//a")
        for i in links:
            link = i.get_attribute("href")
            link = str(link)
            if "linkedin.com/in/" in link:
                lst.append(i)
    except TimeoutException:
        print("Page load timed out after 60 seconds")
    except WebDriverException as e:
        do_log(e)
    return lst


exlusion_list = [
    "linkedin.com",
    "facebook.com",
    "instagram.com",
    "twitter.com",
    "glassdoor.",
    "ambitionbox.com",
    "internshala.com",
    "goodfirms.",
    "naukri.com",
    "bing.com",
    "stackoverflow.com",
    "github.com",
    "yahoo.com",
    "brave.com",
    "twitch.tv",
    "duckduckgo.com",
    "ecosia.org",
    "swisscows.com",
    "youtube.com",
    "you.com",
    "startpage.com",
    "wikipedia.org",
    "startpage.com",
    "yandex.ru",
    "ya.ru",
    "javascript",
    "crunchbase.com",
    "imdb.com"
    
]
def getWebsite(url):
    lst = []
    try:
        driver.get(url)
        time.sleep(7)
        links = driver.find_elements(By.XPATH, "//a")
        for i in links:
            link = i.get_attribute("href")
            link = str(link)
            if "linkedin.com" in link or "facebook.com" in link or "instagram.com" in link or "twitter.com" in link or "glassdoor." in link or "ambitionbox.com" in link or "internshala.com" in link or "goodfirms." in link or "naukri.com" in link:
                continue
            else:
                lst.append(link)
    except TimeoutException:
        print("Page load timed out after 60 seconds")
    except WebDriverException as e:
        do_log(e)
    return lst


def getData(lst, id=None):
    r = []
    for i in lst:
        print(type(i.text))
        res = i.text.split(" - ")
        print(';asfai')
        try:
            if len(res) > 0:
                resp = {
                    "origin": "linkedin.com",
                    "name": res[0],
                    "position": res[1],
                    "url": i.get_attribute("href"),
                }
                try:
                    resp1 = res[2].split("|")[0]
                    if "LinkedIn\n" in resp1:
                        resp["company"] = resp1.split("LinkedIn\n")[0]
                    elif "\nhttps:" in resp1:
                        resp["company"] = resp1.split("\nhttps:")[0]
                    else:
                        resp["company"] = resp1

                    if "LinkedIn" in resp["company"]:
                        resp["company"] = ""
                except:
                    pass
                r.append(resp)
        except:
            pass
    return r


def mainFunc(noPostReq, run_id=None):
    try:
        companies, run_id_new = get_data()
    except:
        return 0, None
    if not run_id:
        run_id = run_id_new
    count = 0
    for company_obj in companies:
        company = company_obj["name"]
        time.sleep(30)
        for ch in ["/", ",", "|", ".", "?", " ", "-"]:
            if ch in company:
                company = company.replace(ch, "+")
        if "&" in company:
            company = company.replace("&", "and")

        urls_lst = [
            "https://www.google.com/search?q="
            + str(company)
            + "+site+linkedin.com&ia=web",
            "https://duckduckgo.com/?q=" + str(company) + "+site+linkedin.com&ia=web",
            "https://swisscows.com/en/web?query=" + str(company) + "+site+linkedin.com",
            "https://www.ecosia.org/search?method=index&q="
            + str(company)
            + "+site+linkedin.com",
            "https://www.startpage.com/do/search?query="
            + str(company)
            + "+site+linkedin.com&lui=english",
            "https://you.com/search?q="
            + str(company)
            + "+site+linkedin.com&source=web",
            "https://search.brave.com/search?q="
            + str(company)
            + "+site+linkedin.com&source=web",
            "https://yandex.ru/search/?text="
            + str(company)
            + "+site+linkedin.com&ia=web&lr=112509",
            "https://search.yahoo.com/search?p="
            + str(company)
            + "+site+linkedin.com&ia=web",
            "https://www.bing.com/search?q="
            + str(company)
            + "+site+linkedin.com&ia=web",
        ]
        
        website_urls_lst = [
            "https://www.google.com/search?q="
            + str(company)
            + "+site+linkedin.com&ia=web",
            "https://duckduckgo.com/?q=" + str(company) + "&ia=web",
            "https://swisscows.com/en/web?query=" + str(company) + "",
            "https://www.ecosia.org/search?method=index&q="
            + str(company)
            + "",
            "https://www.startpage.com/do/search?query="
            + str(company)
            + "&lui=english",
            "https://you.com/search?q="
            + str(company)
            + "&source=web",
            "https://search.brave.com/search?q="
            + str(company)
            + "&source=web",
            "https://yandex.ru/search/?text="
            + str(company)
            + "&ia=web&lr=112509",
            "https://search.yahoo.com/search?p="
            + str(company)
            + "&ia=web",
            "https://www.bing.com/search?q="
            + str(company)
            + "&ia=web",
        ]

        i = 0

        while i < 3:
            try:
                url = random.choice(urls_lst)
                do_log(url)
                lst = getSearch(url)
                do_log(
                    len(lst), "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
                )
                search_res_lst = getData(lst, company_obj["id"])
                if len(search_res_lst) > 0:
                    break
                i += 1
            except Exception as e:
                do_log("Error during scraping:", e)
                i += 1
        
        i=0
        while i < 3:
            try:
                url = random.choice(website_urls_lst)
                do_log(url)
                lst = getWebsite(url)
                do_log(
                    count, "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
                )
                if len(lst) > 0:
                    print(f"Website: {lst[0]}")
                    website = lst[0]
                    website = website.split("//")[-1]
                    website = website.split("/")[0]
                    post_company_website(company_obj["id"], website)
                    break
                else:
                    print("No website found")
                i += 1
            except Exception as e:
                do_log("Error during scraping:", e)
                i += 1


        do_log(search_res_lst)
        try:
            noPostReq, run_id = post_data(search_res_lst, noPostReq, run_id)
        except Exception as e:
            do_log(e)
            pass
        count += 1
        time.sleep(10)
    return noPostReq, run_id


def post_data(detail, noPostReq, run_id):
    url = f"{BASE_URL}/api/postPeopleSearch"

    myobj = detail

    x = requests.post(url, json=myobj, headers={"auth": token})

    do_log(noPostReq, x.text)
    noPostReq = noPostReq + 1
    increase_run_count(run_id)
    return noPostReq, run_id

def post_company_website(company_id, website):
    url = f"{BASE_URL}/api/saveCompanyWebsite"

    myobj = {
        "company_id": company_id,
        "website": website,
        "source":"google"
    }

    x = requests.post(url, json=myobj, headers={"auth": token})

    do_log(x.text)


def increase_run_count(run_id):
    x = requests.post(
        f"{BASE_URL}/api/increment-run-count",
        json={"id": run_id},
        headers={"auth": token},
    )

    do_log(x.text)


def get_data():
    url = f"{BASE_URL}/api/getCompaniesToSearch?version=v3"
    do_log(locals())
    id = 1
    x = requests.get(url, headers={"auth": token})
    raw_data = x.json()
    data = raw_data["data"]
    run_id = raw_data["run_id"]
    do_log(token, run_id)
    do_log(data)

    return data, run_id


def do_kill():
    run_time = time.time() - start
    if run_time > 3 * 60 * 60:
        return True
    return False


def loop_increase_count():
    while True:
        increase_run_count(run_id)
        time.sleep(120)
        if flag != 0:
            print("Thread exit")
            return


thread = threading.Thread(target=loop_increase_count)
# Code to Extract the official website link
# Function to initialize a Chrome WebDriver
def initialize_driver():
    return webdriver.Chrome()

# Function to navigate to the specified search engine URL with error handling and retry mechanism
def navigate_to_search_engine(driver, search_engine_url):
    retries = 3
    while retries > 0:
        try:
            driver.get(search_engine_url)
            sleep(2)
            return
        except TimeoutException:
            print("Connection timed out. Retrying...")
            retries -= 1
    raise ConnectionError("Failed to establish connection to the search engine URL.")

# Function to perform a search using the provided query
def perform_search(driver, query):
    # XPaths for search box and search button
    search_box_xPath = "//*[@id='q']"
    search_button_xPath = "//*[@id='send_search']"

    # Find and interact with the search box
    search_box = driver.find_element(By.XPATH, search_box_xPath)
    search_box.click()
    search_box.send_keys(query)

    # Find and click the search button
    search_button = driver.find_element(By.XPATH, search_button_xPath)
    search_button.click()
    sleep(10)

# Function to extract URLs from search results on multiple pages with error handling
# Function to extract the first URL from search results
def extract_first_url(driver):
    try:
        # XPath for the first URL element in the search results
        first_url_xPath = "//*[@id='urls']/article[1]/a/span[1]/span"

        # Find the first URL element
        first_url_element = driver.find_element(By.XPATH, first_url_xPath)

        # Return the text of the first URL element
        return first_url_element.text.strip()
    except Exception as e:
        print(f"Error extracting the first URL: {str(e)}")
        return None

# Main function to perform search and scrape the first URL
def search_and_scrape_first_url(search_engine_url, search_query):
    driver = initialize_driver()

    try:
        navigate_to_search_engine(driver, search_engine_url)
        perform_search(driver, search_query)

        first_url = extract_first_url(driver)
        if first_url:
            print( first_url)
        else:
            print("No URL found in the search results.")
    finally:
        close_driver(driver)


# Function to print extracted URLs
def print_urls(urls):
    print("Search Results:")
    for i, url in enumerate(urls, start=1):
        print(f"{i}. {url}")

# Function to close the WebDriver
def close_driver(driver):
    driver.quit()

# Main function to perform search and scrape URLs
def search_and_scrape(search_engine_url, search_query, num_pages=5):
    driver = initialize_driver()

    try:
        navigate_to_search_engine(driver, search_engine_url)
        perform_search(driver, search_query)

        urls = extract_urls(driver, num_pages)
        print_urls(list(set(urls)))

    finally:
        close_driver(driver)


if __name__ == "__main__":
    driver = webdriver.Edge(options=options)
    driver.set_page_load_timeout(60)
    noPostReq = 1
    run_id = None
    thread.start()
    try:
        while True:
            noPostReq, run_id = mainFunc(noPostReq, run_id)
            if do_kill():
                flag = 1
                break
    except WebDriverException as e:
        flag = 1
        do_log(e)
    finally:
        
        do_log("Time taken : ", round(time.time() - start, 2))
        flag = 1

        input("Press ANY key to exit .")


      
    search_engine_url = "https://search.nadeko.net/"
    search_query = 'Banao Technologies'

    search_and_scrape_first_url(search_engine_url, search_query)
    driver.quit()




