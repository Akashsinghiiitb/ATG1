from selenium import webdriver
from selenium.webdriver.common.by import By
import time
from selenium.common.exceptions import WebDriverException


prefs = {"profile.default_content_setting_values.notifications": 2}
options = webdriver.EdgeOptions()
options.use_chromium = True
options.add_experimental_option("excludeSwitches", ["ignore-certificate-errors"])
options.add_experimental_option("prefs", prefs)
options.add_experimental_option("excludeSwitches", ["enable-logging"])
options.add_argument('--no-sandbox')
options.add_argument("--disable-extensions")
options.add_argument("--disable-gpu")
options.add_argument("--disable-dev-shm-usage")
options.add_argument("--disable-infobars")
options.add_argument("--log-level=1")
options.add_argument("--headless")

driver = webdriver.Edge(options=options)


def getSearch(url):
    lst = []
    try:
        driver.get(url)
        time.sleep(3) 
        links = driver.find_elements(By.XPATH, "//a")
        for i in links:
            link = i.get_attribute('href')
            link = str(link)
            if 'linkedin.com/in/' in link:
                lst.append(i.get_attribute('href'))
    except WebDriverException as e:
        print(e)
    return lst


def getData(lst, id=None):
    r = []
    try:
        for i in lst:
            res = i.text.split(' - ')
            if len(res) > 1:  # Ensure that res list has at least two elements (name and position)
                resp = {
                    'origin': 'linkedin.com',
                    'name': res[0],
                    'position': res[1],
                    'url': i.get_attribute('href'),
                }
                try:
                    resp1 = res[2].split('|')[0].strip()
                    if 'LinkedIn' in resp1:
                        resp['company'] = ''
                    elif '\nhttps:' in resp1:
                        resp['company'] = resp1.split('\nhttps:')[0].strip()
                    else:
                        resp['company'] = resp1.strip()
                except IndexError:
                    pass
                r.append(resp)
    except Exception as e:
        print("Error occurred while extracting data:", e)
    return r



def mainFunc_Bing(search_str):
    # time.sleep(30)
    # time.sleep(30)
    for ch in ['/', ',', '|', '.','?']:
        if ch in search_str:
            search_str = search_str.replace(ch, '')
    if '&' in search_str:
        search_str = search_str.replace('&', 'and')

    url = "https://www.bing.com/search?q=" + \
        str(search_str) + "+site+linkedin.com&ia=web"

    lst = getSearch(url)
    # search_res_lst = getData(lst)

    return lst


def mainFunc_Yahoo(search_str):
    # time.sleep(30)
    # time.sleep(30)
    for ch in ['/', ',', '|', '.','?']:
        if ch in search_str:
            search_str = search_str.replace(ch, '')
    if '&' in search_str:
        search_str = search_str.replace('&', 'and')

    url = "https://search.yahoo.com/search?p=" + \
        str(search_str) + "+site+linkedin.com&ia=web"

    lst = getSearch(url)
    # search_res_lst = getData(lst)

    return lst


def mainFunc_Yandex(search_str):
    # time.sleep(30)
    for ch in ['/', ',', '|', '.','?']:
        if ch in search_str:
            search_str = search_str.replace(ch, '')
    if '&' in search_str:
        search_str = search_str.replace('&', 'and')

    url = "https://yandex.ru/search/?text=" + \
        str(search_str) + "+site+linkedin.com&ia=web&lr=112509"

    lst = getSearch(url)
    # search_res_lst = getData(lst)

    return lst


def mainFunc_Brave(search_str):
    # time.sleep(30)
    # time.sleep(30)
    for ch in ['/', ',', '|', '.','?']:
        if ch in search_str:
            search_str = search_str.replace(ch, '')
    if '&' in search_str:
        search_str = search_str.replace('&', 'and')

    url = "https://search.brave.com/search?q=" + \
        str(search_str) + "+site+linkedin.com&source=web"

    lst = getSearch(url)
    # search_res_lst = getData(lst)

    return lst


def mainFunc_You(search_str):
    # time.sleep(30)
    # time.sleep(30)
    for ch in ['/', ',', '|', '.','?']:
        if ch in search_str:
            search_str = search_str.replace(ch, '')
    if '&' in search_str:
        search_str = search_str.replace('&', 'and')

    url = "https://you.com/search?q=" + \
        str(search_str) + "+site+linkedin.com&source=web"

    lst = getSearch(url)
    # search_res_lst = getData(lst)

    return lst


def mainFunc_StartPage(search_str):
    # time.sleep(30)
    # time.sleep(30)
    for ch in ['/', ',', '|', '.','?']:
        if ch in search_str:
            search_str = search_str.replace(ch, '')
    if '&' in search_str:
        search_str = search_str.replace('&', 'and')

    url = "https://www.startpage.com/do/search?query=" + \
        str(search_str) + "+site+linkedin.com&lui=english"

    lst = getSearch(url)
    # search_res_lst = getData(lst)

    return lst

def mainFunc_Ecosia(search_str):
    # time.sleep(30)
    # time.sleep(30)
    for ch in ['/', ',', '|', '.','?']:
        if ch in search_str:
            search_str = search_str.replace(ch, '')
    if '&' in search_str:
        search_str = search_str.replace('&', 'and')

    url = "https://www.ecosia.org/search?method=index&q=" + \
        str(search_str) + "+site+linkedin.com"

    lst = getSearch(url)
    # search_res_lst = getData(lst)

    return lst


def mainFunc_SwissCows(search_str):
    # time.sleep(30)
    # time.sleep(30)
    for ch in ['/', ',', '|', '.','?']:
        if ch in search_str:
            search_str = search_str.replace(ch, '')
    if '&' in search_str:
        search_str = search_str.replace('&', 'and')

    url = "https://swisscows.com/en/web?query=" + \
        str(search_str) + "+site+linkedin.com"

    lst = getSearch(url)
    # search_res_lst = getData(lst)

    return lst


def mainFunc_DuckDuckGo(search_str):
    # time.sleep(30)
    for ch in ['/', ',', '|', '.','?']:
        if ch in search_str:
            search_str = search_str.replace(ch, '')
    if '&' in search_str:
        search_str = search_str.replace('&', 'and')

    url = "https://duckduckgo.com/?q=" + \
        str(search_str) + "+site+linkedin.com&ia=web"

    lst = getSearch(url)
    # search_res_lst = getData(lst)

    return lst


def mainFunc_Google(search_str):
    # time.sleep(30)
    for ch in ['/', ',', '|', '.','?']:
        if ch in search_str:
            search_str = search_str.replace(ch, '')
    if '&' in search_str:
        search_str = search_str.replace('&', 'and')

    url = "https://www.google.com/search?q=" + \
        str(search_str) + "+site+linkedin.com&ia=web"

    lst = getSearch(url)
    # search_res_lst = getData(lst)

    return lst