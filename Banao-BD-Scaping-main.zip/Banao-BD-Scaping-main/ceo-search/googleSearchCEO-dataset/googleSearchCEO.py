from selenium import webdriver
from selenium.webdriver.common.by import By
import time
import requests
import os
from log_generator import generate_log

from google_search import (
    mainFunc_Bing,
    mainFunc_Yahoo,
    mainFunc_Yandex,
    mainFunc_Brave,
    mainFunc_You,
    mainFunc_StartPage,
    mainFunc_Ecosia,
    mainFunc_SwissCows,
    mainFunc_DuckDuckGo,
    mainFunc_Google,
)

search_functions = [
    mainFunc_Bing,
    mainFunc_Yahoo,
    mainFunc_Yandex,
    mainFunc_Brave,
    mainFunc_You,
    mainFunc_StartPage,
    mainFunc_Ecosia,
    mainFunc_SwissCows,
    mainFunc_DuckDuckGo,
    mainFunc_Google,
]

start = time.time()
# FLASK_BASE_URL = "http://127.0.0.1:5000"
# NODE_BASE_URL = "http://127.0.0.1:8000"

NODE_BASE_URL = "https://bbd.atg.party"
FLASK_BASE_URL = "https://bbd.atg.party"


os.system("cls")
print("Version:23.6.8 \nGreetings from Banao Technologies!\n"
"Please enter your Banao Token in the designated fields and relax while our program extracts the "
"necessary data for you. We respect your privacy and want to assure you that any data entered by you will be not stored in any way."
"Please note that this program is designed solely for the purpose of aiding Banao Technologies, and we strongly advise against using it for any other purpose.\n\n"
"NOTE : This script will take 3 hours to complete.")

token = input("Token > ")

prefs = {"profile.default_content_setting_values.notifications": 2}
options = webdriver.EdgeOptions()
options.use_chromium = True
options.add_experimental_option("excludeSwitches", ["ignore-certificate-errors"])
options.add_experimental_option("prefs", prefs)
options.add_experimental_option("excludeSwitches", ["enable-logging"])
options.add_argument('--no-sandbox')
options.add_argument("--disable-extensions")
options.add_argument("--disable-gpu")
options.add_argument("--disable-dev-shm-usage")
options.add_argument("--disable-infobars")
options.add_argument("--log-level=1")
options.add_argument("--headless")

def do_log(*message):
    output_data = ''
    for i in message:
        output_data += f"{i} "
    print(output_data)
    generate_log(output_data)

def getSearch(url):
    lst = []
    try:
        driver.get(url)
    except driver.exceptions.RequestException as e:
        do_log(e)

    time.sleep(3)
    links = driver.find_elements(By.XPATH, "//a")

    for i in links:
        link = i.get_attribute('href')
        link = str(link)
        if 'www.linkedin.com/in/' in link:
            lst.append(i)

    return lst


def getData(lst, id=None):
    r = []
    for i in lst:
        res = i.text.split(' - ')

        try:
            if len(res) > 0:
                resp = {
                    'origin': 'linkedin.com',
                    'name': res[0],
                    'position': res[1],
                    'url': i.get_attribute('href'),
                    'company_id':id
                }
                try:
                    resp1 = res[2].split('|')[0]
                    if 'LinkedIn\n' in resp1:
                        resp['company'] = resp1.split('LinkedIn\n')[0]
                    elif '\nhttps:' in resp1:
                        resp['company'] = resp1.split('\nhttps:')[0]
                    else:
                        resp['company'] = resp1

                    if 'LinkedIn' in resp['company']:
                        resp['company'] = ''
                except:
                    pass
                r.append(resp)
        except:
            pass
    return r

def get_profiles(query, run_id):
    query_list = query.split()[0:-2]
    query = ''
    for word in query_list:
        query += word + " "
    print(query)
    links = []
    for func in search_functions:
        links += func(query)
        print('links', links, len(links))

    links = list(set(links))
    increase_run_count(run_id)
    return links

def mainFunc(noPostReq, run_id):
    try:
        data = get_data()
    except:
        return 0, run_id
    
    count = 0
    query = data.get("query")
    url_links = []
    # If the page number doesn't exists, get_profiles throw an error
    try:
        url_links += get_profiles(query, run_id)
    except Exception as e:
        print(e)
        pass

    if len(url_links) > 0:
        scraped_data = []
        for i in url_links:
            single_url_data = {
                "url": i,
                "name": None #modify it
            }
            scraped_data.append(single_url_data)

        do_log(count, "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
        try:
            noPostReq, run_id = post_data(scraped_data, noPostReq, run_id, data.get("qid"))
        except Exception as e:
            do_log(e)
            pass
        count += 1
        time.sleep(10)
    return noPostReq, run_id


def post_data(detail, noPostReq, run_id, qid):
    # Should change the URL 
    res2 = requests.post(f"{FLASK_BASE_URL}/flask/google-keywords/update-log", json={"qid": qid})

    res = requests.post(f"{NODE_BASE_URL}/api/save-google-search-peoples", json={"data":detail, "keyword_id":res2.json()['keyword_id']})

    do_log(noPostReq, res.text, res2.text)
    noPostReq = noPostReq + 1
    increase_run_count(run_id)
    return noPostReq, run_id

def increase_run_count(run_id):
    x = requests.post(f"{NODE_BASE_URL}/api/increment-run-count", json={'id':run_id}, headers={"auth":token})
    do_log(x.text)

def get_data():
    do_log(locals())
    response = requests.get(f"{FLASK_BASE_URL}/flask/google-keywords/get-page", json={"token": token})
    data = response.json()
    do_log(token)
    do_log(data)

    return data

def do_kill():
    run_time = time.time() - start
    if run_time > 3*60*60:
        return True
    return False

# Token verification
def get_run_id(token):
    res = requests.post(f"{NODE_BASE_URL}/api/create-entry-of-userstats", json={'token':token, 'extension':'exe_googlesearchCEO'})
    if res.status_code != 200:
        return None , res.text
    return res.json()['id'] , None

if __name__ == "__main__":
    driver = webdriver.Edge(options=options)

    noPostReq = 1
    run_id, _ = get_run_id(token)
    print("Run ID:", run_id)
    if run_id:
        while True:
            noPostReq, run_id = mainFunc(noPostReq, run_id)
            if do_kill() :
                break
        driver.quit()
        do_log("Time taken : ",round(time.time() - start,2))
        input("Press ANY key to exit .")
        pass
    else:
        exit()