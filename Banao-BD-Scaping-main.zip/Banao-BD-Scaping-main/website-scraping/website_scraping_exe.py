import website_scraping
import api_update
import requests
import json
import time
from log_generator import generate_log
from selenium import webdriver
from selenium.common.exceptions import WebDriverException
import threading
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
import random
from urllib.parse import urlsplit, urlparse
import requests
from bs4 import BeautifulSoup
from english_stopwords import stopwords as stop_words


print("Version:24.5.9 \nGreetings from Banao Technologies!\n"
"Please enter your Banao Token in the designated fields and relax while our program extracts the "
"necessary data for you. We respect your privacy and want to assure you that any data entered by you will be not stored in any way."
"Please note that this program is designed solely for the purpose of aiding Banao Technologies, and we strongly advise against using it for any other purpose.\n\n"
"NOTE : This script will take 6 hours to complete.")

token = input("Token > ")
start = time.time()
BASE_URL = "https://bbd.atg.party"
# BASE_URL = "http://127.0.0.1:8000"

prefs = {"profile.default_content_setting_values.notifications": 2}
options = webdriver.EdgeOptions()
options.use_chromium = True
options.add_experimental_option("excludeSwitches", ["ignore-certificate-errors"])
options.add_experimental_option("prefs", prefs)
options.add_experimental_option("excludeSwitches", ["enable-logging"])
options.add_argument("--no-sandbox")
options.add_argument("--disable-extensions")
options.add_argument("--disable-gpu")
options.add_argument("--disable-dev-shm-usage")
options.add_argument("--disable-infobars")
options.add_argument("--log-level=1")
options.add_argument("--headless")

def do_log(*message):
    output_data = ''
    for i in message:
        output_data += f"{i} "
    print(output_data)
    generate_log(output_data)

def get_run_id(token):
    res = requests.post(f"{BASE_URL}/api/create-entry-of-userstats", json={'token':token, 'extension':'website_scraping_exe'})
    if res.status_code != 200:
        return None , res.text
    return res.json()['id'] , None

run_id, err =  get_run_id(token)
if err:
    do_log("Wrong Token \n")
    input("Press enter to close and try again")
    exit()
    
def scrape_and_check_keywords(url, company_name):
  """
  This function scrapes the homepage of a website and checks for occurrences 
  of the company name (ignoring stopwords).

  Args:
      url (str): The URL of the website to scrape.
      company_name (str): The company name to search for.

  Returns:
      int: The number of matches found for the company name (excluding stopwords).
  """
  try:
    print(f'scraping {url}')
    parsed_url = urlparse(url)
    if not parsed_url.scheme or parsed_url.scheme == "":
        url = f"https://{url}"
    response = requests.get(url)
    soup = BeautifulSoup(response.content, "html.parser")
    text = soup.get_text(separator=' ')  # Extract text content
    company_words = [w.lower() for w in company_name.split() if w.lower() not in stop_words]  # Split, lowercase, and remove stopwords
    tokens = text.lower().replace("\n", " ").split(" ")  # Tokenize and lowercase
    filtered_words = [w for w in tokens if w not in stop_words and w in company_words]  # Remove stopwords and filter by company words
    return len(filtered_words)
  except Exception as e:
    print(f"Error scraping {url}: {e}")
    return 0
    
def is_root_url(url):
  """
  This function checks if the given URL is the root URL of the website.

  Args:
      url (str): The URL to check.

  Returns:
      bool: True if the URL is the root URL, False otherwise.
  """
  parsed_url = urlsplit(url)
  # Check if path and query string are empty
  return parsed_url.path == "" or parsed_url.path == "/"

    
exlusion_list = [
    "linkedin.com",
    "facebook.com",
    "instagram.com",
    "twitter.com",
    "glassdoor.",
    "ambitionbox.com",
    "internshala.com",
    "goodfirms.",
    "naukri.com",
    "bing.com",
    "stackoverflow.com",
    "github.com",
    "yahoo.com",
    "brave.com",
    "twitch.tv",
    "duckduckgo.com",
    "ecosia.org",
    "swisscows.com",
    "youtube.com",
    "you.com",
    "startpage.com",
    "wikipedia.org",
    "startpage.com",
    "yandex.ru",
    "ya.ru",
    "javascript",
    "crunchbase.com",
    "imdb.com",
    "teleguard.com"
    
]
def getWebsite(url, company_name):
    lst = []
    website_url = None
    try:
        driver.get(url)
        time.sleep(7)
        links = driver.find_elements(By.XPATH, "//a")
        for i in links:
            link = i.get_attribute("href")
            link = str(link)
            exclude_link = False
            for j in exlusion_list:
                if j in link:
                    exclude_link = True
                    break
            if exclude_link:
                continue
            else:
                if is_root_url(link):
                    parsed_url = urlparse(link)
                    if not parsed_url.scheme or parsed_url.scheme == "":
                        link = f"https://{link}"
                    lst.append(link)
        
        # Find the URL with the most keyword matches
        max_matches = 0
        for url in lst:
            matches = scrape_and_check_keywords(url, company_name)
            print(f"Keyword matches for {url}: {matches}")
            if matches > max_matches:
                max_matches = matches
                website_url = url
    except TimeoutException:
        print("Page load timed out after 60 seconds")
    except WebDriverException as e:
        do_log(e)
    return website_url
    
def search_engine_scraping(company):
    company_name = company
    company_name = company_name.split("·")[0]
    for ch in ["/", ",", "|", ".", "?", " ", "-"]:
        if ch in company:
            company = company.replace(ch, "+")
    if "&" in company:
        company = company.replace("&", "and")
    
    website_urls_lst = [
        "https://www.google.com/search?q="
        + str(company)
        + "",
        "https://duckduckgo.com/?q=" + str(company) + "&ia=web",
        "https://swisscows.com/en/web?query=" + str(company) + "",
        "https://www.ecosia.org/search?method=index&q="
        + str(company)
        + "",
        "https://www.startpage.com/do/search?query="
        + str(company)
        + "&lui=english",
        "https://you.com/search?q="
        + str(company)
        + "&source=web",
        "https://search.brave.com/search?q="
        + str(company)
        + "&source=web",
        "https://yandex.ru/search/?text="
        + str(company)
        + "&ia=web&lr=112509",
        "https://search.yahoo.com/search?p="
        + str(company)
        + "&ia=web",
        "https://www.bing.com/search?q="
        + str(company)
        + "&ia=web",
    ]
    
    i=0
    website = None
    while i < 3:
        try:
            url = random.choice(website_urls_lst)
            do_log(url)
            website = getWebsite(url, company_name)
            print(f"Website on while loop: {website}")
            do_log("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
            if website != None:
                break
            i += 1
        except Exception as e:
            do_log("Error during scraping:", e)
            i += 1

    return website



def main():
    website_data_api=f"{BASE_URL}/api/comapany-website?count=5"
    r = requests.get(website_data_api)
    sites=json.loads(r.text)
    do_log(len(sites))
    if len(sites) == 0:
        do_log('sleeping for 2 minutes')
        time.sleep(120)

    for site in sites:
        ## Get Company URL from the company_details, if does not exists get it from search engine
        
        url = None
        ## check if company_details_exists
        if 'company_detail' in site:
            ## check if company company details is not null
            if site['company_detail'] != None:
                ## check if website exists
                if site['company_detail']['website'] != None and site['company_detail']['website'] != '':
                    url = site['company_detail']['website'].strip()
        
        id = site['id']
        if url == None:
            url = search_engine_scraping(site['name'])
            try:
                data = website_scraping.scrape_main(url, id)
                data['source'] = 'search_engine'
                api_update.post_company_website_data(data)
            except Exception as e:
                do_log(e)
                data = {'id':id, 'crawl_status':2}
                api_update.post_company_website_data(data)
        else:
            ## website already exists
            try:
                data = website_scraping.scrape_main(url, id)
                data['source'] = 'origin'
                api_update.post_company_website_data(data)
            except Exception as e:
                do_log(e)
                data = {'id':id, 'crawl_status':2}
                api_update.post_company_website_data(data)


def get_run_id(token):
    global run_id
    run_id = 0
    
def do_kill():
    run_time = time.time() - start
    do_log("Runtime: ",run_time)
    if run_time > 6*60*60:
        do_log("Run COmpleted you can close now.")
        return True
    return False

def increase_run_count(run_id):
    x = requests.post(f"{BASE_URL}/api/increment-run-count", json={'id':run_id}, headers={"auth":token})
    do_log(x.text)

if __name__ == "__main__":
    driver = webdriver.Edge(options=options)
    driver.set_page_load_timeout(60)
    fail_count = 0
    do_log(run_id)
    while True:
        # main()
        try:
            main()
            fail_count = 0
            increase_run_count(run_id)
            # search_engine_scraping("Banao Technology")
        except Exception as e:
            do_log(f"Error on main function: ",e)
            fail_count += 1
            if fail_count > 5:
                do_log("Check your network connection or contact support")
                break
            
        if do_kill():
            break
    
    # data = website_scraping.scrape_main("https://www.axisbank.com", 0)
    