# using BeautifulSoup and Selenium to scrape seller information such as name, address, 
# mobile number, etc., from IndiaMart. The script retrieves the HTML content, parses it, 
# extracts links to individual seller pages, and then extracts data from those pages. 
# The extracted data is stored in a dictionary and then saved to a JSON file named data.json.


from bs4 import BeautifulSoup
import requests
from selenium import webdriver
import json
from log_generator import generate_log
from datetime import date, datetime

# Log file name
current_date = date.today()
current_time = datetime.now().strftime("%H:%M").replace(":", ",")
LOG_FILE = f"{current_time} {current_date} IndiaMartScraper"

def do_log(*message):
    """
    Logs the given message and writes it to a log file.

    Args:
        message: Variable number of message components to be logged.
    """
    output_data = ''
    for i in message:
        output_data += f"{i} "
    print(output_data)
    generate_log(output_data, LOG_FILE)



def get_SellerName(soup):
    """
    Extracts the seller name from the BeautifulSoup object.

    Args:
        soup: BeautifulSoup object representing the HTML content of the webpage.

    Returns:
        str: Seller name if found, otherwise an empty string.
    """
    try:
        seller_name = soup.find("a", attrs={"class": 'color6 pd_txu bo'}).string.strip()
    except AttributeError:
        seller_name = ''

    return seller_name


def get_SellerLink(soup):
    """
    Extracts the seller's page link from the BeautifulSoup object.

    Args:
        soup: BeautifulSoup object representing the HTML content of the webpage.

    Returns:
        str: Seller's page link if found, otherwise an empty string.
    """
    try:
        link = soup.find("a", attrs={'class': 'color6 pd_txu bo'})
        link = link.get('href')
    except AttributeError:
        link = ''

    return link


def get_DealerName(soup):
    """
    Extracts the dealer name from the BeautifulSoup object.

    Args:
        soup: BeautifulSoup object representing the HTML content of the webpage.

    Returns:
        str: Dealer name if found, otherwise an empty string.
    """
    try:
        dealer_name = soup.find("div", attrs={'id': 'supp_nm'}).string.strip()
    except AttributeError:
        dealer_name = ''

    return dealer_name


def get_SellerAddress(soup):
    """
    Extracts the seller's address from the BeautifulSoup object.

    Args:
        soup: BeautifulSoup object representing the HTML content of the webpage.

    Returns:
        str: Seller's address if found, otherwise an empty string.
    """
    try:
        address = soup.find("span", attrs={'class': 'color1 dcell verT fs13'}).text.strip()
    except AttributeError:
        address = ''

    return address


def get_Direction(soup):
    """
    Extracts the direction link from the BeautifulSoup object.

    Args:
        soup: BeautifulSoup object representing the HTML content of the webpage.

    Returns:
        str: Direction link if found, otherwise an empty string.
    """
    try:
        direction = soup.find("a", attrs={'class': 'color3 pd_txu gtdir on'})
        direction = direction.get('href')
    except AttributeError:
        direction = ''

    return direction


def get_MobileNumber(soup):
    """
    Extracts the mobile number from the BeautifulSoup object.

    Args:
        soup: BeautifulSoup object representing the HTML content of the webpage.

    Returns:
        str: Mobile number if found, otherwise an empty string.
    """
    try:
        mobileNumber = soup.find("input", attrs={'id': 'contact_number'})
        mobileNumber = str("+91-")+mobileNumber.get('value')
    except AttributeError:
        mobileNumber = ''

    return mobileNumber



if __name__ == '__main__':

    # add your user agent
    HEADERS = ({'User-Agent':'', 'Accept-Language': 'en-US, en;q=0.5'})

    # category
    # category = input()

    # The webpage URL
    # URL = "https://dir.indiamart.com/search.mp?ss=" + str(category).replace(' ', '+') + "&prdsrc=1&res=RC3"
    URL = "https://dir.indiamart.com/search.mp?ss=battery+operated+forklift&prdsrc=1&res=RC3"


    # Create a new Chrome webdriver instance
    driver = webdriver.Chrome()

    driver.get(URL)

    # Get the full HTML source of the page after it has fully loaded
    html_source = driver.page_source

    # Close the webdriver
    driver.quit()

    # Create a Beautiful Soup object with the HTML source
    soup = BeautifulSoup(html_source, "html.parser")

    # Continue parsing or extracting data using Beautiful Soup
    # For example, find all 'a' tags with class "prd-name"
    product_links = soup.find_all("a", class_="prd-name")

    # Process the extracted data as needed
    # for link in product_links:
    #     print(link['href'])
    links_list = []

    # Loop for extracting links from Tag Objects
    for link in product_links:
        links_list.append(str(link.get('href')).split(' ')[0])
    

    # Dictionary for storing all details and then creating a CSV file
    d = {"Seller Name": [], "Seller's Page Link": [], "Dealer Name": [], "Seller's Address": [], "Directions":[], "Mobile Number":[]} 
    i = 0

    # Loop for extracting product details from each link
    for link in links_list:
        do_log("Running for product "+str(i+1))

        new_webpage = requests.get(link, headers=HEADERS)
        new_soup = BeautifulSoup(new_webpage.content, "html.parser")

        i += 1

        # Function calls to display all necessary product information
        d["Seller Name"].append(get_SellerName(new_soup))
        d["Seller's Page Link"].append(get_SellerLink(new_soup))
        d["Dealer Name"].append(get_DealerName(new_soup))
        d["Seller's Address"].append(get_SellerAddress(new_soup))
        d["Directions"].append(get_Direction(new_soup))
        d["Mobile Number"].append(get_MobileNumber(new_soup))
        
    with open('data.json', 'w') as f:
        json.dump(d, f)


