#  has functions to set up a logger and generate logs. The logs are written to a file with a specified format.

import logging

def setup_logger(log_file):
    # Create a logger
    logger = logging.getLogger('my_logger')
    logger.setLevel(logging.DEBUG)

    # Create a file handler to write log messages to the file
    file_handler = logging.FileHandler(log_file, encoding='utf-8')
    file_handler.setLevel(logging.DEBUG)

    # Create a formatter to specify the log message format
    formatter = logging.Formatter('%(asctime)s  %(message)s')
    file_handler.setFormatter(formatter)

    # Add the file handler to the logger
    logger.addHandler(file_handler)

    return logger

def generate_log(message, file):
    """
    Generates a log message and writes it to a log file.

    Args:
        message (str): The message to be logged.
        file (str): The name of the log file.

    Returns:
        None
    """
    try:
        log_file = f'IndiaMart_Scraping/{file}.log'
        logger = setup_logger(log_file)
    except:
        log_file = file
        logger = setup_logger(log_file)

    logger.info(message)