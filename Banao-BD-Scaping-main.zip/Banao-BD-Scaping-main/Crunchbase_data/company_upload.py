import mysql.connector
import csv
from datetime import datetime


mydb = mysql.connector.connect(
  host="scrapdb2.crbyejbc1y6i.ap-south-1.rds.amazonaws.com",
  user="root",
  password="S9K1hfKuWzG3dxt1",
  database="Banaobd"
)

mycursor = mydb.cursor()

# openung the file with encoding UTF-8 help us to avoid errors like charracter errors etc
company_file = open('organizations.csv', 'r', encoding='utf-8')
companies = csv.reader(company_file)
count = 0
data = {}

companies_list = []
# for loop to traverse through each row in the Sheet
for company in companies:
    if count == 0:
        count+=1
        continue
    
    print(count)  
    
    # retriving the data from the CSV file and storing it in a dictionary
    print("id->" , company[0])
    name = str(company[1])
    C_type = str(company[2])
    url = str(company[4]).split('?')[0]
    source = "Crunchbase"
    domain = str(company[5])
    website = str(company[6])
    facebook = str(company[8])
    twitter = str(company[9])
    linkedin = str(company[10])
    location = str(company[12]) + " " + str(company[13]) + " " + str(company[14])
    description = str(company[15])
    time = str(datetime.now())
    print(time)
    
    # inserting to the COMPANY DETAILS Table
    sql = "insert into companies (url, name, source, createdAt, updatedAt) values (%s, %s, %s, %s, %s)"
    val = (url, name, source, time, time)
    print(data)
    
    # try/except block to check if the data is present in the database and if present then continue with the loop
    try:
      mycursor.execute(sql, val)
      mydb.commit()
      print(f"{name} has been added to the COMPANIES table")
    except:
      # print("exception table")
      mycursor.execute(f"""UPDATE companies SET name="{name}", source="{source}", updatedAt="{time}" WHERE url="{url}" """)
      mydb.commit()
      
      print("Company already exists in COMAPNIES table. So update Initiated")
      link = url
      
      
      c_sql = f"select * from companies where url ='{link}'; "
      mycursor.execute(c_sql)
      rows = mycursor.fetchall()
      last_c_id = rows[0][0]
      print(last_c_id, "Updated IDDD ")
    
    # to get the id of the last inserted data in the table
    company_id = mycursor._last_insert_id
    # company_id 
    print(company_id)    
    
    # inserting to the COMPANY DETAILS Table
    
    sql_CD = "insert into company_details (description, domain, website, companyType, location, company_id, createdAt, updatedAt, name, linkedin, facebook, twitter) values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
    val_CD = (description, domain, website, C_type, location, company_id, time, time, name, linkedin, facebook, twitter)
    
    # try/except block to check if the data is present in the database and if present then continue with the loop
    try:
      # print('try')
      mycursor.execute(sql_CD, val_CD)
      # print("before commit")
      mydb.commit()
      print(f"{name} with company id {company_id} has been added to the COMPANy_DETAILS table")
    except:
      # print("exception 2")
      mycursor.execute(f"""UPDATE company_details SET description="{description}", domain="{domain}",website="{website}", companyType="{C_type}", location="{location}", updatedAt="{time}", name="{name}", linkedin="{linkedin}", facebook="{facebook}", twitter="{twitter}"  WHERE company_id="{last_c_id}"; """)
      mydb.commit()
      print(f"Company already exists in COMPANY_DETAILS table. {last_c_id} So update ha been Initiated")
    
    if count == 20:
      break
    
    print()
    count +=1
