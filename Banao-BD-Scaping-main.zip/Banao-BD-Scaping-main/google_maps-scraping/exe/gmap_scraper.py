from selenium import webdriver
import time
from selenium.webdriver.common.by import By
from selenium.webdriver import ActionChains
from selenium.webdriver.common.actions.wheel_input import ScrollOrigin
import requests
import os
from log_generator import generate_log


prefs = {"profile.default_content_setting_values.notifications": 2}
options = webdriver.EdgeOptions()
options.use_chromium = True
options.add_experimental_option("excludeSwitches", ["ignore-certificate-errors"])
options.add_experimental_option("prefs", prefs)
options.add_experimental_option("excludeSwitches", ["enable-logging"])
options.add_argument('--no-sandbox')
options.add_argument("--disable-extensions")
options.add_argument("--disable-gpu")
options.add_argument("--disable-dev-shm-usage")
options.add_argument("--disable-infobars")
options.add_argument("--log-level=1")
options.add_argument("--headless")


os.system("cls")
print("Version:23.7.31 \nGreetings from Banao Technologies!\n"
"Please enter your Banao Token in the designated fields and relax while our program extracts the "
"necessary data for you. We respect your privacy and want to assure you that any data entered by you will be not stored in any way."
"Please note that this program is designed solely for the purpose of aiding Banao Technologies, and we strongly advise against using it for any other purpose.\n\n"
"NOTE : This script will take 6 hours to complete.")

token = input("Token > ")
start = time.time()
BASE_URL = "https://bbd.atg.party"
# BASE_URL = "http://127.0.0.1:5000"

# Formats and prints log messages to the console, as well as logs them using 
def do_log(*message):
    output_data = ''
    for i in message:
        output_data += f"{i} "
    print(output_data)
    generate_log(output_data)

# Fetches a unique run ID for the current session from a server API.
def get_run_id(token):
    res = requests.post(f"{BASE_URL}/api/create-entry-of-userstats", json={'token':token, 'extension':'gmap_exe'})
    if res.status_code != 200:
        return None , res.text
    return res.json()['id'] , None


run_id, err =  get_run_id(token)
if err:
    do_log("Wrong Token \n")
    input("Press enter to close and try again")
    exit()

# Constructs the Google Maps search link with the provided parameters.
# Initializes a Selenium webdriver with Edge browser options.
# Navigates to the constructed search link.
# Scrolls down the page to load more results.
# Extracts details such as name, rating, number of ratings, category, address, status, and website link from the search results.
# Returns a list of dictionaries containing the extracted details for each business.
def scrape(business_name, lat, lon):
    # Construct the Google Maps search link based on business name, latitude, and longitude
    link = f"https://www.google.com/maps/search/{business_name}/@{lat},{lon},16z"
    
    # Initialize a Chrome webdriver instance with specified options
    browser = webdriver.Edge(options=options)
    
    # Navigate to the constructed search link
    browser.get(link)
    
    # Pause execution to allow time for the page to load
    time.sleep(3)
    
    # Initialize ActionChains for performing browser actions
    action = ActionChains(browser)
    
    # Initialize a variable to track the number of times the loop has executed
    s_break = 0
    
    # Initialize an empty list to store details of businesses
    details_list = []
    
    try:
        # Loop until a break condition is met or an exception occurs
        while True:
            try:
                # Check if the maximum number of attempts to scroll has been reached
                if s_break > 10:
                    do_log("Max timeout reached ")
                    a = browser.find_elements(By.CLASS_NAME, "hfpxzc")
                    break
                
                # Find elements with the specified class name
                a = browser.find_elements(By.CLASS_NAME, "hfpxzc")
                
                # Attempt to perform actions within a try-except block
                try:
                    # Increment the attempt count
                    s_break += 1
                    
                    # Check for the presence of a specific element
                    browser.find_element(By.CLASS_NAME, "PbZDve")
                    
                    # Create a scroll origin object
                    scroll_origin = ScrollOrigin.from_element(a[-1])
                    
                    # Perform a scroll action
                    action.scroll_from_origin(scroll_origin, 0, 1000).perform()
                    
                    # Pause execution to allow time for the page to load
                    time.sleep(2)
                    
                    # Exit the loop
                    break
                except:
                    # Handle exceptions and continue execution
                    a = browser.find_elements(By.CLASS_NAME, "hfpxzc")
                    if len(a) > 0:
                        try:
                            scroll_origin = ScrollOrigin.from_element(a[-1])
                            action.scrolopen_statusl_from_origin(
                                scroll_origin, 0, 1000).perform()
                            time.sleep(2)
                        except:
                            break
                    else:
                        break
                a = browser.find_elements(By.CLASS_NAME, "hfpxzc")
            except:
                pass
        
        # Find elements containing business details
        names = browser.find_elements(By.CLASS_NAME, 'bfdHYd.Ppzolf.OFBs3e')
        
        # Iterate over each element to extract details
        for name in names:
            details = name.text.split("\n")
            try:
                b_name = details[0]
            except:
                b_name = None
            try:
                rating = float(details[1].split('(')[0])
            except:
                rating = None
            try:
                num_rating = float(details[1].split('(')[1].replace(')', ''))
            except:
                num_rating = None
            try:
                b_type = details[2].split("·")[0].rstrip()
            except:
                b_type = None
            try:
                b_add = details[2].split("·")[1].lstrip()
            except:
                b_add = None
            try:
                b_status = details[3]
            except:
                b_status = None
            try:
                website_links = name.find_element(By.CLASS_NAME, "Rwjeuc")
                links = website_links.find_element(By.TAG_NAME, "a")
                b_website = links.get_attribute("href")
            except:
                b_website = None
            
            # Construct a dictionary with extracted details
            b_data = {
                "name": b_name,
                "gmap_rating": rating,
                "gmap_num_ratings": num_rating,
                "category": b_type,
                "gmap_address": b_add,
                "gmap_status": b_status,
                "website": b_website
            }
            
            # Append the dictionary to the details list
            details_list.append(b_data)
    except Exception as e:
        # Log any exceptions that occur within the function
        do_log(f"Error occurred in the 'scrape()' function: {e}")
    finally:
        # Close the browser instance
        browser.quit()

    # Return the list of extracted details
    return details_list


# Sends a GET request to the API endpoint with the authentication token.
# Parses the response JSON to extract the coordinates data.
# Returns the coordinates data.
def get_coordinates():
    try:
        res = requests.get(f"{BASE_URL}/gmap/api/get-coordinate-to-scrape?token={token}", headers={"auth": token, "api": '1'})
        raw = res.json()
        return raw['data']
    except requests.exceptions.RequestException as e:
        do_log(f"Error occurred while fetching coordinates: {e}")
        return []
    
# Sends a POST request to the server API endpoint with the run ID.
# Logs the response.
def increase_run_count(run_id):
    x = requests.post(f"{BASE_URL}/api/increment-run-count", json={'id':run_id}, headers={"auth":token})
    do_log(x.text)

# Sends a POST request to the server API endpoint with the data and co_id.
# Logs the success or failure of the request.
def post_data(data, co_id):
    try:
        res = requests.post(f"{BASE_URL}/gmap/api/post-gmap-data", json={'data': data, 'co_id': co_id}, headers={"auth": token, "api": '1'})
        if res.status_code == 200:
            do_log("Successfully saved")
        else:
            do_log(f"Something went wrong when saving: {res.text}")

    except requests.exceptions.RequestException as e:
        do_log(f"Error occurred while posting data: {e}")
    
#  Main function orchestrating the scraping process.
def main():
    try:
        res = get_coordinates()
        co_time = time.time()
        for co in res:
            do_log("Currently scraping", co['category'], co['lat'], co['long'], co['id'])
            data = scrape(co['category'], co['lat'], co['long'])
            post_data(data, co['id'])
        
        do_log(f'time taken for {len(res)}: {time.time()-co_time}')
    
    except Exception as e:
        do_log(f"Error in main function: {e}")

# Calculates the runtime of the program.
# Logs the runtime.
# Returns True if the runtime exceeds 6 hours, otherwise False.
def do_kill():
    run_time = time.time() - start
    do_log("Runtime: ",run_time)
    if run_time > 6*60*60:
        do_log("Run Completed you can close now.")
        return True
    return False


# nitializes variables and settings.
# Logs the run ID obtained.
# Runs the main() function in a loop.
# Handles exceptions and logs errors.
# Terminates the program if the runtime exceeds 6 hours or after encountering multiple failures.

if __name__ == "__main__":
    fail_count = 0
    do_log(run_id)
    while True:
        try:
            main()
            fail_count = 0
            increase_run_count(run_id)
        except Exception as e:
            do_log(f"Error on main function: ",e)
            fail_count += 1
            if fail_count > 5:
                do_log("Check your network connection or contact support")
                break
            
        if do_kill():
            break