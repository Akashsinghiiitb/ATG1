# Google Maps Scraping

This folder contains scripts for scraping business details from Google Maps, storing them in a database, and managing scraping tasks through a web interface.

## Contents

1. **GoogleMaps_API.py**: Python script providing a web interface for users to input location-related information, scrape business details from Google Maps, and store the data in a MySQL database.

2. **gmap_extention.py**: Script for monitoring and managing scraping tasks. It fetches unprocessed categories and coordinates from the database, initiates scraping for each coordinate, updates the database with the scraping status, and displays the progress and scraped data on the web interface.

3. **flask_api.py**: Script containing Flask routes for functionalities related to database creation, coordinate retrieval, data scraping from Google Maps, and data retrieval. It defines SQLAlchemy models for database tables and integrates Flask with Selenium for web scraping.

## Setup

1. **Installation**: Ensure you have Python installed on your system. Install the required packages using `pip install -r requirements.txt`.

2. **Database Setup**: Configure your database connection details in the scripts that interact with the database (`GoogleMaps_API.py`, `gmap_extention.py`, `flask_api.py`). Make sure the database is running and accessible.

3. **Running the Scripts**: Execute the scripts individually using Python. You may need to start the Flask server (`flask_api.py`) to interact with the web interface.

## Usage

1. **GoogleMaps_API.py**: Run this script to access the web interface for inputting location information and initiating the scraping process. Access the interface by visiting `http://localhost:9009` in your web browser.

2. **gmap_extention.py**: This script manages scraping tasks in the background. It fetches unprocessed categories and coordinates, initiates scraping, and updates the database. Run this script alongside the API script for automated scraping.

3. **flask_api.py**: Contains Flask routes for database management and data retrieval. Run this script to interact with the database and initiate scraping tasks through API calls.

## Note

Ensure compliance with Google Maps API Terms of Service and avoid overloading their servers with excessive scraping requests. Use the scripts responsibly and consider implementing rate limiting to avoid IP blocking.

