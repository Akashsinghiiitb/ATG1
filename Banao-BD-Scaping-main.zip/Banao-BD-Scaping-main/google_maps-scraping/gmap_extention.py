# This file serves as a dashboard for monitoring and managing scraping tasks. 
# It fetches unprocessed categories and coordinates from the database, 
# initiates scraping for each coordinate, updates the database with the scraping status,
# and displays the progress and scraped data on the web interface.


import requests as r
import mysql.connector
from datetime import datetime
from flask import Flask, render_template

app = Flask(__name__)



# This method is the handler for the root URL of the web application.
# It connects to a MySQL database and executes two SQL queries to fetch unprocessed or under-processing categories from the category table and coordinates from the coordinates table.
# It iterates over the fetched data and updates the status of categories to 'under processing' and coordinates to 1 (indicating that they are being processed).
# For each category-coordinate pair, it sends a GET request to a Flask endpoint (/GetDetails) with the category type, latitude, and longitude.
# After sending the request, it updates the status of the coordinates to 2 (indicating that they have been processed).
# It calculates the progress of scraping tasks by counting the number of coordinates in different status categories (0: unprocessed, 1: under processing, 2: completed).
# Finally, it retrieves business details from the business_details table and passes them, along with the progress data, to the 'index2.html' template for rendering.



@app.route('/')
def extract_details():
    mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="gmap"
        )

    mycursor = mydb.cursor()

    q1 = "select * from category where status = 'unprocessed' or status = 'under processing'"
    q2 = "select category, lat, longCoord from coordinates where status = 0 or status = 1"

    # Fetching all the data in coordinates table that needs to be scraped
    mycursor.execute(q1)
    my_result1 = mycursor.fetchall()

    # Fetching all the required data from category table
    mycursor.execute(q2)
    my_result2 = mycursor.fetchall()

    j = 1
    i = 1

    for row in my_result1:
        print("Running for category : "+str(i))
        q3 = f"UPDATE category SET status = 'under processing' WHERE id = {row[0]}"
        mycursor.execute(q3)
        mydb.commit()
        for col in my_result2:
            print("Running for category "+str(j)+"'s coordinates")
            if row[0] == col[0]:
                # update_time1 = datetime.now()
                q4 = f"UPDATE coordinates SET status = 1 WHERE category = {col[0]} and status < 2"
                mycursor.execute(q4)
                mydb.commit()
                b_type = row[2]
                lat = col[1]
                long = col[2]
                print(f'http://127.0.0.1:9009/GetDetails/{b_type}-{lat}-{long}')
                req_list = r.get(f'http://127.0.0.1:9009/GetDetails/{b_type}-{lat}-{long}')
                # update_time2 = datetime.now()
                q6 = f"UPDATE coordinates SET status = 2 WHERE category = {col[0]} and lat = {lat}"
                mycursor.execute(q6)
                mydb.commit()
                j += 1
            
            if j == 3:
                break
        if j == len(my_result2):
            q5 = f"UPDATE category SET status = 'completed' WHERE id = {row[0]}"
            mycursor.execute(q5)
            mydb.commit()
        if j == 3:
            break
        i += 1

    cursor = mydb.cursor(dictionary=True)

    cursor.execute("Select name, rating, num_rating, business_type, address, open_status, website_link, time_created from business_details")
    tasks = cursor.fetchall()

    cursor.execute("select status from coordinates")
    tot_st = cursor.fetchall()

    progress = []
    unPr = 0
    undrPr = 0
    com = 0

    for i in range(len(tot_st)):
        if(tot_st[i]["status"] == 0):
            unPr += 1
        elif(tot_st[i]["status"] == 1):
            undrPr += 1
        elif(tot_st[i]["status"] == 2):
            com += 1

    progress.append(unPr)
    progress.append(undrPr)
    progress.append(com)

    
    return render_template('index2.html', tasks = tasks, progress = progress)


if __name__ == '__main__':
    app.run(debug=True)
        
        
