# This script provides a web interface for users to input location-related information,
# scrape business details from Google Maps for specified locations,
# and store the scraped data in a MySQL database for further analysis or use.

from selenium import webdriver
import time
from selenium.webdriver.common.by import By
from selenium.webdriver import ActionChains
from selenium.webdriver.common.actions.wheel_input import ScrollOrigin
from geopy.geocoders import Nominatim
import numpy as np
from flask import Flask, render_template, request
from datetime import datetime
import mysql.connector

app = Flask(__name__)

# This method serves as the handler for the root URL of the web application.
# It attempts to connect to a MySQL database and creates four tables if they don't 
# exist (location, category, coordinates, and business_details).
# If the database connection fails or the tables already exist, it retrieves
# data from the location table and renders the 'index.html' template, passing the retrieved 
# locations to it.

@app.route('/')
def index():
    try:
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="gmap"
        )

        mycursor = mydb.cursor()

        mycursor.execute("CREATE TABLE `gmap`.`location` (`id` INT NOT NULL AUTO_INCREMENT,`name` VARCHAR(1000) NULL,`centre_lat` DOUBLE NULL,`centre_long` DOUBLE NULL,`chunk_width` FLOAT NULL,`chunk_length` FLOAT NULL,`createdAt` DATETIME NULL,PRIMARY KEY (`id`))")
        mycursor.execute("CREATE TABLE `gmap`.`category` (`id` INT NOT NULL AUTO_INCREMENT,`location` INT NULL,`category_name` VARCHAR(1000) NULL,`priority` INT NULL,`status` VARCHAR(500) NULL,`createdAt` DATETIME NULL,`updatedAt` DATETIME NULL,PRIMARY KEY (`id`),INDEX `Category_FK_idx` (`location` ASC) VISIBLE,CONSTRAINT `Category_FK`FOREIGN KEY (`location`)REFERENCES `gmap`.`location` (`id`)ON DELETE NO ACTION ON UPDATE NO ACTION)")
        mycursor.execute("CREATE TABLE `gmap`.`coordinates` (`id` INT NOT NULL AUTO_INCREMENT,`category` INT NULL,`lat` DOUBLE NULL,`longCoord` DOUBLE NULL,`status` INT NULL DEFAULT 0,`scraped_at` DATETIME NULL,PRIMARY KEY (`id`),INDEX `Coordinate_FK_idx` (`category` ASC) VISIBLE,CONSTRAINT `Coordinate_FK`FOREIGN KEY (`category`)REFERENCES `gmap`.`category` (`id`)ON DELETE NO ACTION ON UPDATE NO ACTION)")
        mycursor.execute("CREATE TABLE `gmap`.`business_details` (`id` INT NOT NULL AUTO_INCREMENT,`name` VARCHAR(1000) NULL,`rating` VARCHAR(10) NULL,`num_rating` VARCHAR(10) NULL,`business_type` VARCHAR(200) NULL,`address` VARCHAR(1000) NULL,`open_status` VARCHAR(1000) NULL,`website_link` VARCHAR(1000) NULL,`time_created` DATETIME NULL,PRIMARY KEY (`id`))")

        return render_template('index.html', locations = [])
    except:
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="root",
            database="gmap"
        )

        cursor = mydb.cursor()
        cursor.execute("SELECT * FROM location")
        locations = cursor.fetchall()
        cursor.close()
        return render_template('index.html', locations = locations)


# This method is invoked when form data is submitted to the '/get-location-category-coordinates' endpoint via a POST request.
# It retrieves form data such as category, location, radius, chunk width, chunk length, and priority.
# It uses the provided location to obtain latitude and longitude coordinates using the Geopy library.
# It calculates the latitude and longitude range based on the provided radius and chunk dimensions.
# It inserts the location, category, and coordinates data into their respective tables in the MySQL database.

@app.route('/get-location-category-coordinates', methods=['POST'])
def process_data():
        
    category = request.form.get('category')
    location = request.form.get('other_location')
    radius = eval(request.form.get('radius'))
    chunk_width = eval(request.form.get('chunk_width'))  
    chunk_length = eval(request.form.get('chunk_length'))
    priority = eval(request.form.get('priority'))

    query = location
    geolocator = Nominatim(user_agent="my-app-name")
    location = geolocator.geocode(query)
    center_lat, center_lon = location.latitude, location.longitude

    location_details = []
    category_details = []
    coordinate_details = []

    # Convert radius to degrees
    radius_degrees = radius / 111.32

   # Define the number of rows and columns in the matrix
    rows = chunk_length
    cols = chunk_width

    location_data = {
        "name": str(location),
        "centre_lat": center_lat,
        "centre_lon": center_lon,
        "chunk_width": rows,
        "chunk_length": cols,
        "time_created": str(datetime.now())
    }
    location_details.append(location_data)

    db = mysql.connector.connect(
        database="gmap", user="root", passwd="")
    cursor = db.cursor()

    # Run a MySQL command to insert elements into a table
    add_locData = ("INSERT INTO location"
                   "(name, centre_lat, centre_long, chunk_width, chunk_length, createdAt)"
                   "VALUES (%s, %s, %s, %s, %s, %s)")

    # Insert scraped data into database
    for item in location_details:
        values = tuple(item.values())
        cursor.execute(add_locData, values)

    db.commit()

    lastID_cat = cursor.lastrowid
    category_data = {
        "location": lastID_cat,
        "cat_name": category,
        "priority": priority,
        "status": "unprocessed",
        "created_at": str(datetime.now()),
        "updated_at": str(datetime.now())
    }
    category_details.append(category_data)

    # Run a MySQL command to insert elements into a table
    add_catData = ("INSERT INTO category"
                   "(location,category_name, priority, status, createdAt, updatedAt)"
                   "VALUES (%s, %s, %s, %s, %s, %s)")

    # Insert scraped data into database
    for item in category_details:
        values = tuple(item.values())
        cursor.execute(add_catData, values)

    db.commit()

    lastID_coord = cursor.lastrowid
    # Calculate the latitudes and longitudes of the matrix
    if rows>cols:
        col = rows
    else:
        rows = col

    latitudes = np.linspace(center_lat - radius_degrees,
                            center_lat + radius_degrees, rows)
    longitudes = np.linspace(center_lon - radius_degrees,
                             center_lon + radius_degrees, cols)

    for i in range(len(longitudes)):
        coordinate_data = {
            "category": lastID_coord,
            "lat": latitudes[i],
            "lon": longitudes[i],
            "status": 0,
            "scraped_at": str(datetime.now())
        }
        coordinate_details.append(coordinate_data)

    # Run a MySQL command to insert elements into a table
    add_coordData = ("INSERT INTO coordinates"
                     "(category, lat, longCoord, status, scraped_at)"
                     "VALUES (%s, %s, %s, %s, %s)")

    # Insert scraped data into database
    for item in coordinate_details:
        values = tuple(item.values())
        cursor.execute(add_coordData, values)

    db.commit()

    cursor.close()
    db.close()

    return "data added to tables successfully"


# This method is triggered when accessing the '/GetDetails/string:business_name-string:lat-string:lon' route.
# It scrapes business details from Google Maps based on the provided business name, latitude, and longitude.
# It uses Selenium to automate the scraping process, scrolling through the page to load more results if necessary.
# It extracts business details such as name, rating, number of ratings, business type, address, open status, and website link.
# It inserts the scraped business data into the business_details table in the MySQL database.


@app.route('/GetDetails/<string:business_name>-<string:lat>-<string:lon>')
def scrape(business_name, lat, lon):
    # Construct the Google Maps search link based on business name, latitude, and longitude
    link = f"https://www.google.com/maps/search/{business_name}/@{lat},{lon},16z"
    
    # Initialize a Chrome webdriver instance
    browser = webdriver.Chrome()
    
    # Navigate to the constructed search link
    browser.get(link)
    
    # Pause execution to allow time for the page to load
    time.sleep(3)
    
    # Initialize ActionChains for performing browser actions
    action = ActionChains(browser)
    
    # Initialize a variable to track the number of times the loop has executed
    s_break = 0
    
    # Initialize an empty list to store details of businesses
    details_list = []

    # Loop indefinitely until a break condition is met
    while True:
        try:
            # Check if the maximum number of attempts to scroll has been reached
            if s_break > 10:
                print("Max timeout reached ")
                a = browser.find_elements(By.CLASS_NAME, "hfpxzc")
                break
            
            # Find elements with the specified class name
            a = browser.find_elements(By.CLASS_NAME, "hfpxzc")
            
            # Attempt to perform actions within a try-except block
            try:
                # Increment the attempt count
                s_break += 1
                
                # Check for the presence of a specific element
                browser.find_element(By.CLASS_NAME, "PbZDve")
                
                # Create a scroll origin object
                scroll_origin = ScrollOrigin.from_element(a[-1])
                
                # Perform a scroll action
                action.scroll_from_origin(scroll_origin, 0, 1000).perform()
                
                # Pause execution to allow time for the page to load
                time.sleep(2)
                
                # Exit the loop
                break
            except:
                # Handle exceptions and continue execution
                a = browser.find_elements(By.CLASS_NAME, "hfpxzc")
                if len(a) > 0:
                    try:
                        scroll_origin = ScrollOrigin.from_element(a[-1])
                        action.scroll_from_origin(
                            scroll_origin, 0, 1000).perform()
                        time.sleep(2)
                    except:
                        break
                else:
                    break
            a = browser.find_elements(By.CLASS_NAME, "hfpxzc")
        except:
            pass
    
    # Find elements containing business details
    names = browser.find_elements(By.CLASS_NAME, 'bfdHYd.Ppzolf.OFBs3e')
    
    # Iterate over each element to extract details
    for name in names:
        details = name.text.split("\n")
        try:
            b_name = details[0]
        except:
            b_name = "none"
        try:
            rating = details[1].split('(')[0]
        except:
            rating = "No Reviews"
        try:
            num_rating = details[1].split('(')[1].replace(')', '')
        except:
            num_rating = "No Reviews"
        try:
            b_type = details[2].split("·")[0].rstrip()
        except:
            b_type = "none"
        try:
            b_add = details[2].split("·")[1].lstrip()
        except:
            b_add = "none"
        try:
            b_status = details[3]
        except:
            b_status = "none"
        try:
            website_links = name.find_element(By.CLASS_NAME, "Rwjeuc")
            links = website_links.find_element(By.TAG_NAME, "a")
            b_website = links.get_attribute("href")
        except:
            b_website = "None"
        
        # Construct a dictionary with extracted details
        b_data = {
            "name": b_name,
            "rating": rating,
            "num_ratings": num_rating,
            "category": b_type,
            "address": b_add,
            "status": b_status,
            "website": b_website,
            "time_created": str(datetime.now())
        }
        
        # Append the dictionary to the details list
        details_list.append(b_data)

    # Close the browser instance
    browser.quit()
    
    # Connect to MySQL database
    db = mysql.connector.connect(
        database="gmap", user="root", passwd="")
    
    # Create a cursor to execute SQL commands
    cursor = db.cursor(dictionary=True)

    # SQL command to insert elements into a table
    add_businessData = ("INSERT INTO business_details"
                        "(name, rating, num_rating, business_type, address, open_status, website_link, time_created)"
                        "VALUES (%s, %s, %s, %s, %s, %s, %s, %s)")

    # Insert scraped data into database
    for item in details_list:
        values = tuple(item.values())
        cursor.execute(add_businessData, values)

    # Commit changes to the database
    db.commit()
    
    # Close the cursor and database connection
    cursor.close()
    db.close()

    # Return success message
    return "data scraped successfully"



if __name__ == '__main__':
    app.run(debug=True, port=9009)
