import pika
import time
from utils.queue_worker.people_retriever_worker import push_link_to_temp
credentials = pika.PlainCredentials('server-node', 'v!FpR2Y!Hf$8th')
connection = pika.BlockingConnection(pika.ConnectionParameters('localhost',5672,'/', credentials, heartbeat=0))
channel = connection.channel()

def ack_message(channel, delivery_tag):
    """Note that `channel` must be the same pika channel instance via which
    the message being ACKed was retrieved (AMQP protocol constraint).
    """
    if channel.is_open:
        channel.basic_ack(delivery_tag)
    else:
        # Channel is already closed, so we can't ACK this message;
        # log and/or do something that makes sense for your app in this case.
        pass

def valid_related_callback(ch, method, properties, body):
    print(f" [valid-related] Received {body}")
    try:
        body = eval(body)
        print(body)
        push_link_to_temp(body['user_id'], "valid-related")
    except Exception as e:
        print(e)
    ack_message(ch, method.delivery_tag)

    
channel.basic_consume(queue='valid-related', on_message_callback=valid_related_callback, auto_ack=False)
# channel.basic_consume(queue='zaubacorp', on_message_callback=zaubacorp_callback, auto_ack=False)
# channel.basic_consume(queue='previously-used', on_message_callback=previously_used_callback, auto_ack=False)
channel.start_consuming()
