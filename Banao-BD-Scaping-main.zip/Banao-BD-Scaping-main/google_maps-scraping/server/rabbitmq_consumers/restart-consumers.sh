#!/bin/sh
for service; do systemctl restart rabbit-mq-consumer-valid-related rabbit-mq-consumer-previously-used rabbit-mq-consumer-zaubacorp; done
