import mysql.connector
from decouple import config



BBD_DB_USER = config("BBD_DB_USER")
BBD_DB_PASS=config("BBD_DB_PASS")
BBD_DB_DB=config("BBD_DB_DB")
BBD_DB_HOST=config("BBD_DB_HOST")
OPENAI_API_KEY=config("OPENAI_API_KEY")

mydb = mysql.connector.connect(
        host=BBD_DB_HOST,
        user=BBD_DB_USER,
        password=BBD_DB_PASS,
        database=BBD_DB_DB,)
print('connected to db')
def get_zaubacorp_people():
    mydb.reconnect()
    zc_cursor = mydb.cursor()
    sql_query = f"""
    SELECT 
        people.id, people.name, people.url, people.source, people_details.people_id, people_details.linkedin, people_details.email, people_details.position, people_details.skills, people_details.number, people_details.gender, people_details.website_link, people_details.connects, people_details.followers, people_details.about, people_details.experience 
        FROM  (SELECT 
            id, fetch_status 
            FROM people 
                where origin="google zaubacorp" 
                and url is not null 
                and is_invalid != 1 
            ) ppl 
            JOIN people ON people.id = ppl.id 
            LEFT JOIN people_details ON people.id = people_details.people_id 
            WHERE ppl.fetch_status=0 
        ORDER BY ppl.fetch_status ASC LIMIT 25;
    """
    zc_cursor.execute(sql_query)
    result = zc_cursor.fetchall()
    return result

def get_google_people():
    mydb.reconnect()
    zc_cursor = mydb.cursor()
    sql_query = f"""
    SELECT 
        people.id, people.name, people.url, people.source, people_details.people_id, people_details.linkedin, people_details.email, people_details.position, people_details.skills, people_details.number, people_details.gender, people_details.website_link, people_details.connects, people_details.followers, people_details.about, people_details.experience 
        FROM  (SELECT 
            id, fetch_status 
            FROM people 
                where origin="google" 
                and url is not null 
                and is_invalid != 1 
            ) ppl 
            JOIN people ON people.id = ppl.id 
            LEFT JOIN people_details ON people.id = people_details.people_id 
            WHERE ppl.fetch_status=0 
        ORDER BY ppl.fetch_status ASC LIMIT 25;
    """
    zc_cursor.execute(sql_query)
    result = zc_cursor.fetchall()
    return result

def get_valid_related_people():
    mydb.reconnect()
    vr_cursor = mydb.cursor()
    sql_query = f"""
    SELECT 
        people.id, people.name, people.url, people.source, people_details.people_id, people_details.linkedin, people_details.email, people_details.position, people_details.skills, people_details.number, people_details.gender, people_details.website_link, people_details.connects, people_details.followers, people_details.about, people_details.experience 
        FROM (SELECT 
            id, fetch_status 
            FROM people
                where origin="valid related" 
                and url is not null
            ) ppl 
            JOIN people ON people.id = ppl.id 
            LEFT JOIN people_details ON people.id = people_details.people_id 
            WHERE ppl.fetch_status=0 
        ORDER BY ppl.fetch_status ASC LIMIT 25;
    """
    vr_cursor.execute(sql_query)
    result = vr_cursor.fetchall()
    return result

def get_previously_used_people():
    mydb.reconnect()
    pu_cursor = mydb.cursor()
    sql_query = f"""
    SELECT 
        people.id, people.name, people.url, people.source, people_details.people_id, people_details.linkedin, people_details.email, people_details.position, people_details.skills, people_details.number, people_details.gender, people_details.website_link, people_details.connects, people_details.followers, people_details.about, people_details.experience 
        FROM (SELECT
            id, fetch_status 
            FROM people 
                where points > 99 
                and fetch_status=1
                and source != 'crunchbase'
            ) ppl 
            JOIN people ON people.id = ppl.id 
            LEFT JOIN people_details ON people.id = people_details.people_id 
         LIMIT 25;
    """
    pu_cursor.execute(sql_query)
    result = pu_cursor.fetchall()
    return result

def get_peoples_for_revalidation():
    print("Running Revalidation")
    mydb.reconnect()
    prof_rev_cursor = mydb.cursor()
    sql_query = f"""
    SELECT
        id, url, people_id
    FROM
        user_connection_details
    WHERE
        revalidation_status = 1
        and url IS NOT NULL
    LIMIT 5;
    """
    prof_rev_cursor.execute(sql_query)
    result = prof_rev_cursor.fetchall()
    print("Revalidation Done")
    return result

def insert_people_in_temp(values:str):
    print("Inserting in Temp Table")
    mydb.reconnect()
    temp_table_cursor = mydb.cursor()
    sql_query = f"""
    INSERT INTO linkdein_links_details (user_id, people_id, connection_sent, link, connection_id) VALUES {values.strip(', ')};
    """
    print(sql_query)
    temp_table_cursor.execute(sql_query)
    mydb.commit()
    print("Done Inserting")
    return True

def increase_people_fetch_status(ids:str):
    print("Increasing People Fetch Status")
    mydb.reconnect()
    people_table_cursor = mydb.cursor()
    sql_query = f"""
    UPDATE people SET fetch_status= fetch_status + 1 WHERE id IN ({ids.strip(', ')});
    """
    print(sql_query)
    people_table_cursor.execute(sql_query)
    mydb.commit()
    print("Done Increasing")
    return True

def update_revalidation_status(ids:str, revalidation_status):
    print("Updating Revalidation Status")
    mydb.reconnect()
    revalid_temp_table_cursor = mydb.cursor()
    sql_query = f"""
    UPDATE user_connection_details SET revalidation_status={revalidation_status} WHERE id IN {ids.strip(', ')};
    """
    print(sql_query)
    revalid_temp_table_cursor.execute(sql_query)
    mydb.commit()
    print("Done Updating")
    return True

## To update linkedin_id for one row
def update_linkedin_id(id, linkedin_id):
    print("Updating Linkedin Id")
    mydb.reconnect()
    people_linkedin_id_cur = mydb.cursor()
    sql_query = f"""
    UPDATE people SET linkedin_id = '{linkedin_id}' WHERE id = {id};
    """
    print(sql_query)
    people_linkedin_id_cur.execute(sql_query)
    mydb.commit()
    print("Done Updating")
    return True

## To find the people_id by linkedin_id
def find_people_id_by_linkedin_id(linkedin_id):
    print("Finding People Id")
    mydb.reconnect()
    people_id_cur = mydb.cursor()
    sql_query = f"""
    SELECT id FROM people WHERE linkedin_id = '{linkedin_id}';
    """
    print(sql_query)
    people_id_cur.execute(sql_query)
    result = people_id_cur.fetchall()
    print("Done Finding")
    return result

## To update people_id in user_connection_details for one row
def update_people_id_in_user_connection_details(id, people_id):
    print("Updating People Id")
    mydb.reconnect()
    people_id_connection_details_cur = mydb.cursor()
    sql_query = f"""
    UPDATE user_connection_details SET people_id = {people_id} WHERE id = {id};
    """
    print(sql_query)
    people_id_connection_details_cur.execute(sql_query)
    mydb.commit()
    print("Done Updating")
    return True

## To update people_id in user_invitation_details for one row
def update_people_id_in_user_invitation_details(id, people_id):
    print("Updating People Id")
    mydb.reconnect()
    people_id_invitation_details_cur = mydb.cursor()
    sql_query = f"""
    UPDATE user_invitation_details SET people_id = {people_id} WHERE id = {id};
    """
    print(sql_query)
    people_id_invitation_details_cur.execute(sql_query)
    mydb.commit()
    print("Done Updating")
    return True

def get_company_by_linkedin_url(linkedin_url):
    print("Finding Company Id")
    mydb.reconnect()
    company_id_cur = mydb.cursor()
    sql_query = f"""
    SELECT id FROM companies WHERE url like '{linkedin_url}%';
    """
    print(sql_query)
    company_id_cur.execute(sql_query)
    result = company_id_cur.fetchall()
    print("Done Finding")
    return result

def get_company_details_by_linkedin_url(linkedin_url):
    print("Finding Company Id")
    mydb.reconnect()
    company_details_id_cur = mydb.cursor()
    sql_query = f"""
    SELECT company_id FROM company_details WHERE linkedin like '{linkedin_url}%';
    """
    print(sql_query)
    company_details_id_cur.execute(sql_query)
    result = company_details_id_cur.fetchall()
    print("Done Finding")
    return result

def save_company(company_name, linkedin_url):
    print("Saving Company")
    mydb.reconnect()
    company_save_cur = mydb.cursor()
    sql_query = f"""
    INSERT INTO companies (name, url, priority) VALUES ('{company_name}', '{linkedin_url}', 500);
    """
    print(sql_query)
    company_save_cur.execute(sql_query)
    mydb.commit()
    print("done saving")
    return get_company_by_linkedin_url(linkedin_url)

def update_company_priority(company_id, priority):
    print("Updating Company Priority")
    mydb.reconnect()
    company_priority_cur = mydb.cursor()
    sql_query = f"""
    UPDATE companies SET priority = {priority} WHERE id = {company_id};
    """
    print(sql_query)
    company_priority_cur.execute(sql_query)
    mydb.commit()
    print("Done Updating")
    return True

def save_works_in(company_id, people_id, designtation, status):
    print("Saving worksIns")
    mydb.reconnect()
    works_in_save_cur = mydb.cursor()
    sql_query = f"""
    INSERT INTO worksIns (company_id, people_id, Designation, presently) VALUES ({company_id}, {people_id}, '{designtation}', {status});
    """
    print(sql_query)
    works_in_save_cur.execute(sql_query)
    mydb.commit()
    print("done saving")
    return True


def find_works_ins(people_id, company_id):
    print("Finding worksIns")
    mydb.reconnect()
    works_in_find_cur = mydb.cursor()
    sql_query = f"""
    SELECT * FROM worksIns WHERE people_id = {people_id} AND company_id = {company_id};
    """
    print(sql_query)
    works_in_find_cur.execute(sql_query)
    result = works_in_find_cur.fetchall()
    print("Done Finding")
    return result

