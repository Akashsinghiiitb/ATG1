## This file is to pulish messages from inside of the Rabbit MQ consumer

import pika

credentials = pika.PlainCredentials('server-node', 'v!FpR2Y!Hf$8th')
# credentials = pika.PlainCredentials('guest', 'guest')
connection = pika.BlockingConnection(pika.ConnectionParameters('localhost',5672,'/', credentials, heartbeat=0))
channel = connection.channel()
channel.queue_declare(queue='linkedin-id-gen', durable=True)


def publish_people_id_for_link_gen(body:str):
    channel.basic_publish(exchange='', routing_key='linkedin-id-gen', body=body)

