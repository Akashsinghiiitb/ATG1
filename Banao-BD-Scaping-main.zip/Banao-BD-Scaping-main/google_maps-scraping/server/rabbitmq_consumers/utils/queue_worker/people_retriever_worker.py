from raw_queries.people_queries import get_valid_related_people, get_previously_used_people,\
    get_zaubacorp_people, get_google_people, get_peoples_for_revalidation, insert_people_in_temp, \
        increase_people_fetch_status, update_revalidation_status
        
from utils.queue_worker.linkedin_id_gen import batch_extract_linkedin_id_from_url
        
def push_link_to_temp(user_id, data_source):
    values_to_push_into_temp = ""
    people_ids_to_increase_fetch_status = ""
    connection_ids_to_update_revalidation_status = ""
    print("Starting Query")
    if data_source == 'valid-related':
        peoples = get_valid_related_people()
    elif data_source == 'previously-used':
        peoples = get_previously_used_people()
    elif data_source == 'zaubacorp':
        peoples = get_zaubacorp_people()
    elif data_source == 'google':
        peoples = get_google_people()
    else:
        peoples = None
    print("query finished")
    people_dict = []
    if peoples:
        for people in peoples:
            people_id = people[0]
            people_url = people[2]
            values_to_push_into_temp = values_to_push_into_temp + f"({user_id},{people_id}, 0, '{people_url}', null), "
            people_ids_to_increase_fetch_status = people_ids_to_increase_fetch_status + f"{people_id}, "
            people_dict.append({'id':int(people_id), 'url':people_url})
        rev_peoples = get_peoples_for_revalidation()
        for people in rev_peoples:
            connection_id = people[0]
            people_url = people[1]
            people_id = people[2]
            if people_id:
                values_to_push_into_temp = values_to_push_into_temp + f"({user_id},{people_id}, 1, '{people_url}', {connection_id}), "
                connection_ids_to_update_revalidation_status = connection_ids_to_update_revalidation_status + f"{connection_id}, "
                
        insert_people_in_temp(values_to_push_into_temp)
        increase_people_fetch_status(people_ids_to_increase_fetch_status)
        if connection_ids_to_update_revalidation_status != "":
            update_revalidation_status(connection_ids_to_update_revalidation_status, 2)
        
        batch_extract_linkedin_id_from_url(people_dict)
        
    else:
        print("There is no people")
        pass