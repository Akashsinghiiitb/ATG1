## This file to write utilities for find people_id and and save it to user_connection_details
import sys, os

sys.path.append(os.path.realpath(os.path.dirname(__file__)+"/../.."))

from raw_queries.people_queries import get_company_by_linkedin_url, get_company_details_by_linkedin_url, save_company, save_works_in, find_works_ins, update_company_priority

def save_experience(experience:dict):
    people_id = experience['people_id']
    company_name = experience['name']
    designation = experience['position']
    status = experience['status']
    linkedin_url = experience['url'].split('?')[0].strip('/')
    
    is_new_company = False
    company_id = get_company_by_linkedin_url(linkedin_url)
    if len(company_id) > 0:
        company_id = company_id[0][0]
        
    else:
        company_id = get_company_details_by_linkedin_url(linkedin_url)
        if len(company_id) > 0:
            company_id = company_id[0][0]
        else :
            company_id = save_company(company_name, linkedin_url)[0][0]
            is_new_company = True
    print(company_id)
    if not is_new_company:
        update_company_priority(company_id, 500)
    
    works_ins = find_works_ins(people_id, company_id)
    if len(works_ins) == 0:
        save_works_in(company_id, people_id, designation, status)
        
    
    
## For testing
# if __name__ == '__main__':
#     save_experience({ 'name':'Pacifica Companies', 'position':'General Manager Finance General Manager Finance', 'url':'https://www.linkedin.com/company/94058/', 'status':1, 'people_id':1 })