## This file to write utilities for find people_id and and save it to user_connection_details
import sys, os

sys.path.append(os.path.realpath(os.path.dirname(__file__)+"/../.."))

from utils.queue_worker.linkedin_id_gen import extract_linkedin_id_from_url
from raw_queries.people_queries import find_people_id_by_linkedin_id, update_people_id_in_user_connection_details, update_people_id_in_user_invitation_details

def find_and_update_linkedin_id(people:dict):
    connection_type = people['type']
    linkedin_id = extract_linkedin_id_from_url(people['url'])
    if connection_type == 'connection':
        if linkedin_id:
            people_id = find_people_id_by_linkedin_id(linkedin_id)
            if len(people_id) >0:
                update_people_id_in_user_connection_details(people['connection_id'], people_id[0][0])
                return True
    elif connection_type == 'invitation':
        if linkedin_id:
            people_id = find_people_id_by_linkedin_id(linkedin_id)
            if len(people_id) >0:
                update_people_id_in_user_invitation_details(people['invitation_id'], people_id[0][0])
                return True
    
    # update_people_id_in_user_connection_details(people['connection_id'], -5)
    
## For testing
if __name__ == '__main__':
    people = {'url':'https://www.linkedin.com/in/metin-kiri%C5%9F-83992938/', 'connection_id':576, "type": "connection"}
    # people = {'url':'https://www.linkedin.com/in/metin-kiri%C5%9F-83992938/', 'connection_id':576, "type": "invitation"}
    find_and_update_linkedin_id(people)