## This file to write utilities for extracting and pushing the linkedin id from the url
import sys, os

sys.path.append(os.path.realpath(os.path.dirname(__file__)+"/../.."))
from utils.rabbitmq_publisher.publisher_linkedin_id_gen import publish_people_id_for_link_gen
from raw_queries.people_queries import update_linkedin_id

def extract_linkedin_id_from_url(url:str):
    """
    Check if it is a linkedin peple url and then extract the id from it
    """
    if 'linkedin.com/in/' in url:
        return url.split('linkedin.com/in/')[1].split('/')[0]
    else:
        return None
    
def batch_extract_linkedin_id_from_url(urls:list):
    """
    urls: list :: [{'url': 'https://www.linkedin.com/in/rahulbhatia/', 'id':1}, {'url': 'https://www.linkedin.com/in/rahulbhatia/', 'id':2}]
    
    extract the id from the url and build the body to push to the queue
    """
    
    body_dict = []
    for url in urls:
        linkedin_id = extract_linkedin_id_from_url(url['url'])
        body_dict.append({'linkedin_id': linkedin_id, 'id': url['id']})
    
    publish_people_id_for_link_gen(str(body_dict))
    
def batch_update_linkedin_id(urls:list):
    for url in urls:
        update_linkedin_id(url['id'], url['linkedin_id'])
        
    
    

## For Testing
if __name__ == '__main__':
    # id = extract_linkedin_id_from_url('https://www.linkedin.com/in/rahulbhatia/')
    urls: list = [{'url':'https://www.linkedin.com/in/metin-kiri%C5%9F-83992938', 'id':1},{'url':'https://www.linkedin.com/in/asaad-johra-a130b8153','id':2},{'url':'https://www.linkedin.com/in/gisele-alves-pereira-85409255','id':3}]
    batch_extract_linkedin_id_from_url(urls)