import pika
import time
from utils.queue_worker.linkedin_id_find import find_and_update_linkedin_id
credentials = pika.PlainCredentials('server-node', 'v!FpR2Y!Hf$8th')
# credentials = pika.PlainCredentials('guest', 'guest')
connection = pika.BlockingConnection(pika.ConnectionParameters('localhost',5672,'/', credentials, heartbeat=0))
channel = connection.channel()

def ack_message(channel, delivery_tag):
    """Note that `channel` must be the same pika channel instance via which
    the message being ACKed was retrieved (AMQP protocol constraint).
    """
    if channel.is_open:
        channel.basic_ack(delivery_tag)
    else:
        # Channel is already closed, so we can't ACK this message;
        # log and/or do something that makes sense for your app in this case.
        pass

## RabbitMQ consumer
def linkedin_id_find_callback(ch, method, properties, body):
    print(f" [linkedin-id-find] Received {body}")
    try:
        body = eval(body)
        print(body)
        find_and_update_linkedin_id(body)
    except Exception as e:
        print(f"Error: {e}")
    ack_message(ch, method.delivery_tag)

channel.basic_consume(queue='linkedin-id-find', on_message_callback=linkedin_id_find_callback, auto_ack=False)
channel.start_consuming()
