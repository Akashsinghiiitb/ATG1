# This file contains a Flask application with several classes and methods designed to perform
#  various tasks related to data scraping, web serving, database management, 
# and machine learning.




import time
from geopy.geocoders import Nominatim
import numpy as np
import json
import pandas as pd
import threading as t
from flask import Flask, jsonify,redirect,url_for, request, render_template
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from flask_migrate import Migrate
from sqlalchemy.sql import func
from sqlalchemy.inspection import inspect
import json
import requests
from decouple import config
import random

#for cli command
import click
from flask.cli import with_appcontext
import pickle

# for zaubacorp
from bs4 import BeautifulSoup

#ML Script
from ml_utils import generate_1st_response


NODE_BASE_URL = config("NODE_BASE_URL")
USER = config("DB_USER")
PASS=config("PASS")
DB=config("DB")
HOST=config("HOST")

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = f"mysql://{USER}:{PASS}@{HOST}:3306/{DB}"
db = SQLAlchemy(app)
migrate = Migrate(app, db)


# Represents a geographical location with attributes like name, centre_lat, centre_long, etc.
class Location(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255))
    centre_lat = db.Column(db.Float(precision=53))
    centre_long = db.Column(db.Float(precision=53))
    chunk_width = db.Column(db.Float(precision=53))
    chunk_length = db.Column(db.Float(precision=53))
    radius = db.Column(db.Integer)
    createdAt = db.Column(db.DateTime, server_default=func.now())
    categories = db.relationship(
        "Category", 
        lazy='joined', 
        backref=db.backref("location")
    )
    
    def serialize(self):
        d = Serializer.serialize(self)
        del d['createdAt']
        del d['categories']
        return d
    
# Represents a category associated with a location, including attributes like category_name, priority, etc.
class Category(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    location_id = db.Column(db.Integer, db.ForeignKey('location.id'))
    category_name = db.Column(db.String(255))
    priority = db.Column(db.Integer)
    status = db.Column(db.String(255), default="pending")
    createdAt = db.Column(db.DateTime, server_default=func.now())
    updatedAt = db.Column(db.DateTime, onupdate=func.now())
    coordinates = db.relationship(
        "Coordinates", 
        lazy='joined', 
        backref=db.backref("category")
    )
    
    def serialize(self):
        d = Serializer.serialize(self)
        del d['createdAt']
        del d['updatedAt']
        scraped = Coordinates.query.filter_by(status=2, category_id=d['id']).count()
        unprocessed = Coordinates.query.filter_by(status=0, category_id=d['id']).count()
        processing = Coordinates.query.filter_by(status=1, category_id=d['id']).count()
        total = Coordinates.query.filter_by(category_id=d['id']).count()
        d['status_str'] = f"{scraped}/{processing}/{unprocessed}/{total}"
        return d


# Represents geographical coordinates associated with a category, including attributes like lat, long, etc.
class Coordinates(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    category_id = db.Column(db.Integer, db.ForeignKey('category.id'))
    lat = db.Column(db.Float(precision=53))
    long = db.Column(db.Float(precision=53))
    status = db.Column(db.Integer, default=0) # Definations: 0: Un processed, 1: processing, 2: completed
    scraped_at = db.Column(db.DateTime, onupdate=func.now())
    
    def serialize(self):
        d = Serializer.serialize(self)
        del d['scraped_at']
        d['category'] = d['category'].category_name
        return d
    

# BusinessDetails, MainPageLinks, TemporaryLink, DirectorsDetails, CrawlingStatus, CompanyDetail, and Query are additional models representing various types of data.
class BusinessDetails(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    category_id = db.Column(db.Integer, db.ForeignKey('category.id'))
    rating = db.Column(db.String(10))
    num_ratings = db.Column(db.String(10))
    business_type = db.Column(db.String(100))
    address = db.Column(db.String(200))
    open_status = db.Column(db.String(200))
    website = db.Column(db.String(200))
    mobile = db.Column(db.String(200))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return '<Business %r>' % self.name

class MainPageLinks(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    link = db.Column(db.String(255))
    status = db.Column(db.String(50))

class TemporaryLink(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    link = db.Column(db.String(255))
    status = db.Column(db.String(50))
    location = db.Column(db.String(20))

class DirectorsDetails(db.Model):
    id = db.Column(db.Integer,primary_key=True)
    din = db.Column(db.String(30), unique=True)
    name = db.Column(db.String(30))
    company = db.Column(db.String(255))
    profile_link = db.Column(db.String(50))
    designation = db.Column(db.String(30))
    appointment_date = db.Column(db.String(30))
    
class CrawlingStatus(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    current_city_index = db.Column(db.Integer)
    current_link_index = db.Column(db.Integer)

class CompanyDetail(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    cin = db.Column(db.String(50))
    company_name = db.Column(db.String(255))
    link = db.Column(db.String(255))
    company_status = db.Column(db.String(50))
    company_RoC = db.Column(db.String(50))
    company_regNo = db.Column(db.String(50))
    company_category = db.Column(db.String(250))
    company_sub_category = db.Column(db.String(50))
    company_class = db.Column(db.String(50))
    company_date_of_inc = db.Column(db.String(50))
    company_age = db.Column(db.String(50))
    company_activity = db.Column(db.String(255))
    company_no_of_members = db.Column(db.Integer)
    company_email = db.Column(db.String(255))
    company_address = db.Column(db.String(255))
    company_auth_capital = db.Column(db.String(50))
    company_paid_up_capital = db.Column(db.String(50))
    company_listing_status = db.Column(db.String(50))
    company_last_agm = db.Column(db.String(50))
    company_latest_balsheet = db.Column(db.String(50))

class SearchKeyword(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    owner = db.Column(db.String(255))
    keyword = db.Column(db.String(255))
    last_row_id = db.Column(db.Integer, default=0)
    
class Query(db.Model):
    # __tablename__ = 'queries'
    id = db.Column(db.Integer, primary_key=True)
    query_text = db.Column(db.Text, unique=True)
    status = db.Column(db.Integer, nullable=False, default=0)
    keyword_id = db.Column(db.Integer, db.ForeignKey('search_keyword.id'))

# with app.app_context():
#     db.create_all()


### Gmap Serializers and Views
    
## Serializers

class Serializer(object):

    def serialize(self):
        return {c: getattr(self, c) for c in inspect(self).attrs.keys()}

    @staticmethod
    def serialize_list(l):
        return [m.serialize() for m in l]


    
## INDEX PAGE FOR ADDING DATA   
@app.route('/gmap/add')
def index():
    locations = Location.query.all()
    return render_template('index.html', locations = locations)



##POst method for adding data
@app.route('/gmap/get-location-category-coordinates', methods=['POST'])
def process_data():
    old_location = request.form.get('location', type=int)

    location = request.form.get('other_location')
    category = request.form.get('category')
    priority = eval(request.form.get('priority'))

    #these are required only if old_location is negetive
    try:
        chunk_width = eval(request.form.get('chunk_width'))
        chunk_length = eval(request.form.get('chunk_length'))
        center_lat = eval(request.form.get('center_lat'))
        center_lon = eval(request.form.get('center_long'))
        radius = eval(request.form.get('radius'))
        
    except:
        pass

    if old_location < 0:
        if center_lat==None or center_lon == None:
            query = location
            geolocator = Nominatim(user_agent="my-app-name")
            location = geolocator.geocode(query)
            center_lat, center_lon = location.latitude, location.longitude
        location_ins = Location(name=location, centre_lat=center_lat, centre_long= center_lon, chunk_length=chunk_length, chunk_width=chunk_width, radius=radius)
        db.session.add(location_ins)
        db.session.commit()
        db.session.refresh(location_ins)
    else:
        location_ins = Location.query.get(old_location)

    # Convert radius to degrees
    radius_degrees = location_ins.radius / 111.32

    # Define the number of rows and columns in the matrix
    rows = int(location_ins.radius/location_ins.chunk_length)
    cols = int(location_ins.radius/location_ins.chunk_width)
        
    if "," in category:
        category_list = category.split(',')
        for i in range(len(category_list)):
            category_ins = Category(
                location_id=location_ins.id, category_name=category_list[i], priority=priority)
            db.session.add(category_ins)

            # Create coordinates for each category
            db.session.commit()
            db.session.refresh(category_ins)

            latitudes = np.linspace(location_ins.centre_lat - radius_degrees,
                                    location_ins.centre_lat + radius_degrees, int(rows))
            longitudes = np.linspace(location_ins.centre_long - radius_degrees,
                                     location_ins.centre_long + radius_degrees, int(cols))

            matrix = np.zeros((int(rows), int(cols), 2))

            for i in range(rows):
                for j in range(cols):
                    matrix[i, j, 0] = latitudes[i]
                    matrix[i, j, 1] = longitudes[j]
            lats = []
            lons = []

            for i in matrix:
                for j in i:
                    lats.append(j[0])
                    lons.append(j[1])
            for lat, lon in zip(lats, lons):
                coordinate_ins = Coordinates(
                    category_id=category_ins.id, lat=lat, long=lon)
                db.session.add(coordinate_ins)
    else:
        category_ins = Category(
            location_id=location_ins.id, category_name=category, priority=priority)
        db.session.add(category_ins)

        # Create coordinates for the single category
        db.session.commit()
        db.session.refresh(category_ins)

        latitudes = np.linspace(location_ins.centre_lat - radius_degrees,
                                location_ins.centre_lat + radius_degrees, int(rows))
        longitudes = np.linspace(location_ins.centre_long - radius_degrees,
                                 location_ins.centre_long + radius_degrees, int(cols))

        matrix = np.zeros((int(rows), int(cols), 2))

        for i in range(rows):
            for j in range(cols):
                matrix[i, j, 0] = latitudes[i]
                matrix[i, j, 1] = longitudes[j]
        lats = []
        lons = []

        for i in matrix:
            for j in i:
                lats.append(j[0])
                lons.append(j[1])
        for lat, lon in zip(lats, lons):
            coordinate_ins = Coordinates(
                category_id=category_ins.id, lat=lat, long=lon)
            db.session.add(coordinate_ins)

    db.session.commit()

    return "data added to tables successfully"



# This route (/gmap/edit-priority) is accessed via POST requests.
# It takes two parameters from the form data: category_id and new_priority.
# It finds the Category instance based on the category_id.
# It updates the priority attribute of the found Category instance with the new priority.
# Finally, it commits the changes to the database and redirects to the get_dashboard() route.
@app.route('/gmap/edit-priority', methods=['POST'])
def edit_priority():
    category_id = request.form.get('category_id')
    new_priority = request.form.get('new_priority')

    category = Category.query.get(category_id)
    category.priority = new_priority
    db.session.commit()

    return redirect(url_for('get_dashboard'))



# This route (/gmap/api/get_location_details) is accessed via GET requests.
# It expects an id parameter in the request's query string.
# It retrieves the Location instance from the database based on the provided id.
# It serializes the retrieved Location instance into JSON format and returns it.
@app.route("/gmap/api/get_location_details") #internal use: for dashboard to auto populate
def get_location_details():
    id = request.args.get("id")
    location = Location.query.get(id)
    
    return json.dumps(location.serialize())



# This route (/gmap/api/get-coordinate-to-scrape) is accessed via GET requests.
# It fetches coordinate data from the Coordinates table.
# It filters coordinates with a status of 0 (unprocessed) and joins them with the Category table based on category priority.
# It limits the result to 5 coordinates, updates their status to 1 (processing), and serializes them into JSON format.
# Finally, it returns the serialized coordinate data along with a run_id.
@app.route("/gmap/api/get-coordinate-to-scrape")
def get_coordinate_to_scrape():
    data = []
    coordinates = Coordinates.query.filter_by(status=0).join(Coordinates.category).order_by(Category.priority.desc()).limit(5)
    for co in coordinates:
        co.status = 1
        db.session.commit()
        data.append(co.serialize())
        print(co.id)
    run_id = 1
    return json.dumps({"data":data, "run_id":run_id})



# This is a helper function used by other routes.
# It takes a link parameter and performs several checks to filter out undesirable website links.
# It returns the domain of the link if it passes the checks; otherwise, it returns None.
def filter_website(link):
    if len(link) < 2:
        return None
    without_proto = link.split("//")[-1]
    without_proto_l = without_proto.split("/")
    domain = without_proto_l[0]
    
    if len(without_proto_l)<2:
        return domain
    if len(without_proto_l[1]) < 1:
        return domain 
    if 'wix' in domain:
        return domain
    if without_proto_l[1][0] == '?':
        return domain
    return None



# This route (/gmap/api/post-gmap-data) is accessed via POST requests.
# It expects JSON data in the request body.
# It updates the status of a coordinate to 2 (processed) based on the provided co_id.
# It processes and saves business details received in the JSON data to the database.
# It makes a request to an external API (NODE_BASE_URL) to save GMap companies.
# Finally, it returns the response from the external API in JSON format.
@app.route("/gmap/api/post-gmap-data", methods=["POST"])
def post_gmap_data():
    data = request.json
    coordinate = Coordinates.query.get(data['co_id'])
    coordinate.status=2
    db.session.commit()
    # print(data)
    companies = []
    data_ins_s = []
    for c in data['data']:
        exist_count = BusinessDetails.query.filter_by(name=c['name']).count()
        if exist_count == 0:
            business = BusinessDetails(name=c['name'],category_id=coordinate.category_id,
                                       rating = c['gmap_rating'], num_ratings = c['gmap_num_ratings'],
                                       business_type = c['category'], address = c['gmap_address'],
                                       open_status=c['gmap_status'], website = c['website']
                                       )
            data_ins_s.append(business)
            if c['website'] != None:
                link = filter_website(c['website'])
                if link:
                    print(link)
                    companies.append(c)
        
    print(companies)
    db.session.bulk_save_objects(data_ins_s)
    db.session.commit()
    
    res = requests.post(f"{NODE_BASE_URL}/api/save-gmap-companies", json=companies)
    print(res.json())
    return json.dumps(res.json())



# This route (/gmap/) is accessed via GET requests.
# It retrieves counts of coordinates with different statuses from the database.
# It serializes a list of categories and returns them along with progress data to render an HTML template (index2.html).
@app.route("/gmap/")

def get_dashboard():
    scraped = Coordinates.query.filter_by(status=2).count()
    unprocessed = Coordinates.query.filter_by(status=0).count()
    processing = Coordinates.query.filter_by(status=1).count()
    total = Coordinates.query.order_by(Coordinates.id).count()
    progress = {
        "total":total,
        "scraped":scraped,
        "processing":processing,
        "unprocessed": unprocessed
    }

    
    categories = Serializer.serialize_list(Category.query.all())


    
    return render_template('index2.html', categories = categories, progress = progress)

### Zaubacorp Serializers and views
# This route (/flask/fetch_count) is accessed via GET requests.
# It retrieves the total count of records in the TemporaryLink table.
# It returns a string message indicating the total count.
@app.route('/flask/fetch_count')
def fetch_count():
    count = TemporaryLink.query.count()
    return f'Total records in TemporaryLink: {count}'



# This route (/flask/get_link) is accessed via GET requests.
# It fetches up to 10 pending links from the TemporaryLink table.
# It marks each fetched link as "processing" by updating its status in the database.
# It returns a list of the fetched links.
@app.route('/flask/get_link')
def get_link():
    rows = TemporaryLink.query.filter_by(status='pending').limit(10).all()
    links = []
    for row in rows:
        row.status = "processing"
        links.append(row.link)
        db.session.commit()
    return links
    

# This route (/flask/save_links) is accessed via POST requests.
# It expects JSON data containing a list of links in the request body.
# It marks a MainPageLinks instance with a specific link as "complete" based on the provided crawl_link.
# It adds each link from the JSON data to the TemporaryLink table as pending.
# It returns a message indicating the number of links added to the database.
@app.route('/flask/save_links',methods=['POST'])
def save_links():
    data = request.json
    links = data["links"]
    link = MainPageLinks.query.filter_by(link=data['crawl_link']).first()
    link.status = 'complete'
    db.session.commit()
    for link in links:
        temporary_link = TemporaryLink(link=link, status='pending',location="-")
        db.session.add(temporary_link)
    db.session.commit()
    return f"{len(links)} links added to database"



# This route (/flask/crawl) is accessed via GET requests.
# It fetches up to 5 pending links from the MainPageLinks table.
# It marks each fetched link as "processing" by updating its status in the database.
# It returns a dictionary containing the fetched links.
@app.route('/flask/crawl')
def crawl():
    links_list = []
    links = MainPageLinks.query.filter_by(status='pending').limit(5).all()
    # Update the status of retrieved rows to "completed"
    for link in links:
        links_list.append(link.link)
        link.status = 'processing'
        db.session.commit()
    
    data = {"links":links_list}
    return data

@app.route('/flask/check_crawl')
def check_crawl():
    pending_links_count = MainPageLinks.query.filter_by(status='pending').count()
    if pending_links_count:
        return {"response":True}
    else:
        return {"response":False }
    


# This route (/flask/check_scrape) is accessed via GET requests.
# It checks if there are any pending links in the TemporaryLink table.
# If there are pending links, it returns {"response": True}; otherwise, it returns {"response": False}.
@app.route('/flask/check_scrape')
def check_scrape():
    pending_links_count = TemporaryLink.query.filter_by(status='pending').count()
    print("Pending Links : ",pending_links_count)
    if pending_links_count:
        return {"response":True}
    else:
        return {"response":False }



# This route (/flask/company) is accessed via POST requests.
# It expects JSON data containing details of a company in the request body.
# It extracts various attributes of the company from the JSON data.
# It updates the status of the corresponding TemporaryLink instance to "complete".
# It creates a new CompanyDetail instance with the extracted data and adds it to the database.
# Finally, it sends a request to an external API (NODE_BASE_URL) to save the company data and returns a success message.
@app.route('/flask/company', methods=['POST'])
def create_company():
    company_data = request.json  # Assuming the data is sent as JSON in the request body
    # Extract values from the company_data dictionary
    cin = company_data.get('cin')
    company_name = company_data.get('name')
    link = company_data.get('zaubacorp_url')
    company_status = company_data.get('status')
    company_RoC = company_data.get('headquarter')
    company_regNo = None #company_data.get('registration_number')
    company_category = company_data.get('fundingType')
    company_sub_category = None
    company_class = company_data.get('companyType')
    company_date_of_inc = company_data.get('founded')
    company_age = company_data.get('age')
    company_activity = company_data.get('description')
    company_email = company_data.get('email')
    company_address = company_data.get('location')
    company_auth_capital = company_data.get('data')['Authorized Capital']
    company_paid_up_capital = company_data.get('data')['Paid-up Capital']
    company_listing_status = company_data.get('data')['Listing Status']
    company_last_agm = company_data.get('data')['Last AGM']
    company_latest_balsheet = company_data.get('data')['Latest Balance Sheet']
    directors_list = company_data.get('peoples')
    company_no_of_members = len(directors_list)
    
    comp_link = TemporaryLink.query.filter_by(link=link).first()
    comp_link.status='complete'
    db.session.commit()

    # Create a new CompanyDetail object and add it to the database
    company_detail = CompanyDetail(cin=cin, company_name=company_name, link=link, company_status=company_status,
                                    company_RoC=company_RoC, company_regNo=company_regNo,
                                    company_category=company_category,
                                    company_date_of_inc=company_date_of_inc, company_age=company_age,
                                    company_activity=company_activity,
                                    company_no_of_members=company_no_of_members, company_email=company_email,
                                    company_address=company_address, company_auth_capital=company_auth_capital,
                                    company_paid_up_capital=company_paid_up_capital,
                                    company_listing_status=company_listing_status,
                                    company_last_agm=company_last_agm,
                                    company_latest_balsheet=company_latest_balsheet)
    # company_detail.set_directors_list(directors_list)
    db.session.add(company_detail)
    db.session.commit()
    print("request sent")
    res = requests.post(f"{NODE_BASE_URL}/api/save-zaubacorp-companiess", json={'data':[company_data]})
    print(res.json())

    return 'Company created successfully', 201




# This route (/flask/google-keywords/get-page) is accessed via GET requests.
# It expects JSON data in the request body containing a token.
# It retrieves a query object from the database based on the provided token and the status being 0 (indicating pending).
# If a query object is found, its status is updated to 1 (indicating processing) in the database.
# It constructs a response JSON containing the query ID (qid) and the query text (query).
# It returns the constructed JSON response.
# If no query object is found, it returns a JSON response with a message indicating an error.
@app.route("/flask/google-keywords/get-page")
def get_page():
    data = request.get_json()
    token = data.get('token')
    query = Query.query.filter(Query.token==token, Query.status==0).first()
    if query:
        query.status = 1
        db.session.commit()
        data = {
            'qid':query.id,
            'query':query.query_text,
        }
        return jsonify(data)
    
    return jsonify({"message": "Something went wrong!"})



# This route (/flask/google-keywords/update-log) is accessed via POST requests.
# It expects JSON data in the request body containing the query ID (qid).
# It retrieves the query object from the database based on the provided query ID.
# It updates the status of the query object to 2 (indicating completion) in the database.
# It constructs a response JSON indicating the successful update.
# It returns the constructed JSON response.
@app.route('/flask/google-keywords/update-log', methods=["POST"])
def update_log():
    data = request.get_json()
    qid = data.get('qid')
    query = Query.query.get(qid)
    query.status = 2
    db.session.commit()
    export_data = {
        'qid': qid,
        'success': True,
        'error': None,
        'keyword_id': query.keyword_id
    }
    return jsonify(export_data)



# This route (/get-string) is accessed via GET requests.
# It returns a JSON response containing a randomly chosen string from the provided list ['banao', 'website'].
@app.route('/get-string')
def get_string():
    data = ['banao', 'website']
    return jsonify({'data': random.choice(data)})

#################################### ML Views ####################################



# This route (/flask/ml/generate_first_reply_to_unreplied) is accessed via POST requests.
# It expects JSON data in the request body containing people_id, user_name, and client_name.
# It calls a function generate_1st_response with the provided parameters to generate a response message.
# If successful, it returns a JSON response containing the generated message with error set to False.
# If an exception occurs during the process, it returns a JSON response indicating an error along with the error message.
@app.route('/flask/ml/generate_first_reply_to_unreplied', methods=['POST'])
def generate_first_reply_to_unreplied():
    try:
        data = request.json
        people_id = data.get('people_id')
        assistant_name = data.get('user_name')
        client_name = data.get('client_name')
        msg = generate_1st_response(people_id,assistant_name,client_name)
        
        return {"error":False, "error_msg":None, "response":msg }
    except Exception as e:
        return {"error":True, "error_msg":f"{str(e)}", "response":None }






##Commands


#CIty list for zaubacorp link generation

cities = [
    'Delhi', 'Mumbai', 'Kolkata', 'Bangalore', 'Hyderabad', 'Chennai', 'Pune', 'Ahmedabad', 'Jaipur',
    'Indore', 'Lucknow', 'Thane', 'Gurgaon', 'Patna', 'Surat', 'Coimbatore', 'Nagpur', 'Bhubaneswar',
    'Howrah', 'Chandigarh', 'Ernakulam', 'Secunderabad', 'Kanpur', 'Bhopal', 'Vadodara', 'Guwahati',
    'Agra', 'Raipur', 'Nashik', 'Rajkot', 'Ludhiana', 'Noida', 'Aurangabad', 'Ghaziabad', 'Faridabad',
    'Udaipur', 'Visakhapatnam', 'Thrissur', 'Ranchi', 'Trivandrum', 'Gwalior', 'Goa', 'Varanasi',
    'Kolhapur', 'Siliguri', 'Kochi', 'Cuttack', 'Cochin', 'Vijayawada'
]

@click.command(name="create_zaubacorp_urls")
@with_appcontext
def create_zaubacorp_urls():
    try:
        f = open('zaubacorp_last_city_index.pkl', 'rb')
        last_city_index = pickle.load(f)['last_city_index']
    except:
        last_city_index = 0
        
    for city in cities[last_city_index:]:
        home_page = requests.get(f'https://www.zaubacorp.com/company-list/city-{city}/status-Active-company.html')
        soup = BeautifulSoup(home_page.text, 'html.parser')
        s = soup.select_one('#block-system-main div div span').text
        max_page = int(s.split()[-1].replace(',', ''))  # Remove comma from the string
        print(f"City : {city} , Max page : {max_page}")
        for i in range(1,max_page+1):
            url = f'https://www.zaubacorp.com/company-list/city-{city}/status-Active/p-{i}-company.html'
            link_entry = MainPageLinks(link=url, status='pending')
            db.session.add(link_entry)
        db.session.commit()
        last_city_index = last_city_index + 1
        fw = open('zaubacorp_last_city_index.pkl', 'wb')
        pickle.dump({'last_city_index': last_city_index}, fw)


@click.command(name='create_categories')
@with_appcontext
def create_categories():
    f = open('word_list.pkl', 'rb')
    log = open('load_category_log.txt', 'a')
    categories = pickle.load(f)
    last_tracker = {
        'location_id': None
    }
    try:
        last_tracker_file = open('last_tracker.pkl', 'rb')
        last_location_id = pickle.load(last_tracker_file)['location_id']
        last_tracker_file.close()
        print(last_location_id)
    except:
        last_location_id = 2
    locations = db.session.query(Location).filter(Location.id >= last_location_id)
    try:
        for l in locations:
            print(l)
    except:
        print("failed")
    print(locations)
    for location_ins in locations:
        print(location_ins.name)
        last_tracker_file = open('last_tracker.pkl', 'wb')
        last_tracker['location_id'] = location_ins.id
        pickle.dump(last_tracker, last_tracker_file)
        last_tracker_file.close()
        
        # Convert radius to degrees
        radius_degrees = location_ins.radius / 111.32

        # Define the number of rows and columns in the matrix
        rows = int(location_ins.radius/location_ins.chunk_length)
        cols = int(location_ins.radius/location_ins.chunk_width)
            


        # Calculate the latitudes and longitudes of the matrix
        if rows>cols:
            cols = rows
        else:
            rows = cols

        latitudes = np.linspace(location_ins.centre_lat - radius_degrees,
                                location_ins.centre_lat + radius_degrees, int(rows))
        longitudes = np.linspace(location_ins.centre_long - radius_degrees,
                                    location_ins.centre_long + radius_degrees, int(cols))
        
        matrix = np.zeros((int(rows), int(cols), 2))

        for i in range(rows):
            for j in range(cols):
                matrix[i, j, 0] = latitudes[i]
                matrix[i, j, 1] = longitudes[j]
        lats = []
        lons = []
        coordinates = []

        for i in matrix:
            for j in i:
                lats.append(j[0])
                lons.append(j[1])
        
        priority = 2
        for category in categories:
            if category == None:
                continue
            print(location_ins.id, location_ins.name, category)
            cat = Category.query.filter_by(location_id=location_ins.id, category_name = category)
            if cat.count() > 0:
                category_ins = cat[0]
                print('category skipping')
                continue
            else:
                category_ins = Category(location_id=location_ins.id,category_name=category, priority=priority)
            
                db.session.add(category_ins)
                db.session.commit()
                db.session.refresh(category_ins)
            i = 0
            log.write(f"{location_ins.id}, {location_ins.name}, {category}\n")
            for lat, lon in zip(lats, lons):
                coordinate_ins = Coordinates(category_id=category_ins.id, lat=lat, long = lon)
                db.session.add(coordinate_ins)
                db.session.commit()
                i += 1
            print('coordinates added: ', i)
        
@click.command(name='create_queries_from_keywords')
@with_appcontext
def create_queries_from_keywords():
    """_summary_
    get the names from the indian_names.pkl file and get 
    a keyword which has less than the max name row id number
    and lowest name row id number then get the name from the 
    name row id number and append the keyword to the query
    """
    # names = loand from pk
    names = []
    last_row_from_name = 0
    keyword = SearchKeyword.query.filter(SearchKeyword.last_row_id < last_row_from_name).order_by(SearchKeyword.last_row_id).first()
    for name in names[keyword.last_row_id:]:
        generated_query_text = f"{keyword.keyword} {name} site:linkedin.com inurl:linkedin.com/in"
        ## save the generated query text
        query_ins = Query(query_text=generated_query_text, keyword_id=keyword.id)
        db.session.add(query_ins)
        db.session.commit()
    
    pass

app.cli.add_command(create_categories)
app.cli.add_command(create_zaubacorp_urls)
