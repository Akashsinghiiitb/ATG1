
# This file seems to contain various functions related to processing
# data for generating messages and replies based on certain conditions.



import pandas as pd
import json
import openai
import mysql.connector
from decouple import config

BBD_DB_USER = config("BBD_DB_USER")
BBD_DB_PASS=config("BBD_DB_PASS")
BBD_DB_DB=config("BBD_DB_DB")
BBD_DB_HOST=config("BBD_DB_HOST")
OPENAI_API_KEY=config("OPENAI_API_KEY")
openai.api_key = OPENAI_API_KEY 
model_id = 'gpt-3.5-turbo'


#a list of all servidces provided by Banao
all_services="""Graphic Design
User Interface Design
User Experience Design
User Experience Review
Web Development
PHP/Laravel Development
MEAN Stack
MERN Stack
NodeJs Development
Django Web Development
Quality Assurance and Consulting
Manual Testing
Pixel Perfect UI Testing
Selenium Testing
Appium Automation
Progressive Web App Development
React Native App Development
Android App Development
Flutter App Development
DevOps Consulting
Test Automation in DevOps
Server Monitoring and Alerts
DevOps CI/CD Implementation
Digital Marketing
Social Media Marketing
Social Media Advertising
Telemarketing
Youth Marketing
Content Marketing
Sales Strategy
Leads Generation
YouTube Marketing
Email Marketing
SMS/WhatsApp Marketing
Artificial intelligence/Machine learning
Blockchin"""
banao_services=", ".join(all_services.split("\n"))
 

### 3 sep messages ###
# 1. intro-default
# 2. congrats-custom
# 3. banao intro-default
# 4. outro- custom

# part of congrats message-preserve #2
system_message_phrase_1="""if the person has a Science/Technology/Engineering/Mathematics bsackground you write 'True', otherwise you write 'False'"""

# part of congrats message #2
success_classification=f"""you classify experience into 3 levels 
1)multiple founders with successful finishes: class_1
2)ventures going for 6+ years: class_2
3)ventures going for 3+ years: class_3
4)woking at a big company: class_2
the conditions for writing are: 
1) always return just the answer "class_1", "class_2", or "class_3" do not write anything else
""" #this takes experience format_ecperience_2(exp) as prompt

def remove_words(text,removeables):
    """removeables: words that needs to be removed"""
    system_message=f"""given a sentence, you remove the words in # {removeables} # and replace with a different word of the same meaning in the context of the sentence
    keeping the rest of the sentence as it is and keep it short"""
    conversation = []
    conversation.append({'role': 'system', 'content': system_message})
    conversation.append({'role': 'user', 'content': text})
    conversation = turbo_conversation(conversation)
    return conversation[-1]['content'].strip()
    

system_message_get_field="""Based on the information provided about the client's background and skills  you extract a single field and sub-field (examples: business,software development,banking,sales,music etc are fields) (example: banking, investment, etc are sub-fields of finace)
how to write?:
1) just return the field and sub-field name do not write anything else, if any field is too long replace it with its shorter abbreviation
2) rerurn them in this format ##field:field_name,sub-field:sub-field_name##
3) often the client position doest not represent their field, you should extract the domain they are asociated with
"""
def custom_outro(field_info,prompt):
    fields=field_info.split(",")
    main_field=fields[0].split(":")[1].strip()
    sub_field=fields[1].split(":")[1].strip()
    
    system_message_outro=f"""
    the client works as {main_field} specifically as {sub_field}.
    refer more info on the client and draft a message asking for personal advices/findings from their experience,
    as if you are a beginner in it (write it improvising around what they are good at,but select just one area). make it a little specific but not too much.
    examples:
    1)if the client is in machine learning/AI or similar, write some thing like:   "As someone new to ML, I'm curious, what key insights or findings from your extensive experience do you think would benefit me in my journey?"
    2)if the client is from a business background write something like:   "How do you manage your day effectively, and do you have any helpful tips you could share for my future career in the business field that I am committed to pursuing."
    3)if the client is an investor/board member/CEO or similar write something like:   "I'm eager to embark on my entrepreneurial journey and would appreciate your insights on your daily routine and time management strategies" 
   
    how to write?:
    1) format the {main_field} and {sub_field} as per the style of writing
    1) the text should be a sentence, just write the text body only, do not write anything extra
    2) text should be something that asks for personal findings, advices, generally something i cannot get the asnwers from web search
    4) write WITHOUT AN INTRO, OUTRO
    5) ALWAYS keep it SHORT and polite, do not explain a lot
    6) do not describe about their experience
    """
    conversation = []
    conversation.append({'role': 'system', 'content': system_message_outro})
    conversation.append({'role': 'user', 'content': prompt})
    conversation = turbo_conversation(conversation)
    return conversation[-1]['content'].strip()


# def format_experience(exp,last_n):
#     """worked - years and months at - company (rpeat for all exps)"""
#     command=""
#     if len(exp)>=last_n:
#         for i in range(last_n-1,-1,-1):
#             if i!=0:
#                 try:
#                     command=command+"worked "+exp[i]['duration']+" at "+exp[i]['companyName']+', '
#                 except:
#                     continue
#             else:
#                 try:
#                     command=command+"been working for "+exp[i]['duration']+" at "+exp[i]['companyName']+', '
#                 except:
#                     continue
#     else:
#         for i in range(len(exp)-1,-1,-1):
#             if i!=0:
#                 try:
#                     command=command+"worked "+exp[i]['duration']+" at "+exp[i]['companyName']+', '
#                 except:
#                     continue
#             else:
#                 try:
#                     command=command+"been working for "+exp[i]['duration']+" at "+exp[i]['companyName']+', '
#                 except:
#                     continue
        
#     return command

def format_experience(exp, last_n):
    """worked - years and months at - company (rpeat for all exps)"""
    exp1 = json.loads(exp)
    command = ""
    for i in exp1:
        if 'status' in i:
            if i['end'] == "Present":
                command = command+"been working for " + i['duration']+" at "+i['companyName']+', '
    return command

def format_experience_2(exp,last_n):
    """worked - years and months as - at - company (repetation for all the comapany)"""
    command=""
    
    if len(exp)>=last_n:
            
        for i in range(last_n-1,-1,-1):
            if i!=0:
                try:
                    command=command+"worked "+exp[i]['duration']+" as "+exp[i]['companyPosition']+" at "+exp[i]['companyName']+', '
                except:
                    continue
            else:
                try:
                    command=command+"been working "+exp[i]['duration']+" as "+exp[i]['companyPosition']+" at "+exp[i]['companyName']+', '
                except:
                    continue
    else:
          for i in range(len(exp)-1,-1,-1):
            if i!=0:
                try:
                    command=command+"worked "+exp[i]['duration']+" as "+exp[i]['companyPosition']+" at "+exp[i]['companyName']+', '
                except:
                    continue
            else:
                try:
                    command=command+"been working "+exp[i]['duration']+" as "+exp[i]['companyPosition']+" at "+exp[i]['companyName']+', '
                except:
                    continue
    return command


def create_query(info):
    """creates person profile for banao desc"""
    text=""
    if info['name']:
        text+="the folling are the information about "+info['name']+":"+"\n"
    if info['about']:
        text+="summary: "+info['about']+"\n"
    if info['skills']:
        text+="skills: "+info['skills']+"\n"
    if info['experience']:
        text+="experience: "+format_experience(info['experience'],2)+"\n"
    if info['position']:
        text+="current position: "+info['position']+"\n"
    text="the following is all the info on a clent: "+text
    name=" ".join([i.lower().capitalize() for i in info["name"].split(" ")])
    return text,name

def create_query_sweet_talk(info):
    """makes a person profile for sweet talking"""
    text=""
    if info['about']:
        text+="summary: "+info['about']+"\n"
    if info['experience']:
        text+="experience: "+format_experience(info['experience'],2)+"\n"
    text="the following is all the info on a clent: "+text
    return text


def turbo_conversation(conversation,temperature=None, max_tokens=None):
    if temperature==None and max_tokens==None:
        response = openai.ChatCompletion.create(
            model=model_id,
        messages=conversation)   
    else:
        response = openai.ChatCompletion.create(
            model=model_id,
        messages=conversation,
        temperature=temperature,
        max_tokens=max_tokens)
    conversation.append({'role': response.choices[0].message.role, 'content': response.choices[0].message.content})
    return conversation
    
def standard_message_intro(name):
    """ returns standard introduction default
    name:client_name"""
    name=name.split(" ")[0]
    return f"""Hi {name},\nGlad to be connected."""

def standard_message_outro():
    """return standard outro message default"""
    return'\nMay I request 20 mins of your time this week to explore synergy for growth?\nThanks.'

def get_all_positions(exp):
    """extracts positions and concats into a string"""
    command=""
    for i in range(len(exp)-1,-1,-1):
        try:
            command=command+exp[i]['companyPosition']
        except:
            continue
    return command

def preprocess_for_outro(data):    
    """processing for sutom outro
    extracts these:
    "about",
    "previous positions",
    "skills", 
    from profiles, concats to a string """
    
    prompt="following are the details of a client- "
    if data['about']: 
        prompt+="about "+data['about']+"\n"
    if data['experience']:
        prompt+= "exp: "+get_all_positions(data['experience'])+"\n"
    if data['skills']:
        prompt+="skills: "+data['skills']+"\n"
    return prompt


def default_message_banao_desc(assistant_name):
    """return default message for banao description given an assisstant name"""
    return f"""I am {assistant_name}, and work with Banao Technologies (www.banao.tech), which provides AI/ML, web/app development, marketing services to businesses."""

def custom_message_sweet_talk_stem(prompt,success_level):
    system_message=f"""you look at a client's description, (data scraped from their LinkedIn about, experience sections) 
    and write a very short sentence either congratulating for a single one of their achievements or simply praising their knowledge,
    considering their success level also, success_level={success_level}
    how to write?:
    1)if success_level='class_1', then the text should sound like this: say "your entrepreneurial knack is commendable." but elaborate little bit 
    2)if success_level='class_2', then the text should sound like this: say "Congratulations on the success at their company (include just one  company name)" but elaborate little bit 
    3)if success_level='class_3', then the text should sound like this: ask "How is it going at their current company(#include CURRENT company name)", but elaborate a little bit 
    # the rules to follow:
    1)text should be wriiten without an inro or outro, and always keep it short and general
    2)write WITHOUT mentioning ABOUT THEIR TENURE AT A PLACE LIKE "10 year 3 months","12 years" etc..
    3)WRITE WITHOUT NUMBERS, ESPECIALLY in the form of MONEY, AGE or TIME, TENURE,PERCENT,TURNOVER etc
    4)use past tense when menstioning a previous company 
    5)when you say comany name there should be no LLC, LTD, VC, Inc or similar extensions, only take the company name, ##be very causious in filtering the company name out!
    6)text should be something that feeds their ego
    7)remember to clean text
    """
    
    conversation = []
    conversation.append({'role': 'system', 'content': system_message})
    conversation.append({'role': 'user', 'content': prompt})
    conversation = turbo_conversation(conversation)
    return conversation[-1]['content'].strip()
    
def custom_message_sweet_talk_nstem(prompt,success_level):
    system_message=f"""you look at a client's description, (data scraped from their LinkedIn about, experience sections) 
    and write a very short sentence either congratulating for a single one of their recent(very important) work or philanthropy or simply praising their knowledge,
    the rules to follow:
    1)text should be without an inro or outro, and always keep it short
    2)should be something that makes you resonate with them 
    3)remember to clean text
    4)when you say comany name there should be no LLC, LTD extensions only take the company name
    5)write WITHOUT mensioning ABOUT THEIR TENURE AT A PLACE LIKE "10 year 3 months","12 years" etc..
    6)WRITE WITHOUT NUMBERS, ESPECIALLY in the form MONEY, AGE or TIME, TENURE
    """
    
    conversation = []
    conversation.append({'role': 'system', 'content': system_message})
    conversation.append({'role': 'user', 'content': prompt})
    conversation = turbo_conversation(conversation)
    return conversation[-1]['content'].strip()

    
def conv_pipe(system_message,prompt):
    conversation = []
    conversation.append({'role': 'system', 'content': system_message})
    conversation.append({'role': 'user', 'content': prompt})
    conversation = turbo_conversation(conversation)
    return conversation[-1]['content'].strip()


def write(sample,assistant_name,client_name):    
    query,name=create_query(sample)
    sweet_talk_query=create_query_sweet_talk(sample)
    success_level=conv_pipe(success_classification,format_experience_2(sample['experience'],4))
    text=standard_message_intro(client_name) #1
    is_stem=bool(conv_pipe(system_message_phrase_1,query))
    # outro_query=preprocess_for_outro(sample)
    # field_info=conv_pipe(system_message_get_field,outro_query)
    # outro_message=custom_outro(field_info,outro_query)
    
    outro_message = "Our UI and marketing experts have prepared a free UI/UX design and marketing roadmap analysis for your company. May I please request you for your email to send that? Should you like our findings, we may take the discussion forward with concerned team thereafter."
    
    if is_stem:
        text+="\n"+remove_words(custom_message_sweet_talk_stem(sweet_talk_query,success_level),'truly') #2
    
    else:
        text+="\n"+remove_words(custom_message_sweet_talk_nstem(sweet_talk_query,success_level),'truly')

    text+="\n"+default_message_banao_desc(assistant_name)
    text+="\n"+outro_message+"\n"+"Thanks" #4
    return text


def preprocess(data):
    data['experience'] = data['experience'].apply(lambda x: json.loads(x) if x is not None else None)
    data['posts'] = data['posts'].apply(lambda x: json.loads(x) if x is not None else None)
    data['skills']=data['skills'].apply(lambda x:x.replace("\n",",") if x is not None else None)
    return data
 
 
def get_data(id):
    USER_NAME = BBD_DB_USER
    PASS = BBD_DB_PASS
    DB = BBD_DB_DB
    HOST = BBD_DB_HOST

 
    mydb = mysql.connector.connect(
        host=HOST,
        user=USER_NAME,
        password=PASS,
        database=DB,)
 
    mycursor = mydb.cursor()
    sql_query = f"""
    SELECT p.id, p.name, pd.about, pd.experience, pd.position, pd.skills, pd.priority, p.points, p.points_explanation, pd.posts, p.url
    FROM Banaobd.people AS p
    INNER JOIN Banaobd.people_details AS pd ON p.id = pd.people_id
    WHERE p.id={id}
    AND p.name IS NOT NULL
    AND pd.about IS NOT NULL
    AND pd.experience IS NOT NULL
    AND pd.position IS NOT NULL
    AND pd.skills IS NOT NULL;
    """
    mycursor.execute(sql_query)
    result = mycursor.fetchall()
    try:
        cols=['id', 'name', 'about', 'experience', 'position', 'skills', 'priority','points', 'points_explanation', 'posts', 'url']
        sample=pd.DataFrame({cols[i]:result[0][i] for i in range(len(cols))},index=[0])    
        sample=preprocess(sample)
        data=sample.iloc[0]
    except:
        print('no such id present or some important attributes missing for this id: cannot generate message!')
        return None
    
    mycursor.close()
    mydb.close()
    return data

def get_first_name(full_name):
    f_name = full_name.split(' ')[0]
    f_name = f_name.split('.')[0]
    return f_name.capitalize()

def generate_1st_response(id, user_name,client_name): 
    assistant_name= get_first_name(user_name) #customize
    sample=get_data(id)    
    if sample is not None:
        result=write(sample,assistant_name,client_name)        
        return result



# reply to any client resonse folowing the connection message/messages
# from llama_index import VectorStoreIndex, SimpleDirectoryReader
# data_path=config('DATA_PATH')
# documents = SimpleDirectoryReader(data_path).load_data()
# index = VectorStoreIndex.from_documents(documents)
# query_engine = index.as_query_engine()


def get_messages_data(connection_id):  
    USER_NAME = BBD_DB_USER
    PASS = BBD_DB_PASS
    DB = BBD_DB_DB
    HOST = BBD_DB_HOST

    mydb = mysql.connector.connect(
        host=HOST,
        user=USER_NAME,
        password=PASS,
        database=DB,)
 
    mycursor = mydb.cursor()
    sql_query = f"""
    SELECT m.id,m.message,m.sender,m.connection_id,m.user_id FROM Banaobd.messages as m
    WHERE connection_id={connection_id};
    """
    mycursor.execute(sql_query)
    result = mycursor.fetchall()
    
    try:
        cols=['id', 'message', 'sender', 'connection_id', 'user_id']
        sample=pd.DataFrame({cols[i]:result[0][i] for i in range(len(cols))},index=[0])    
    except:
        print('no such id present or some important attributes missing for this id: cannot generate message!')
        return None
    
    mycursor.close()
    mydb.close()
    return sample


def get_conversation(sample):
    conversation=[]
    conversation.append({'role': 'user', 'content': ""})
    assistant_name=sample['sender'].iloc[0]
    first_message_assistant=sample['message'].iloc[0]
    if sample['sender'].iloc[1]!=assistant_name:
        client_name=sample['sender'].iloc[1]
        first_client_reply= sample['message'].iloc[1]
        iter_start=2
        
    else:
        client_name=sample['sender'].iloc[2]
        first_message_assistant+="\n"+sample['message'].iloc[1]
        first_client_reply=sample['message'].iloc[2]
        iter_start=3
    conversation.append({'role': 'assistant', 'content':first_message_assistant})
    conversation.append({'role': 'user', 'content':first_client_reply})

    role="assistant"
    for message_idx in range(iter_start,len(sample)):
        conversation.append({'role': role, 'content':sample['message'].iloc[message_idx]})
        role='user'
    return conversation
        
    
    
# def extend_conversation(conversation):
#     for dialog in conversation[::-1]:
#         if dialog['role']=="user":
#             user_response=dialog['content']
#             break
            
#     prompt=f"""you are a representative of Banao, look at client replies:{user_response} and produce an aprpriate reply
#     instructions for writing:
#     1) keep it below 25 words and always be factually correct
#     2) always give proper details so its not needed to ask again
#     3) always rewrite sentence professionally
#     4) when asked about Banao's services or technologies, always have AI/ML weightage
#     """
#     response = query_engine.query(prompt)
#     system_message=f"""you are Banaos assistant you look at the answer to a question, ## answer:{response.response} ## and write it in the current context and tone
#     instructions to write:
#     1) keep it pofessional but resonate wth the clients tone
#     2) omit inro and outro just write the text
#     3)keep it short"""    

#     conversation.insert(0,{"role":"system","content":system_message})
#     conversation = turbo_conversation(conversation)
#     return conversation

# def generate_reply(connection_id):
#     sample=get_messages_data(connection_id)
#     conversation=get_conversation(sample)
#     conversation=extend_conversation(conversation)
#     return conversation[-1]['content'].strip() # this needs to be stored to db(its the reply)