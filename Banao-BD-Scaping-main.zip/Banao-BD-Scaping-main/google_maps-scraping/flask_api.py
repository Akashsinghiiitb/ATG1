# Each method in this file handles specific functionalities related to database creation,
# coordinate retrieval, data scraping from Google Maps, and data retrieval. The associated
# routes define how users can interact with the application and trigger these functionalities.


from selenium import webdriver
import time
from selenium.webdriver.common.by import By
from selenium.webdriver import ActionChains
from selenium.webdriver.common.actions.wheel_input import ScrollOrigin
from geopy.geocoders import Nominatim
import numpy as np
import json
import pandas as pd
import threading as t
from flask import Flask, jsonify,redirect,url_for
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime


app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///data.db'
db = SQLAlchemy(app)


class BusinessDetails(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    rating = db.Column(db.String(10), nullable=False)
    num_ratings = db.Column(db.String(10), nullable=False)
    business_type = db.Column(db.String(100), nullable=False)
    address = db.Column(db.String(200), nullable=False)
    open_status = db.Column(db.String(200), nullable=False)
    website_link = db.Column(db.String(200), nullable=False)
    time_created = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return '<Business %r>' % self.name


class Location(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String)
    centre_lat = db.Column(db.Float(precision=53))
    centre_long = db.Column(db.Float(precision=53))
    chunk_width = db.Column(db.Float(precision=53))
    chunk_length = db.Column(db.Float(precision=53))
    createdAt = db.Column(db.DateTime)

class Category(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    location = db.Column(db.Integer, db.ForeignKey('location.id'))
    category_name = db.Column(db.String)
    priority = db.Column(db.Integer)
    status = db.Column(db.String)
    createdAt = db.Column(db.DateTime)
    updatedAt = db.Column(db.DateTime)

class Coordinates(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    category = db.Column(db.Integer, db.ForeignKey('category.id'))
    lat = db.Column(db.Float(precision=53))
    long = db.Column(db.Float(precision=53))
    status = db.Column(db.Integer, default=0)
    scraped_at = db.Column(db.DateTime)


# Creates the SQLite database and its tables using SQLAlchemy.
# Returns a message indicating that the database has been created.

@app.route('/')
def database_creation():
    db.create_all()
    return "Database created"


@app.route('/get_coordinates/<string:category>-<string:location>-<int:radius>-<int:density>', defaults={'priority': 3})
@app.route('/get_coordinates/<string:category>-<string:location>-<int:radius>-<int:density>-<int:priority>')

# Retrieves coordinates based on the provided category, location, radius, and density.
# Uses Nominatim to obtain latitude and longitude coordinates for the specified location.
# Generates a matrix of coordinates within the specified radius around the location.
# Stores the coordinates in the SQLite database.

# /get_coordinates/dentist-delhi-50-40
def get_coordinates(category, location, radius, density, priority=1):
    query = location
    geolocator = Nominatim(user_agent="my-app-name")
    location = geolocator.geocode(query)
    center_lat, center_lon = location.latitude, location.longitude

    # Define the center coordinate
    # Define the radius of the area in kilometers
    radius = radius

    # Convert radius to degrees
    radius_degrees = radius / 111.32

    # Define the number of rows and columns in the matrix
    rows = density
    cols = density

    # Calculate the latitudes and longitudes of the matrix
    latitudes = np.linspace(center_lat - radius_degrees,
                            center_lat + radius_degrees, rows)
    longitudes = np.linspace(center_lon - radius_degrees,
                             center_lon + radius_degrees, cols)

    # Create the matrix
    matrix = np.zeros((rows, cols, 2))

    for i in range(rows):
        for j in range(cols):
            matrix[i, j, 0] = latitudes[i]
            matrix[i, j, 1] = longitudes[j]
    lat = []
    lon = []
    coordinates = []

    for i in matrix:
        for j in i:
            lat.append(j[0])
            lon.append(j[1])
    for lat, lon in zip(lat, lon):
        coordinate = f"{lat},{lon}"
        status = 0  # Replace with your desired status value
        coordinate_with_status = (coordinate, status)
        #((lat,lon),status)
        coordinates.append(coordinate_with_status)
    context = {
        'category': category,
        'location': str(location),
        'radius': radius,
        'coordinates': coordinates
    }
    # data = Data(
    #     category=category,
    #     priority=priority,
    #     location=str(location),
    #     radius=radius,
    #     coordinates=coordinates
    # )
    # db.session.add(data)
    db.session.commit()
    return jsonify(context)


# Retrieves unscraped coordinates from the database.
# Limits the number of unscraped coordinates to 6 for each category.
# Returns a JSON response containing the unscraped coordinates.

@app.route('/data')
def get_data():
    # data = Data.query.all()
    unscraped_coordinates = []
    data_dict_list = [d.to_dict() for d in data]
    i = 0
    for data in data_dict_list:
        category = data["category"]
        for row in data["coordinates"]:
            if row[1] == 0:
                if i > 5:
                    break
                i += 1
                unscraped_coordinates.append({'lat,lon':row,
                                            'category':category
                                              })
                

    return jsonify(unscraped_coordinates)


# Scrapes business details from Google Maps based on the provided business name, latitude, and longitude.
# Constructs the URL for the Google Maps location search with the business name.
# Automates scrolling through the page to load more results if necessary.
# Extracts business details such as name, rating, number of ratings, business type, address, open status, and website link.
# Stores the scraped business details in the SQLite database.

name = 'travel agents'
lat = '28.6139'
lon = '77.2090'
@app.route('/GM', defaults={'business_name' : name, 'lat':lat, 'lon' : lon})
@app.route('/GM/<business_name>-<lat>-<lon>')
def scrape(business_name, lat, lon):
    # business = Data.query.filter_by(coordinates=(lat,lon)).first()
    # if business:
    #     business.coordinates = (lat,lon,2)
    #     db.session_add(business)
    #     db.session.commit()
    # else:
    #     print("Record not found")
    # Construct the URL for the Google Maps location search with the business name
    link = f"https://www.google.com/maps/search/{business_name}/@{lat},{lon},16z"
    browser = webdriver.Chrome()
    browser.get(link)
    time.sleep(3)
    action = ActionChains(browser)
    s_break = 0
    details_list = []

    while True:
        try:
            if s_break>10:
                print("Max timeout reached ")
                a = browser.find_elements(By.CLASS_NAME, "hfpxzc")
                break
            a = browser.find_elements(By.CLASS_NAME, "hfpxzc")
            # print(f"Length of a : {len(a)}")
            try:
                s_break += 1
                # print(s_break)
                # print("inside try")
                browser.find_element(By.CLASS_NAME,"PbZDve")
                scroll_origin = ScrollOrigin.from_element(a[-1])
                action.scroll_from_origin(scroll_origin, 0, 1000).perform()
                time.sleep(2)
                break
            except:
                a = browser.find_elements(By.CLASS_NAME, "hfpxzc")
                if len(a)>0:
                    try:
                        scroll_origin = ScrollOrigin.from_element(a[-1])
                        action.scroll_from_origin(scroll_origin, 0, 1000).perform()
                        time.sleep(2)
                    except:
                        break
                else:
                    break
            a = browser.find_elements(By.CLASS_NAME, "hfpxzc")
        except:
            pass
    names = browser.find_elements(By.CLASS_NAME, 'bfdHYd.Ppzolf.OFBs3e')
    for name in names:
        details = name.text.split("\n")
        print(details)
        try:
            b_name = details[0]
        except:
            b_name = "none"
        try:
            rating = details[1].split('(')[0]
        except:
            rating = "No Reviews"
        try:
            num_rating = details[1].split('(')[1].replace(')', '')
        except:
            num_rating = "No Reviews"
        try:
            b_type = details[2].split("·")[0].rstrip()
        except:
            b_type = "none"
        try:
            b_add = details[2].split("·")[1].lstrip()
        except:
            b_add = "none"
        try:
            b_status = details[3]
        except:
            b_status = "none"
        try:
            website_links = name.find_element(By.CLASS_NAME, "Rwjeuc")
            links = website_links.find_element(By.TAG_NAME, "a")
            b_website = links.get_attribute("href")
        except:
             b_website = "None"
        b_data = {
        "name" : b_name,
        "rating" : rating,
        "num_ratings" : num_rating,
        "category" : b_type,
        "address" : b_add,
        "status" : b_status,
        "website" : b_website
        }
        details_list.append(b_data)

        existing_record = BusinessDetails.query.filter_by(name=b_name).first()
        if not existing_record:
            data = BusinessDetails(
                name=b_name,
                rating=rating,
                num_ratings=num_rating,
                business_type=b_type,
                address=b_add,
                open_status=b_status,
                website_link=b_website
            )
            db.session.add(data)
    db.session.commit()
    browser.quit()
    # data_record = Data.query.filter_by().first()
    # if business:
    #     data_record.coordinates = (lat,lon,3)
    #     db.session.commit()
    # else:
    #     print("Record not found")
    
    return jsonify(details_list)


# @app.route('/GoogleMapsAPI/')
# def get_coordinates(location):
#     query = location
#     geolocator = Nominatim(user_agent="my-app-name")
#     location = geolocator.geocode(query)
#     center_lat, center_lon = location.latitude, location.longitude
#     return center_lat, center_lon


if __name__ == "__main__":
    app.run(debug=True)
    # start_time = time.time()
    # data = pd.read_csv('top_rated\\maps_category.csv')
    # cats = []
    # categories = []
    # for col in data.columns:
    #     cats.append(data[col])
    # for cat in cats:
    #     cat.dropna(inplace=True)
    #     for c in cat:
    #         categories.append(c)
    # lat , lon = get_coordinates("Pune")
    # lat2, lon2 = get_coordinates("Delhi")
    # print(len(categories))

    # scrape('travel agents', lat2, lon2)
    # with open("detailsT1.json", "w") as of:
    #         json.dump(details_list, of)
