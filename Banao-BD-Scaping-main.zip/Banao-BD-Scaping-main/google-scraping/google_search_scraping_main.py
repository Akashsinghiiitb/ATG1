from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from shutil import which
from scrapy.selector import Selector
from fake_useragent import UserAgent
from shutil import which
import requests
import time 
import random
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import os
import urllib.request
import pathlib
from log_generator import generate_log
from datetime import date, datetime

# Log file name
current_date = date.today()
current_time = datetime.now().strftime("%H:%M").replace(":", ",")
LOG_FILE = f"{current_time}_{current_date}_google_search_scrping"
BASE_URL_NODE = "https://bbd.atg.party"

def do_log(*message):
    output_data = ''
    for i in message:
        output_data += f"{i} "
    print(output_data)
    generate_log(output_data, LOG_FILE)

def captcha():
    filename = "1.mp3"
    audioToTextDelay = 10
    def audioToText(mp3Path):
        driver.switch_to.window(driver.window_handles[0])
        btn = driver.find_element(By.XPATH, '//*[@id="root"]/div/input')
        btn.send_keys(f'{pathlib.Path(__file__).parent.resolve()}\\1.mp3')
        time.sleep(audioToTextDelay)
        text = driver.find_element(By.XPATH, '//*[@id="root"]/div/div[7]/div/div/div').find_elements_by_tag_name('span')
        result = " ".join( [ each.text for each in text ] )
        driver.refresh()
        driver.switch_to.window(driver.window_handles[1])
        return result
    frames = driver.find_elements_by_tag_name("iframe")
    driver.switch_to.frame(frames[0])
    time.sleep(2)
    driver.find_element(by=By.CLASS_NAME,value="recaptcha-checkbox-border").click()
    driver.switch_to.default_content()
    frames = driver.find_element(by=By.XPATH,value = "/html/body/div[2]/div[4]").find_elements(by=By.TAG_NAME,value="iframe")
    driver.switch_to.frame(frames[0])
    time.sleep(2)
    driver.find_element(by=By.ID,value="recaptcha-audio-button").click()
    driver.switch_to.default_content()
    frames = driver.find_element(by=By.XPATH,value="/html/body/div/div[4]").find_elements(by=By.TAG_NAME,value="iframe")
    driver.switch_to.frame(frames[0])
    time.sleep(2)
    driver.find_element(by=By.XPATH,value="/html/body/div/div/div[3]/div/button").click()
    src = driver.find_element(by=By.ID,value="audio-source").get_attribute("src")
    time.sleep(2)
    urllib.request.urlretrieve(src,os.getcwd()+"\\" + filename)
    response = audioToText(os.getcwd() + '/' + filename)
    driver.switch_to.default_content()
    frames = driver.find_element(by=By.XPATH,value="/html/body/div/div[@style='z-index: 2000000000; position: relative; width: 280px; height: 275px;']").find_elements(by=By.TAG_NAME,value="iframe")
    driver.switch_to.frame(frames[0])
    inputbtn = driver.find_element(by=By.ID,value='audio-response')
    inputbtn.send_keys(response)
    inputbtn.send_keys(Keys.ENTER)
    return

def scraping(data):
    details = []
    for i in data.xpath("//div[@class='yuRUbf']"):
        req = {'name':" ",'url' :" "}
        temp = i.xpath("./a/h3/text()").get()
        name = list(temp.split("-"))
        href = i.xpath("./a/@href").get()
        if '?' in href:
            t = href.split("?")
            temp = t[0]
            req["name"] = name[0]
            req["url"] = temp
            details.append(req)
        else:
            req["name"] = name[0]
            req["url"] = href
            details.append(req)
    
    r = requests.post(url="https://banao-bd-scrapper.herokuapp.com/api/googleSearchPeopleApi", json={"peoples": details, "item":items_title})
    do_log(r)
    time.sleep(random.choice(range(5,10)))

def pagination():
    while(1):
        html = driver.page_source
        data = Selector(text=html)
        scraping(data)
        next = data.xpath("//td[@class='d6cvqb BBwThe']/a/span[contains(text(),'Next')]")
        cap = data.xpath("//div[@id='recaptcha']")
        if next:
            next = driver.find_element(by = By.XPATH,value="//td[@class='d6cvqb BBwThe']/a/span[contains(text(),'Next')]")
            next.click()
        elif cap:
            captcha()
            time.sleep(2)
            driver.switch_to.default_content()
        else:
            break
    return


ua = UserAgent()
option = webdriver.ChromeOptions()
option.add_argument(f"user-agent = {ua.random}")
option.add_argument("--window-size=1920,1200")
option.add_argument('--disable-notifications')
option.add_argument("--mute-audio")
option.add_argument("--headless")

chrome_path = f'{pathlib.Path(__file__).parent.resolve()}/chromedriver'
driver = webdriver.Chrome(executable_path=chrome_path,chrome_options=option)

def get_profiles(query, page_number=0):
    url = "https://duckduckgo.com/?t=h_&q="
    link = url+query
    driver.get(link)
    time.sleep(2)

    links = set()

    for _ in range(page_number-1):       
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(1)
        try:
            more_results_btn = driver.find_element(By.TAG_NAME, "button")
            more_results_btn.click()
            time.sleep(1)
        except:
            pass

    span = driver.find_elements(By.CLASS_NAME, 'ds1w04wA2KNmfx2PU4CA')[-1]
    list_tag = span.find_element(By.XPATH, '../..')
    divs = list_tag.find_elements(By.XPATH, 'following-sibling::li')

    for i in divs:
        anchor = i.find_element(By.XPATH, '*[1]/*[2]/*[1]/*[1]')
        links.add(anchor.get_attribute('href'))

    return list(links)

# Token verification
def get_run_id(token):
    res = requests.post(f"{BASE_URL_NODE}/api/create-entry-of-userstats", json={'token':token, 'extension':'exe_googlesearchscraping'})
    if res.status_code != 200:
        return None , res.text
    return res.json()['id'] , None

token = input("Enter token")
run_id, err =  get_run_id(token)

if err:
    print("Invalid Token")
    exit()


driver.get('https://speech-to-text-demo.ng.bluemix.net/')
driver.execute_script("window.open('');")
driver.switch_to.window(driver.window_handles[1])

url_list=['https://www.google.com/search?q=react+js+%22student%22+bachelor+of+technology+2017+-+2021+site%3Alinkedin.com', 'https://www.google.com/search?q=ui+design+%22student%22+india+2017+-+2021+site:linkedin.com', 'https://www.google.com/search?q=marketing+communication+%22student%22+india+2018+-+2022+site%3Alinkedin.com']
for url_from_api in url_list:
    driver.switch_to.window(driver.window_handles[1])
    driver.get(url_from_api)
    html = driver.page_source
    data = Selector(text=html)
    next = data.xpath("//td[@class='d6cvqb BBwThe']/a/span[2]")
    cap = data.xpath("//div[@id='recaptcha']")
    if next:
        pagination()
    elif cap:
        captcha()
        time.sleep(2)
        driver.switch_to.default_content()
        pagination()
time.sleep(10)

# Get pages calling
while True:
    response = requests.get("http://127.0.0.1:5000/get-page", json={"token": token})
    data = response.json()
    if data == None or data.get("message")==None:
        break
    pageno = data.get("pageno")
    query = data.get("query")
    url_links = []
    # If the page number doesn't exists, get_profiles throw an error
    for _ in range(10):
        try:
            links = get_profiles(query, pageno)
            if links:
                url_links += links
        except:
            pass
        pageno += 1
    
    post_data = []
    for i in url_links:
        single_url_data = {
            "url": i,
            "name": "Random Name" #modify it
        }
        post_data.append(single_url_data)

    res = requests.post("https://bbd.atg.party/api/save-google-search-peoples", json={"data":post_data})
    res2 = requests.post("http://127.0.0.1:5000/update-log", json={"logid", data.get("logid")})