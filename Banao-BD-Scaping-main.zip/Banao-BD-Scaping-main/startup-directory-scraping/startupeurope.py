#!/usr/bin/env python
# coding: utf-8

# In[ ]:


from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
import time
import requests


# In[ ]:


s = Service("C:\Program Files (x86)\chromedriver.exe")
driver = webdriver.Chrome(service=s)
driver.get("https://startupeurope.net/search")
time.sleep(10)

final_pages = []

def pages(): 
    
    global final_pages       

    c1 = driver.find_element(by=By.XPATH, value='/html/body/div[1]/div[3]/div/div[1]/div[2]/div[1]/div/a')
    c1_href = c1.get_attribute('href')
    final_pages.append(c1_href)
    
    c2 = driver.find_element(by=By.XPATH, value='/html/body/div[1]/div[3]/div/div[1]/div[2]/div[2]/div/a')
    c2_href = c2.get_attribute('href')
    final_pages.append(c2_href)
    
    c3 = driver.find_element(by=By.XPATH, value='/html/body/div[1]/div[3]/div/div[1]/div[2]/div[3]/div/a')
    c3_href = c3.get_attribute('href')
    final_pages.append(c3_href)
    
    c4 = driver.find_element(by=By.XPATH, value='/html/body/div[1]/div[3]/div/div[1]/div[2]/div[4]/div/a')
    c4_href = c4.get_attribute('href')
    final_pages.append(c4_href)
    
    c5 = driver.find_element(by=By.XPATH, value='/html/body/div[1]/div[3]/div/div[1]/div[2]/div[5]/div/a')
    c5_href = c5.get_attribute('href')
    final_pages.append(c5_href)
    
    buttonn = driver.find_element(by=By.XPATH, value = '/html/body/div[1]/div[3]/div/div[1]/div[4]/div/div/nav/ul/li[2]/a')
    #time.sleep(5)
    #buttonn.click()
    try:
        if buttonn.is_enabled:
            buttonn.click()
            time.sleep(1)
            pages()
        else:
            return
    except:
        return
    
pages()
print(final_pages)


# In[ ]:


total_list = {}

total_list['origin']='https://startupeurope.net/search'

def post_data(detail):
    url = "http://intranet.atg.party:8989/api/saveExternalCompanyDetails"

    myobj = detail

    x = requests.post(url, json = myobj)
    print(x.text)


for final_pgs in final_pages:
    driver.get(final_pgs)
    time.sleep(10)
    
    try:
        name = driver.find_element(by=By.XPATH, value='/html/body/div[1]/div[2]/div[2]/div[1]/div/h2')
        final_name = name.text
        total_list['name']=final_name 
    except:
        total_list['name']=''       
             
    try:
        link = driver.find_element(by=By.XPATH, value='/html/body/div[1]/div[2]/div[2]/div[1]/div/span/a[2]')
        final_link = link.text
        total_list['website']=final_link  
    except:
        total_list['website']=''  
   
    try:
        domain = driver.find_element(by=By.XPATH , value ='/html/body/div[1]/div[2]/div[2]/div[1]/div/span/a[3]')
        final_domain = domain.text
        total_list['category']=final_domain    
    except:
        total_list['category']=''
    
        
        
    try:
        description = driver.find_element(by=By.XPATH, value='/html/body/div[1]/div[2]/div[2]/div[2]/p')
        final_description = description.text
        total_list['description']=final_description
    except:
        total_list['description']=''
        
    total_list['founded_date']=''
    total_list['linkedin']=''
    total_list['facebook']=''
    total_list['twitter']=''
    total_list['play_store']=''
    total_list['app_store']=''
   
        
    try:
        location = driver.find_element(by=By.XPATH, value ='/html/body/div[1]/div[2]/div[2]/div[1]/div/span/a[1]')
        final_location = location.text
        total_list['location']=final_location    
    except:
        total_list['location']=''       
        
    total_list['rank']=''
    total_list['headquarter']=''
    total_list['people']=[]

    print(total_list)
    post_data(total_list)

    #print(final_name,final_location,final_link,final_domain,final_description)

