#!/usr/bin/env python
# coding: utf-8

# In[ ]:


from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
import time
import requests


# In[ ]:


s = Service("C:\Program Files (x86)\chromedriver.exe")
driver = webdriver.Chrome(service=s)
driver.get("https://allstartups.info/Startups")
time.sleep(10)

final_pages = ['https://allstartups.info/Startups?Page=1']

def pages(): 
    page = driver.find_elements(by=By.CLASS_NAME, value='col-sm-16')
    page_links_ = driver.find_elements(by=By.XPATH, value='//a')
    page_links_ = page_links_[-5:-3]
    
    print(page_links_)
    
    for i in page_links_:
        a = i.get_attribute('href')
    print(a)
    
    global final_pages       
    final_pages.append(a)    
    
    if a != 'https://allstartups.info/Startups':
        driver.get(a)
        time.sleep(2)
        print('next page')
        pages()
    else:
        print('end')
        return 

pages()


# In[ ]:


total_list = {}
total_list['origin']="https://allstartups.info/Startups"


def post_data(detail):
    url = "http://intranet.atg.party:8989/api/saveExternalCompanyDetails"

    myobj = detail

    x = requests.post(url, json = myobj)
    print(x.text)


for final_pgs in fp1:
    
    driver.get(final_pgs) 
    read = driver.find_elements(by=By.CLASS_NAME, value='pull-left')
    read_links = driver.find_elements(by=By.XPATH , value ='//a')
    read_links = read_links[5:15]

    read_more_links = []
    for readd in read_links:
        i = readd.get_attribute('href')
        read_more_links.append(i)

    for i in read_more_links:
        driver.get(i)
        time.sleep(10)

        try:
            title = driver.find_element(by=By.XPATH, value='//h1')
            final_title = title.text
            total_list['name']=final_title
        except:
            title=''
            total_list['name']=''
        
        try:
            link = driver.find_element(by=By.CLASS_NAME, value='pull-left')
            final_link = link.text
            total_list['website']=final_link
        except:
            link=''
            total_list['website']=''
        
        try:
            category=driver.find_element(by=By.XPATH, value='/html/body/div[2]/div/div/div[1]/div[3]/div[2]/p[1]')
            final_category = category.text
            total_list['category']=final_category
        except:
            category=''
            total_list['category']=''
        
        try:
            description = driver.find_element(by=By.CLASS_NAME, value='detail-body')
            final_description = description.text
            total_list['description']=final_description
        except:
            description=''
            total_list['description']=''
            
        try:
            founded_date = driver.find_element(by=By.XPATH, value='/html/body/div[2]/div/div/div[1]/div[3]/div[2]/p[2]')
            final_founded_date = founded_date.text
            total_list['founded_date']=final_founded_date
        except:
            founded_date=''
            total_list['founded_date']=''
        
        
        lnks = driver.find_element(by=By.CLASS_NAME, value='pull-right')
        links = lnks.find_elements(by=By.XPATH , value ='//a')
        links = links[5:-2]

        link_list=[]
        for lnk in links:
            j = lnk.get_attribute('href')
            link_list.append(j)
        
        for i in link_list:
            if 'linkedin' in i:
                total_list['linkedin'] = i
            else:
                total_list['linkedin'] = ''
            if 'facebook' in i:
                total_list['facebook'] = i
            else:
                total_list['facebook'] = ''
            if 'twitter' in i:
                total_list['twitter'] = i
            else:
                total_list['twitter'] = ''
            
        total_list['play_store']=''
        total_list['app_store']=''
        total_list['location']=''
        total_list['rank']=''
        total_list['headquarter']=''
        total_list['people']=[]
        
        print(total_list)
        post_data(total_list)
#print(total_list)

