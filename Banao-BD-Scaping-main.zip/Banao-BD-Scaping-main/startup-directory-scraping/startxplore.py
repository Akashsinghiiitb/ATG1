import undetected_chromedriver.v2 as uc
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
import requests
import time
from langdetect import detect


class startup:
    lks = []
    link = 'https://startupxplore.com/en/search/startups?q=&hPP=20&idx=profiles&p='
    pg_no = 16
    detail_printed_count = 0
    
    def __init__(self):
        link = self.link + str(self.pg_no) + '&hFR%5Bprofiles.lvl0%5D%5B0%5D=Startups&is_v=1'
        driver.get(link)
        time.sleep(20)
        self.get_art_lks()

    def get_art_lks(self):
        try:
            links = driver.find_elements(By.XPATH,"//*[@class='ais-hits--item']//div[1]/a")
            if(links == []):
                raise Exception("#####---NOT FOUND---######")
        except:
            print("#####---NOT FOUND---######")
            return
        self.lks = []
        for i in links:
            self.lks.append(i.get_attribute('href'))
        self.open_art_lk()

    def open_art_lk(self):
        for art_link in self.lks:
            driver.delete_all_cookies()
            time.sleep(5)
            driver.get(art_link)
            try:
                self.print_details()
            except:
                pass
        self.get_next_page()

    def get_next_page(self):
        self.pg_no += 1
        nxt_url = self.link + str(self.pg_no) + '&hFR%5Bprofiles.lvl0%5D%5B0%5D=Startups&is_v=1'
        print(f"#######----Next Page URL {self.pg_no}---#########")
        driver.get(nxt_url)
        time.sleep(20)
        self.get_art_lks()
    
    def print_details(self):
        detail = {}
        time.sleep(3)

        title_val = driver.find_element(By.XPATH,"//*[@class='content-profile-principal']/h1")
        print(title_val.get_attribute('textContent'))
        detail["origin"] = "https://startupxplore.com"
        detail["company"] = title_val.get_attribute('textContent').strip()

        cat_val = ''
        for i in range(5):
            try:
                cat = driver.find_element(By.XPATH,f"//*[@class='content-data sectors']/ul/li[{i+1}]/a").get_attribute('textContent')
                cat_val += cat + ' ,'
            except:
                pass
        detail["category"] = cat_val

        try:
            socials = driver.find_elements(By.XPATH,"//*[@class='content-data social']//a")
            for i in socials:
                social_name = i.get_attribute('title')
                social_link = i.get_attribute('href')
                if social_name in ['Google+','Pinterest']:
                    pass
                else:
                    detail[social_name] = social_link
        except:
            pass

        try:
            web_val = driver.find_element(By.XPATH,"//*[@class='content-data website']/ul/li/a").get_attribute('href')
            detail['website'] = web_val
        except:
            pass

        try:
            desp_val = driver.find_element(By.XPATH,"//*[@class='block-content about-profile']//*[@class='html-content']").get_attribute('textContent')
            desp_val = desp_val.replace('\n','').strip()
            lang = detect(desp_val)
            if lang == 'es':
                return
            else:
                detail["description"] = desp_val
        except:
            pass

        try:
            locn_val = driver.find_element(By.XPATH,"//*[@class='block-content data-profile']//*[@class='dato']//*[@class='content']/a").get_attribute('textContent')
            locn_val = locn_val.strip()
            detail["location"] = locn_val.replace('\n','')
        except:
            pass
        
        detail["people"] = []
        founders_links = []
        founders_name = []
        
        try:
            founders_names = driver.find_elements(By.XPATH, "(//*[@class='block-content people-profile'])[1]//*[@class='content']")
            founders_link = driver.find_elements(By.XPATH, "(//*[@class='block-content people-profile'])[1]//a")
            for name,link in zip(founders_names,founders_link):
                founders_name.append(name.get_attribute('textContent').split('\n')[1].strip())
                founders_links.append(link.get_attribute('href'))
                print(name.get_attribute('textContent').split('\n')[1].strip())
                print(link.get_attribute('href'))
        except:
            pass

        for i,name in zip(founders_links,founders_name):
            try:
                time.sleep(3)
                driver.get(i)
            except:
                pass

            people = {}
            people['name'] = name


            try:
                socials = driver.find_elements(By.XPATH,"//*[@class='content-data social']//a")
                
                for i in zip(socials):
                    social_name = i.get_attribute('title')
                    social_link = i.get_attribute('href')
                    if social_name in ['Google+','Pinterest']:
                        pass
                    elif social_name == "Twitter":
                        people['twitter'] = social_link
                    elif social_name == "Facebook":
                        people['facebook'] = social_link
                    elif social_name == "Linkedin":
                        people['linkedin'] = social_link
                    elif social_name == "Youtube":
                        people['youtube'] = social_link
            except:
                pass

            try:
                web_val = driver.find_element(By.XPATH,"//*[@class='content-data website']/ul/li/a").get_attribute('href')
                people['website'] = web_val
            except:
                pass

            detail["people"].append(people)

        print(f"###### {self.detail_printed_count}")
        print(detail)
        post_data(detail)
        self.detail_printed_count += 1


def post_data(detail):
    url = "http://intranet.atg.party:8989/api/saveExternalCompanyDetails"

    myobj = detail

    x = requests.post(url, json = myobj)
    print(x.text)

## code starts form here
if __name__ == "__main__":
    
    chrome_options = Options()
    prefs = {"profile.default_content_setting_values": {'images': 2},}
    chrome_options.add_experimental_option('prefs',prefs)
    driver = webdriver.Chrome(options=chrome_options)
    driver.maximize_window()

    startup()