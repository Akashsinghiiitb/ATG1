import undetected_chromedriver.v2 as uc
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
import time
import requests

class countries:
    def __init__(self):
        countries = driver.find_elements(By.XPATH,"//td/a")
        for i in countries:
            print(i.get_attribute('href'))
            countries_lk.append(i.get_attribute('href'))

class per_country_lk:
    lks = []
    link = 'link'
    pg_no = 4
    detail_printed_count = 0
    
    def __init__(self,i):
        self.link = i + '/' + str(self.pg_no)
        driver.get(self.link)
        time.sleep(10)
        self.get_art_lks()

    def get_art_lks(self):
        try:
            links = driver.find_elements(By.XPATH,"//*[@class='ranks']/tr/td/div[2]/a")
            if(links == []):
                raise Exception("#####---NOT FOUND---######")
        except:
            print("#####---NOT FOUND---######")
            return
        self.lks = []
        for i in links:
            self.lks.append(i.get_attribute('href'))
        self.open_art_lk()
        # self.get_next_page()

    def open_art_lk(self):
        for art_link in self.lks:
            driver.delete_all_cookies()
            time.sleep(5)
            driver.get(art_link)
            try:
                self.print_details()
            except:
                pass
        self.get_next_page()

    def get_next_page(self):
        self.pg_no += 1
        nxt_url = self.link + '/' + str(self.pg_no)
        print(f"#######----Next Page URL {self.pg_no}---#########")
        driver.get(nxt_url)      
        self.get_art_lks()
    
    def print_details(self):
        detail = {}
        time.sleep(2)

        detail["origin"] = "www.startupranking.com"

        company_name = driver.find_element(By.XPATH,"//*[@class='su-info']/h2").text
        detail["company"] = company_name
        print(company_name)

        try:
            title = driver.find_element(By.XPATH,"//*[@class='su-phrase']").text
            detail["title"] = title
        except:
            pass

        try:
            WebDriverWait(driver, 5).until(
                EC.element_to_be_clickable((By.XPATH, "//*[@class='description_expandable_more']"))
            ).click()
        except:
            pass

        try:   
            desp = driver.find_element(By.XPATH,"//*[@class='su-info']/p").text
            detail["description"] = desp.replace('\n','')
        except:
            pass

        try:
            web = driver.find_element(By.XPATH,"//*[@class='su-info']/p[2]/a").text
            detail["website"] = web
        except:
            pass
        
        try:
            founded = driver.find_element(By.XPATH,"//*[@class='su-info']/p[2]").text
            detail["founded"] = founded.split(':')[3]
        except:
            pass

        try:
            fb_link = driver.find_element(By.XPATH,"//*[@class='su-info']/div/ul/li[1]/a").get_attribute('href')
            detail["facbook"] = fb_link
        except:
            pass

        try:
            twitter_link = driver.find_element(By.XPATH,"//*[@class='su-info']/div/ul/li[2]/a").get_attribute('href')
            detail["twitter"] = twitter_link
        except:
            pass

        try:
            linkedin_link = driver.find_element(By.XPATH,"//*[@class='su-info']/div/ul/li[3]/a").get_attribute('href')
            detail["linkedin"] = linkedin_link
        except:
            pass

        try:
            locn_state = driver.find_element(By.XPATH,"//*[@class='su-ranks']/li[3]").text
            locn_country = driver.find_element(By.XPATH,"//*[@class='su-ranks']/li[2]").text
            detail["location"] = locn_state + ", " + locn_country
        except:
            pass
        
        try:
            rank = driver.find_element(By.XPATH,"//*[@class='su-indicators group']/div[1]/h4").text
            rank_val = driver.find_element(By.XPATH,"//*[@class='su-indicators group']/div[1]/p").text
            detail[rank] = rank_val
        except:
            pass  


        detail["people"] = []
        founders_links = []
        founders_name = []
        founders_twitter = []
        founders_facebook = []
        founders_linkedin = []
        
        try:
            founders = driver.find_elements(By.XPATH, "(//*[@class='table-striped wide top-100 rank_table'])[5]//*[@class='name']/a")
            for founder in founders:
                founders_name.append(founder.text)
                founders_links.append(founder.get_attribute('href'))
                print(founder.text)
        except:
            pass

        for i in founders_links:
            try:
                time.sleep(3)
                driver.get(i)
            except:
                pass

            try:
                tw_link = driver.find_element(By.XPATH, "//*[@class='su-follow']//*[@class='twitter']").get_attribute('href')
                founders_twitter.append(tw_link)
            except:
                tw_link = ""
                founders_twitter.append(tw_link)

            try:
                fb_link = driver.find_element(By.XPATH, "//*[@class='su-follow']//*[@class='facebook']").get_attribute('href')
                founders_facebook.append(fb_link)
            except:
                fb_link = ""
                founders_facebook.append(fb_link)

            try:
                lkd_link = driver.find_element(By.XPATH, "//*[@class='su-follow']//*[@class='linkedin']").get_attribute('href')
                founders_linkedin.append(lkd_link)
            except:
                lkd_link = ""
                founders_linkedin.append(lkd_link)

        for founder, tw,fb,lkd in zip(founders_name,founders_twitter,founders_facebook,founders_linkedin):
            people = {}
            people["name"] = founder
            people["twitter"] = tw
            people["facebook"] = fb
            people["linkedin"] = lkd
            detail["people"].append(people)


        print(f"###### {self.detail_printed_count}")
        print(detail)
        post_data(detail)
        self.detail_printed_count += 1

def post_data(detail):
    url = "http://intranet.atg.party:8989/api/saveExternalCompanyDetails"

    myobj = detail

    x = requests.post(url, json = myobj)
    print(x.text)


## code starts form here
if __name__ == "__main__":

    driver = uc.Chrome()

    url = "https://www.startupranking.com/countries"
    driver.get(url)
    driver.maximize_window()

    countries_lk = []
    countries()
    
    for i in countries_lk:
        per_country_lk(i)
        