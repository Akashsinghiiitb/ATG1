
# This script is a web scraper and crawler

import requests as r
from bs4 import BeautifulSoup
from lxml import etree
from google_search import (
    mainFunc_Bing,
    mainFunc_Yahoo,
    mainFunc_Yandex,
    mainFunc_Brave,
    mainFunc_You,
    mainFunc_StartPage,
    mainFunc_Ecosia,
    mainFunc_SwissCows,
    mainFunc_DuckDuckGo,
    mainFunc_Google,
)
import os
import time
import random
from log_generator import generate_log, is_log_file_empty

search_functions = [
    mainFunc_Bing,
    mainFunc_Yahoo,
    mainFunc_Yandex,
    mainFunc_Brave,
    mainFunc_You,
    mainFunc_StartPage,
    mainFunc_Ecosia,
    mainFunc_SwissCows,
    mainFunc_DuckDuckGo,
    mainFunc_Google,
]

keywords_to_search = [
    "CEO",
    "Founder",
    "CFO",
    "CTO",
    "CMO",
    "Chief Marketing Officer",
    "Chief Public Officer",
    "Cheif Executive Officer",
    "Chief Financial Officer",
    "Chief Financie Officer",
    "Chief People Officer",
    "Chief Technology Officer",
    "Chief Revenue Officer",
    "Board Member",
    "Director",
    "President",
    "Investor",
    "co-chair",
    "Owner",
]

BASE_URL = "https://bbd.atg.party/flask"
BASE_URL_NODE = "https://bbd.atg.party"


os.system("cls")
print(
    "Version:23.11.20 \nGreetings from Banao Technologies!\n"
    "Please enter your Banao Token in the designated fields and relax while our program extracts the "
    "necessary data for you. We respect your privacy and want to assure you that any data entered by you will be not stored in any way."
    "Please note that this program is designed solely for the purpose of aiding Banao Technologies, and we strongly advise against using it for any other purpose.\n\n"
    "NOTE : This script will take 3 hours to complete."
)

token = input("Token > ")
option = input("Select one Option : \n1.Scrape\n2.Crawl\n\n> ")

# Formats and prints a message, then logs it.
def do_log(*message):
    output_data = ""
    for i in message:
        output_data += f"{i} "
    print(output_data)
    generate_log(output_data)

# Sends a POST request to get a run ID from the server.
def get_run_id(token):
    res = r.post(
        f"{BASE_URL_NODE}/api/create-entry-of-userstats",
        json={"token": token, "extension": "zaubacorp_exe"},
        timeout=90,
    )
    if res.status_code != 200:
        return None, res.text
    return res.json()["id"], None

#  Sends a POST request to increase the run count.
def increase_run_count(run_id):

    x = r.post(
        f"{BASE_URL_NODE}/api/increment-run-count",
        json={"id": run_id},
        headers={"auth": token},
        timeout=90,
    )
    do_log(x.text)


run_id, err = get_run_id(token)

if err:
    do_log(err)
    do_log("Wrong Token \n")
    input("Press enter to close and try again")
    exit()

start = time.time()

#  Checks if the script should stop running based on runtime.
def do_kill():
    try:
        run_time = time.time() - start
        do_log("Runtime: ", run_time)
        if run_time > 6 * 60 * 60:
            do_log("Run completed. You can close the script now.")
            return True
        return False
    except Exception as e:
        do_log("Error occurred in do_kill():", e)
        return False

# Initiates crawling process by sending requests to scrape links and save them.
def crawl():
    d = r.get(f"{BASE_URL}/crawl", timeout=60)
    links = d.json()["links"]
    company_links = []
    for url in links:
        raw_html = r.get(url, timeout=60)
        soup = BeautifulSoup(raw_html.text, "html.parser")
        company_links_tags = soup.select("#table a")
        for company_link in company_links_tags:
            company_links.append(company_link["href"])
        data = {"links": company_links, "crawl_link": url}
        res = r.post(f"{BASE_URL}/save_links", json=data, timeout=60)
        do_log(res.text)

#  Initiates scraping process by sending requests to retrieve HTML content from links and parse relevant data.
def scrape():
    try:
        # Retrieve links to scrape from the server
        links = r.get(f"{BASE_URL}/get_link", timeout=60).json()
        
        # Iterate through each link to scrape data
        for link in links:
            # Get HTML content of the link
            html = r.get(link, timeout=60, verify=False, headers={"User-Agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36"})
            page = BeautifulSoup(html.text, "html.parser")
            other_people = []

            try:
                # Extract directors' information
                director = page.select(".main-row p")
                name = page.select("h1")[0].text
                directors_list = []
                separate_lists = []
                chunk_size = 5
                
                # Split directors' information into chunks
                for i in range(0, len(director), chunk_size):
                    sublist = director[i : i + chunk_size]
                    separate_lists.append(sublist)

                # Iterate through each chunk of directors' information
                for sublist in separate_lists:
                    increase_run_count(run_id)
                    directors_data = {}
                    directors_data["url"] = None
                    directors_data["company"] = name
                    
                    # Parse each element of the chunk
                    for i, element in enumerate(sublist):
                        if i == 0:
                            directors_data["din"] = element.text
                        elif i == 1:
                            directors_data["name"] = element.text.strip()
                            directors_data["profile_link"] = element.find("a")["href"]
                            
                            try:
                                # Retrieve related company count from director's profile
                                increase_run_count(run_id)
                                director_profile_page = r.get(
                                    directors_data["profile_link"], timeout=60, verify=False
                                )
                                director_profile_soup = BeautifulSoup(
                                    director_profile_page.content, "html.parser"
                                )

                                dom = etree.HTML(str(director_profile_soup))
                                
                                # Search for related company count in the HTML tree
                                for i in range(1, 5):
                                    els = dom.xpath(
                                        f"/html/body/div[6]/div/div[1]/section/div[3]/section/div[{i}]/div/table[1]/tr"
                                    )
                                    if len(els) > 1:
                                        break
                                if len(els) == 0:
                                    directors_data["related_company_count"] = 1
                                else:
                                    directors_data["related_company_count"] = (
                                        len(els) - 1
                                    )
                            except Exception as e:
                                # Handle errors during profile scraping
                                do_log(f"Warning: error at profile scraping: {e}")
                                directors_data["related_company_count"] = 1
                            
                            try:
                                # Generate search query for Google
                                to_search = f"{directors_data['name'].replace(' ', '+')}+{name.replace(' ', '+')}"
                                to_search += " & ( "
                                for keyword in keywords_to_search:
                                    to_search += f"| '{keyword}' "
                                to_search += ")"
                                
                                i = 1
                                increase_run_count(run_id)
                                random_function = random.choice(search_functions)
                                google_data = random_function(to_search)

                                # Retry Google search if necessary
                                while i < 3:
                                    increase_run_count(run_id)
                                    if len(google_data) > 0:
                                        break
                                    random_function = random.choice(search_functions)
                                    google_data = random_function(to_search)
                                    i += 1
                                do_log(google_data)

                                # Extract Google search results
                                if len(google_data) > 0:
                                    directors_data["url"] = google_data[0]["url"]
                                    google_data.pop(0)
                                other_people = other_people + google_data
                            except Exception as e:
                                # Handle errors during Google search
                                do_log(f"Warning: Error at google search: {e}")
                                pass
                        elif i == 2:
                            directors_data["designation"] = element.text
                        elif i == 3:
                            directors_data["appointment_date"] = element.text
                    directors_list.append(directors_data)
            except Exception as e:
                # Handle errors during directors' list extraction
                do_log("error at director list: ", e)
                directors_list = []
            
            # Extract company information
            try:
                cin = page.select_one("thead td+ td p").text
            except:
                cin = None
            try:
                company_name = page.select_one(
                    ".col-xs-12:nth-child(1) tbody tr:nth-child(1) td+ td p"
                ).text
            except:
                company_name = None
            try:
                company_status = page.select_one(".table-striped p span").text
            except:
                company_status = None
            try:
                company_RoC = page.select_one(
                    ".col-xs-12 thead+ tbody tr:nth-child(3) td+ td p"
                ).text
            except:
                company_RoC = None
            try:
                company_regNo = page.select_one("tr:nth-child(4) td+ td p").text
            except:
                company_regNo = None
            try:
                company_category = page.select_one("tr:nth-child(5) td+ td p").text
            except:
                company_category = None
            try:
                company_sub_category = page.select_one("tr:nth-child(6) td+ td p").text
            except:
                company_sub_category = None
            try:
                company_class = page.select_one("tr:nth-child(7) td+ td p").text
            except:
                company_class = None
            try:
                company_date_of_inc = page.select_one("tr:nth-child(8) td+ td p").text
            except:
                company_date_of_inc = None
            try:
                company_age = page.select_one("tr:nth-child(9) td+ td p").text
            except:
                company_age = None
            try:
                company_activity = page.select_one(
                    "tr:nth-child(10) td+ td p:nth-child(1)"
                ).text
            except:
                company_activity = None
            try:
                company_no_of_members = page.select_one(
                    "tr:nth-child(11) td+ td p"
                ).text
            except:
                company_no_of_members = None

            try:
                company_email = page.select_one(
                    ".col-12 .col-xs-12 p:nth-child(1)"
                ).text.split(":")[-1]
            except:
                company_email = None
            try:
                company_address = page.select("p:nth-child(4)")[1].text
            except:
                company_address = None
            try:
                share_cap = page.select(".col-sm-12:nth-child(4)")
                company_auth_capital = share_cap[0].find_all("p")[1].text
                company_paid_up_capital = share_cap[0].find_all("p")[3].text
            except:
                company_auth_capital = None
                company_paid_up_capital = None
            try:
                company_listing_status = page.select_one(
                    ".col-xs-12+ .col-xs-12 thead td+ td p"
                ).text
            except:
                company_listing_status = None
            try:
                company_last_agm = page.select_one(
                    ".col-xs-12+ .col-xs-12 thead+ tbody tr:nth-child(1) td+ td p"
                ).text
            except:
                company_last_agm = None
            try:
                company_latest_balsheet = page.select_one(
                    ".col-xs-12+ .col-xs-12 thead+ tbody tr+ tr td+ td p"
                ).text
            except:
                company_latest_balsheet = None

            # Construct company data dictionary
            company_data = {
                "cin": cin,
                "name": company_name,
                "zaubacorp_url": link,
                "status": company_status,
                "headquarter": company_RoC,
                "registration_number": company_regNo,
                "fundingType": company_category + " " + company_sub_category,
                "companyType": company_class,
                "founded": company_date_of_inc,
                "age": company_age,
                "description": company_activity,
                "director_count": company_no_of_members,
                "email": company_email,
                "location": company_address,
                "data": {
                    "Authorized Capital": company_auth_capital,
                    "Paid-up Capital": company_paid_up_capital,
                    "Listing Status": company_listing_status,
                    "Last AGM": company_last_agm,
                    "Latest Balance Sheet": company_latest_balsheet,
                },
                "peoples": directors_list,
                "other_people": other_people,
            }

            # Log final company data
            do_log("final data ->", company_data)
            
            # Send company data to the server
            response = r.post(f"{BASE_URL}/company", json=company_data, timeout=60)
            do_log(response.text)
    except Exception as e:
        # Handle any errors that occur during the scraping process
        do_log("Error occurred while scraping:", e)


# Executes only if log file is empty(once per day)
if is_log_file_empty():
    # URL need to be update
    to_search = r.get('http://127.0.0.1:5000/get-string')
    i=0
    while i < 3:
        increase_run_count(run_id)
        random_function = random.choice(search_functions)
        google_data = random_function(to_search)
        i += 1
    do_log(google_data)

try:
    while True:
        if option == "1":
            try:
                res = r.get(f"{BASE_URL}/check_scrape", timeout=60).json()
                do_log(res)
                if res["response"]:
                    scrape()
                else:
                    choice = input(
                        "Nothing to scrape, press 'y' to crawl, or 'n' to exit > "
                    )
                    if choice == "y":
                        crawl()
                    else:
                        do_log("Exiting...")
                        break
            except r.exceptions.RequestException as req_err:
                do_log(f"Error during check_scrape - Request Exception: {req_err}")
            except Exception as e:
                do_log(f"Error during check_scrape: {e}")
        elif option == "2":
            try:
                res = r.get(f"{BASE_URL}/check_crawl", timeout=60).json()
                do_log(res)
                if res["response"]:
                    crawl()
                else:
                    input("No more links left to crawl...")
                    break
            except r.exceptions.RequestException as req_err:
                do_log(f"Error during check_crawl - Request Exception: {req_err}")
            except Exception as e:
                do_log(f"Error during check_crawl: {e}")

        try:
            increase_run_count(run_id)
            if do_kill():
                break
        except KeyboardInterrupt:
            do_log("Script interrupted by the user.")
            break
        except r.exceptions.RequestException as req_err:
            do_log(f"Error during run count increase - Request Exception: {req_err}")
        except Exception as e:
            do_log(f"Error during run count increase: {e}")

except KeyboardInterrupt:
    do_log("Script manually stopped by the user.")
except r.exceptions.RequestException as req_err:
    do_log(f"Fatal error - Request Exception: {req_err}")
except Exception as e:
    do_log(f"Fatal error: {e}")

