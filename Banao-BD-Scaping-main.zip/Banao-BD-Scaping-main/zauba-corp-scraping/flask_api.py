# This Flask application is designed to scrape data from the website "zaubacorp.com" 
# which contains information about companies and directors.
# It utilizes SQLAlchemy for database management and Beautiful Soup for web scraping.
# The application has several routes for fetching, saving, and processing data.


from flask import Flask, request,jsonify
from flask_sqlalchemy import SQLAlchemy
from bs4 import BeautifulSoup
import requests as r

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'  # SQLite database
db = SQLAlchemy(app)

cities = [
    'Delhi', 'Mumbai', 'Kolkata', 'Bangalore', 'Hyderabad', 'Chennai', 'Pune', 'Ahmedabad', 'Jaipur',
    'Indore', 'Lucknow', 'Thane', 'Gurgaon', 'Patna', 'Surat', 'Coimbatore', 'Nagpur', 'Bhubaneswar',
    'Howrah', 'Chandigarh', 'Ernakulam', 'Secunderabad', 'Kanpur', 'Bhopal', 'Vadodara', 'Guwahati',
    'Agra', 'Raipur', 'Nashik', 'Rajkot', 'Ludhiana', 'Noida', 'Aurangabad', 'Ghaziabad', 'Faridabad',
    'Udaipur', 'Visakhapatnam', 'Thrissur', 'Ranchi', 'Trivandrum', 'Gwalior', 'Goa', 'Varanasi',
    'Kolhapur', 'Siliguri', 'Kochi', 'Cuttack', 'Cochin', 'Vijayawada'
]
#  Represents links to the main pages of each city's company listing.
class MainPageLinks(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    link = db.Column(db.String(255))
    status = db.Column(db.String(50))

#  Stores temporary links to individual company pages for scraping.
class TemporaryLink(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    link = db.Column(db.String(255))
    status = db.Column(db.String(50))
    location = db.Column(db.String(20))

# Stores details of directors associated with companies.
class DirectorsDetails(db.Model):
    id = db.Column(db.Integer,primary_key=True)
    din = db.Column(db.String(30), unique=True)
    name = db.Column(db.String(30))
    company = db.Column(db.String(255))
    profile_link = db.Column(db.String(50))
    designation = db.Column(db.String(30))
    appointment_date = db.Column(db.String(30))

# Stores the current state of web crawling.    
class CrawlingStatus(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    current_city_index = db.Column(db.Integer)
    current_link_index = db.Column(db.Integer)

# Stores details of companies scraped from the website.
class CompanyDetail(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    cin = db.Column(db.String(50))
    company_name = db.Column(db.String(255))
    link = db.Column(db.String(255))
    company_status = db.Column(db.String(50))
    company_RoC = db.Column(db.String(50))
    company_regNo = db.Column(db.String(50))
    company_category = db.Column(db.String(50))
    company_sub_category = db.Column(db.String(50))
    company_class = db.Column(db.String(50))
    company_date_of_inc = db.Column(db.String(50))
    company_age = db.Column(db.String(50))
    company_activity = db.Column(db.String(255))
    company_no_of_members = db.Column(db.Integer)
    company_email = db.Column(db.String(255))
    company_address = db.Column(db.String(255))
    company_auth_capital = db.Column(db.String(50))
    company_paid_up_capital = db.Column(db.String(50))
    company_listing_status = db.Column(db.String(50))
    company_last_agm = db.Column(db.String(50))
    company_latest_balsheet = db.Column(db.String(50))

# Scrapes links to all pages of company listings for each city and stores them in the database.
def push_all_pages():
    for city in cities:
        home_page = r.get(f'https://www.zaubacorp.com/company-list/city-{city}/status-Active-company.html')
        soup = BeautifulSoup(home_page.text, 'html.parser')
        s = soup.select_one('#block-system-main div div span').text
        max_page = int(s.split()[-1].replace(',', ''))  # Remove comma from the string
        print(f"City : {city} , Max page : {max_page}")
        for i in range(1,max_page+1):
            url = f'https://www.zaubacorp.com/company-list/city-{city}/status-Active/p-{i}-company.html'
            link_entry = MainPageLinks(link=url, status='pending')
            db.session.add(link_entry)
        db.session.commit()

#  Retrieves the total count of records in the TemporaryLink table.
@app.route('/fetch_count')
def fetch_count():
    count = TemporaryLink.query.count()
    return f'Total records in TemporaryLink: {count}'

# Provides a link to scrape by fetching a link from the TemporaryLink table.
@app.route('/get_link')
def get_link():
    crawling_status = CrawlingStatus.query.first()
    if crawling_status:
        row = TemporaryLink.query.offset(crawling_status.current_link_index).first()
        row.status = "completed"
        crawling_status.current_link_index += 1
        db.session.commit()
        return row.link
    else:
        status = CrawlingStatus(current_city_index=0,current_link_index=0)
        db.session.add(status)
        db.session.commit()
        row = TemporaryLink.query.first()
        return row.link

# Creates database tables before handling any request.
@app.before_request
def create_tables():
    db.create_all()

# Saves links received in the request body to the TemporaryLink table.
@app.route('/save_links',methods=['POST'])
def save_links():
    data = request.json
    links = data["links"]
    for link in links:
        temporary_link = TemporaryLink(link=link, status='pending',location="-")
        db.session.add(temporary_link)
    db.session.commit()
    return f"{len(links)} links added to database"

# Initiates the crawling process by fetching a batch of links from the MainPageLinks table.
@app.route('/crawl')
def crawl():
    if MainPageLinks.query.first() is None:
        push_all_pages()
    links_list = []
    links = MainPageLinks.query.filter_by(status='pending').limit(5).all()
    # Update the status of retrieved rows to "completed"
    for link in links:
        links_list.append(link.link)
        link.status = 'completed'
        db.session.commit()
    
    data = {"links":links_list}
    return data

# Checks if there are pending links to crawl.
@app.route('/check_crawl')
def check_crawl():
    pending_links_count = MainPageLinks.query.filter_by(status='pending').count()
    if pending_links_count:
        return {"response":True}
    else:
        return {"response":False }
    
# Checks if there are pending links to scrape.
@app.route('/check_scrape')
def check_scrape():
    pending_links_count = TemporaryLink.query.filter_by(status='pending').count()
    print("Pending Links : ",pending_links_count)
    if pending_links_count:
        return {"response":True}
    else:
        return {"response":False }
    
# Creates a new company entry in the database.
@app.route('/company', methods=['POST'])
def create_company():
    company_data = request.json  # Assuming the data is sent as JSON in the request body
    # Extract values from the company_data dictionary
    cin = company_data.get('CIN')
    company_name = company_data.get('Company Name')
    link = company_data.get('Company Link')
    company_status = company_data.get('Company Status')
    company_RoC = company_data.get('Company RoC')
    company_regNo = company_data.get('Company Registration Number')
    company_category = company_data.get('Company Category')
    company_sub_category = company_data.get('Company Sub-Category')
    company_class = company_data.get('Company Class')
    company_date_of_inc = company_data.get('Company Date of Incorporation')
    company_age = company_data.get('Company Age')
    company_activity = company_data.get('Company Activity')
    company_no_of_members = company_data.get('Company Number of Members')
    company_email = company_data.get('Company Email')
    company_address = company_data.get('Company Address')
    company_auth_capital = company_data.get('Company Authorized Capital')
    company_paid_up_capital = company_data.get('Company Paid-up Capital')
    company_listing_status = company_data.get('Company Listing Status')
    company_last_agm = company_data.get('Company Last AGM')
    company_latest_balsheet = company_data.get('Company Latest Balance Sheet')
    directors_list = company_data.get('Company Directors')

    # Create a new CompanyDetail object and add it to the database
    company_detail = CompanyDetail(cin=cin, company_name=company_name, link=link, company_status=company_status,
                                    company_RoC=company_RoC, company_regNo=company_regNo,
                                    company_category=company_category,
                                    company_date_of_inc=company_date_of_inc, company_age=company_age,
                                    company_activity=company_activity,
                                    company_no_of_members=company_no_of_members, company_email=company_email,
                                    company_address=company_address, company_auth_capital=company_auth_capital,
                                    company_paid_up_capital=company_paid_up_capital,
                                    company_listing_status=company_listing_status,
                                    company_last_agm=company_last_agm,
                                    company_latest_balsheet=company_latest_balsheet)
    # company_detail.set_directors_list(directors_list)
    db.session.add(company_detail)
    db.session.commit()

    return 'Company created successfully', 201


# Creates a new director entry in the database.
@app.route('/director', methods=['POST'])
def create_director():
    director_data = request.json
    directors_list = director_data["Company Directors"]
    try:
        for director in directors_list:
            new_director = DirectorsDetails(din = director.get("din"),
                                            name = director.get("name"),
                                            profile_link = director.get("profile_link"),
                                            designation = director.get("designation"),
                                            appointment_date = director.get("appointment_date"),
                                            company=director.get("company"),)
            db.session.add(new_director)
            db.session.commit()

    except:
        return "Director already exists in table", 400
    
    return "Director Created successfully", 201

#  Runs the Flask application in debug mode.
app.run(debug=True)