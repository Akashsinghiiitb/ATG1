import mysql.connector
import csv
from datetime import datetime


## Scrapedb 2
# mydb = mysql.connector.connect(
#   host="scrapdb2.crbyejbc1y6i.ap-south-1.rds.amazonaws.com",
#   user="ankeeta",
#   password="password",
#   database="BanaoBDTest"
# )

mydb = mysql.connector.connect(
  host="scrapdb2.crbyejbc1y6i.ap-south-1.rds.amazonaws.com",
  user="ankeeta",
  password="password",
  database="BanaoBDTest"
)

people_file = open('people.csv', 'r')
peoples = csv.reader(people_file)
peoples_list = []
country_list = []
region_list = []
city_list = []
for people in peoples:
    country_list.append(people[11])
    region_list.append(people[10])
    city_list.append(people[9])
    peoples_list.append(people)

# mydb.autocommit = True
mycursor = mydb.cursor()
mycursor_details = mydb.cursor()
mycursor_check = mydb.cursor()

i = 548285
j = i

time_a = 0
time_c = 0

i = 548287
j = i

for people in peoples_list[i:]:
    time = datetime.now()
    # print(j)
    new = False
    people_added = 0
    people_details_updated = 0
    people_details_added = 0
    name = str(people[2]) + " " + str(people[3])
    name = name.replace('"','')
    url = str(people[4]).split('?')[0]
<<<<<<< Updated upstream
    facebook = people[6].replace("""\\""","")
    twitter = people[7].replace("""\\""","")
    linkedin = people[8].replace("""\\""","")
    location = str(people[9]) + " " +str(people[10]) + " " + str(people[11])
    position = str(people[12])
    start_time = datetime.now()
    print((f"""SELECT id FROM people WHERE url LIKE "{str(url)}%" COLLATE utf8mb4_general_ci;"""))
    try:
        mycursor_check.execute(f"""SELECT id FROM people WHERE url LIKE "{str(url)}%";""")
=======
    facebook = people[6]
    twitter = people[7]
    linkedin = people[8]
    linkedin = linkedin.replace('"','')
    location = str(people[9]) + " " +str(people[10]) + " " + str(people[11])
    position = str(people[12])
    position = position.replace('"','')
    try:
        mycursor_check.execute(f"""SELECT id FROM people WHERE url LIKE "{url}%";""")
>>>>>>> Stashed changes
    except:
        mycursor = mydb.cursor()
        mycursor_check.execute(f"""SELECT id FROM people WHERE url LIKE "{str(url)}%" COLLATE utf8mb4_general_ci;""")
    rows = mycursor_check.fetchall()
    end_time = datetime.now()
    time_taken = end_time - start_time
    sec = time_taken.seconds
    print("time taken -> ", sec)
    time_a = time_a + sec
    time_c = time_c + 1
    print("avarage time -> ", time_a/time_c)
    count = len(rows)
    # print("count-> ", count)
    if count == 0:
        mycursor.execute(
            f"""
            INSERT INTO people (url, name, source, createdAt, updatedAt) VALUES ("{url}", "{name}", "crunchbase", "{time}", "{time}");
            """)
        mydb.commit()
        last_people_id = mycursor._last_insert_id
        new = True
        people_added = mycursor.rowcount
    else:
        last_people_id = rows[0][0]
    print("last_people_id -> ", last_people_id)
    if not new:
        print("Not New")
        mycursor_check.execute(f"""SELECT id FROM people_details WHERE people_id = {last_people_id} ;""")
        details_rows = mycursor_check.fetchall()
        details_count = len(rows)
        if details_count > 0:
            print(f"""UPDATE people_details SET position="{position}", twitter="{twitter}", linkedin="{linkedin}", facebook="{facebook}", location="{location}", updatedAt="{time}" WHERE people_id={last_people_id} ;""")
            mycursor_details.execute(f"""UPDATE people_details SET position="{position}", twitter="{twitter}", linkedin="{linkedin}", facebook="{facebook}", location="{location}", updatedAt="{time}" WHERE people_id={last_people_id} ;""")
            people_details_updated = 1
        else:
            print(f"""INSERT INTO people_details (people_id, position, twitter, linkedin, facebook, location, createdAt, updatedAt) VALUES ({last_people_id}, "{position}", "{twitter}", "{linkedin}", "{facebook}", "{location}", "{time}", "{time}");""")
            mycursor_details.execute(f"""INSERT INTO people_details (people_id, position, twitter, linkedin, facebook, location, createdAt, updatedAt) VALUES ({last_people_id}, "{position}", "{twitter}", "{linkedin}", "{facebook}", "{location}", "{time}", "{time}");""")
            people_details_added = mycursor_details.rowcount
        
    else:
        print(f"""INSERT INTO people_details (people_id, position, twitter, linkedin, facebook, location) VALUES {last_people_id}, "{position}", "{twitter}", "{linkedin}", "{facebook}", "{location}");""")
        mycursor_details.execute(f"""INSERT INTO people_details (people_id, position, twitter, linkedin, facebook, location, createdAt, updatedAt) VALUES ({last_people_id}, "{position}", "{twitter}", "{linkedin}", "{facebook}", "{location}", "{time}", "{time}");""")
        people_details_added = mycursor_details.rowcount

    mydb.commit()
    print(f"index-> {j}  saved=> people:{people_added}  people details: {people_details_added}  people details updated: {people_details_updated}")

    j = j + 1
    # break
