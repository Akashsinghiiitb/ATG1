from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .forms import FileForm
from .tasks import process_file_task
from django.contrib import messages
from django.http import HttpResponse
import subprocess
import os

def landing_page(request):
    return render(request,"Files/index.html")

@login_required()
def home(request):
    context = {'form':FileForm()}
    if request.method=="POST":
        form = FileForm(request.POST,request.FILES)
        form.instance.admin = request.user
        form.instance.file_status = "Processing"
        if form.is_valid():
            form.save()
            process_file_task("Processing")
            return HttpResponse("File uploaded successfully")
    return render(request,"Files/home.html",context)