import logging
from .models import Files
from background_task import background
from .inserting_rec import insert_records_to_db
logging.basicConfig(filename='example.log',filemode="w", level=logging.DEBUG)
@background(schedule=5)
def process_file_task(file_status):
    for i in Files.objects.filter(file_status=file_status):
        if i.file_type=="Company":
            insert_records_to_db("Company",i.file_name )
        elif i.file_type=="People":
            insert_records_to_db("People",i.file_name )
        elif i.file_type=="Search":
            insert_records_to_db("Search",i.file_name )
        i.file_status="Processed"
        i.save()