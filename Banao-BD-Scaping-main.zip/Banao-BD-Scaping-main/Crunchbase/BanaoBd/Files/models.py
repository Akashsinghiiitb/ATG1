from django.db import models
from django.contrib.auth.models import User

class Files(models.Model):
    file_name = models.FileField(upload_to="csv_files")
    file_type_choices = [
        ['Company','Company']
        ,["People","People"],
        ["Search","Search"],]
    file_type = models.CharField(max_length=101,choices=file_type_choices)
    file_status_choices = [
        ['Processed','Processed'],
        ['Processing','Processing'],
        ['Not Processed','Not Processed']
    ]
    file_status = models.CharField(max_length=101,choices=file_status_choices)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    admin = models.ForeignKey(User,null=True,blank=False,on_delete=models.SET_NULL)
    def __str__(self):
        return f"{self.file_name} {self.file_type}"
    class Meta:
        verbose_name_plural="Files"