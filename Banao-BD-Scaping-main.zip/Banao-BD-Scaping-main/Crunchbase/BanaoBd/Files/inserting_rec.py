import re
import sys
import csv
import logging
import traceback
import mysql.connector
import environ
import os
env = environ.Env()
DIR= os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
environ.Env.read_env(os.path.join(DIR, '.env'))
logging.basicConfig(filename="/home/ubuntu/banaobd/Banao-BD-Scaping/Crunchbase/BanaoBd/logs/database_insert.log",)

def insert_records_to_db(type,file_location):
    mydb = mysql.connector.connect(
      host=env("MYSQL_HOST"),
      user=env("MYSQL_USERNAME"),
      password=env("MYSQL_PASSWORD"),
      database=env("DATABASE"),
    )
    mycursor = mydb.cursor()
    if type=="Company":
        smt = """INSERT INTO Banaobd.companies (url,name,source) VALUES (%s,%s,%s)"""
    elif type=="People":
        smt = """Insert into Banaobd.people (url,name,source) VALUES (%s,%s,%s)"""
    elif type=="Search":
        smt = """Insert into Banaobd.search_people(url,name,source) VALUES(%s,%s,%s)"""
    
    with open(file_location.path) as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        count = 0
        logging.info(f"Processing file {file_location}")
        for j in csv_reader:
            if count==0:#Excluding the column names like (name,url,title)
                count = count + 1
                continue
            else:
                values=j
                if len(values)==2:
                    values.append("Linkedin")
                values = tuple(values)
                url = values[0]
                regex = ("((http|https)://)(www.)?" +
                    "[a-zA-Z0-9@:%._\\+~#?&//=]" +
                    "{2,256}\\.[a-z]" +
                    "{2,6}\\b([-a-zA-Z0-9@:%" +
                    "._\\+~#?&//=]*)")
                if re.search(regex,url):#If regext is valid the insert record into database
                    try:
                        mycursor.execute(smt,values)
                    except Exception as ex:
                        #If any error occurs then logging to a file
                        logging.error(sys.exc_info()[1])
                    mydb.commit()
                else:
                    logging.error(f"The url is invalid in the file {file_location} and the record is{count}")#The url is wrong
            count = count + 1
