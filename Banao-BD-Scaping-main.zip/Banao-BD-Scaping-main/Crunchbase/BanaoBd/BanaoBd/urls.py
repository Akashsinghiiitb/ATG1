from django.contrib import admin
from django.urls import path
from Files.views import landing_page,home
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.auth.views import LoginView
urlpatterns = [
    path('admin/', admin.site.urls),
    path("",landing_page),
    path("home/",home,name='home'),
    path("login/",LoginView.as_view(template_name='admin/login.html'),name="login")
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
