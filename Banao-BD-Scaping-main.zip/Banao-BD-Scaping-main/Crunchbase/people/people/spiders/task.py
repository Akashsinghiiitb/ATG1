import scrapy
from xml.dom import minidom
import gzip
from xml.dom.minidom import parseString
import csv

class TaskSpider(scrapy.Spider):
    name = 'task'
    start_urls = ['https://www.amazon.in//']
    dom = minidom.parse(r"C:\Users\sathw\santy\Internship\crunchbase\people\sitemap-index.xml")
    global value
    value= dom.getElementsByTagName('sitemap')

    def parse(self,response):
        #To get the urls to download the files from sitemaps
        links = []
        url = ' '
        for data in value:
            url = data.getElementsByTagName('loc')[0].childNodes[0].nodeValue
            if "https://www.crunchbase.com/www-sitemaps/sitemap-people" in url:
                links.append(url)
        i = 0
        for link in links:
            i = i + 1
            # Download the sitemaps files and rename them
            yield{
                'file_urls' : [link],
                'i' : str(i)
            }
        length = len(links)
        print(length)
        # Opening the downloaded XML zip files and reading the data from the files
        for i in range(1,length):  
            print("stage 1")
            company_url = []
            company_name = []
            source = []         
            infile = gzip.open(rf"C:\Users\sathw\santy\Internship\crunchbase\people\downloaded_files\{str(i)}.xml.gz")
            content = infile.read()
            dom = parseString(content)
            name = dom.getElementsByTagName('url')
            for data in name:
                url = data.getElementsByTagName('loc')[0].childNodes[0].nodeValue
                company_url.append(url)
                images = data.getElementsByTagName('image:image')
                for image in images:
                    name = image.getElementsByTagName('image:title')[0].childNodes[0].nodeValue
                    company_name.append(name)
                s = 'crunchbase'
                source.append(s)
            # Storing the data into the CSV files
            with open(f"{str(i)}_xmlfile.csv","w",newline ="",encoding="UTF_8") as csvfile:
                data = csv.writer(csvfile)
                headers = ['url','name','source']
                data.writerow(headers)
                for name,url,s in zip(company_name,company_url,source):
                    try:
                        headers = [f'{url}',f'{name}',f'{s}']
                        data.writerow(headers)
                    except UnicodeEncodeError:
                        name = url[40:]
                        headers = [f'{url}',f'{name}',f'{s}']
                        data.writerow(headers) 
