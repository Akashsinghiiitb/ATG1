# Scrapy settings for people project
#
# For simplicity, this file contains only settings considered important or
# commonly used. You can find more settings consulting the documentation:
#
#     https://docs.scrapy.org/en/latest/topics/settings.html
#     https://docs.scrapy.org/en/latest/topics/downloader-middleware.html
#     https://docs.scrapy.org/en/latest/topics/spider-middleware.html

BOT_NAME = 'people'

SPIDER_MODULES = ['people.spiders']
NEWSPIDER_MODULE = 'people.spiders'


USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.246'
ROBOTSTXT_OBEY = False
RETRY_HTTP_CODES = [403]
DOWNLOAD_DELAY = 10
HTTPERROR_ALLOWED_CODES = [404]

ITEM_PIPELINES = {
   'people.pipelines.CustumFilePipelines': 1,
}
FILES_STORE = 'downloaded_files'

