import subprocess
import requests
while(1):
    response = requests.get("https://banao-bd-scrapper-testing.herokuapp.com/api/ask-crunch-config")
    print(response.status_code)
    details = response.json()
    print(details)
    try:
        links = []
        for i in details:
            links.append(i['url'])
        for i in links:
            subprocess.call(f'scrapy crawl company_details -a start_url={i}',shell= True)
    except TypeError:
        print("Scrapping Completed")
        exit()