# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class CompanyDetailItem(scrapy.Item):
    Company_Name = scrapy.Field()
    location = scrapy.Field()
    members = scrapy.Field()
    funding_type = scrapy.Field()
    company_type = scrapy.Field()
    company_url = scrapy.Field()
    rank = scrapy.Field()
    people_url = scrapy.Field()
    contact_url = scrapy.Field() 
    person_name = scrapy.Field()
    person_url = scrapy.Field()
    person_position = scrapy.Field()
    people = scrapy.Field()
