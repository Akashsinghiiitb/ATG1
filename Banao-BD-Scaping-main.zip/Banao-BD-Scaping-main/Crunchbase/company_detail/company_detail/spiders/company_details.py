import scrapy
from urllib.parse import urljoin
import requests

class CompanyDetailsSpider(scrapy.Spider):
    name = 'company_details'
    def __init__(self, name=None, **kwargs):
        super(CompanyDetailsSpider,self).__init__(name, **kwargs)
        self.start_urls = [kwargs.get('start_url')]
    def parse(self,response): 
        link = response.url
        print(link)
        #To scrapy the start_urls and get required information
        person_name = []
        person_url = []
        person_position = []
        loc = ""
        r = ""
        #Accessing the required information in webpage using the xpath
        location = response.xpath("//ul[@class='icon_and_value']/li/label-with-icon/span/field-formatter/identifier-multi-formatter/span/a/text()").extract()
        for l in location:
            if loc:
                loc = loc + ',' + l
            else:
                loc = l
        company_type = response.xpath("//ul[@class='icon_and_value']/li/label-with-icon/span/field-formatter/span/text()").extract()
        company_url = response.xpath("//ul[@class='icon_and_value']/li/label-with-icon/span/field-formatter/link-formatter/a/text()").extract()
        members = response.xpath("//ul[@class='icon_and_value']/li/label-with-icon/span/field-formatter/a[contains(@href , 'num_employees_enum')]/text()").extract()
        funding_type = response.xpath("//ul[@class='icon_and_value']/li/label-with-icon/span/field-formatter/a[contains(@href , 'last_funding_type')]/text()").extract()
        rank = response.xpath("//ul[@class='icon_and_value']/li/label-with-icon/span/field-formatter/a[contains(@href , 'rank_org_company')]/text()").extract()
        Company_Name = response.xpath("//h1[@class='profile-name']/text()").extract()
        url = response.xpath("//div[@class='mat-tab-links']/a[contains(@href , 'people')]/@href").extract()
        urls = urljoin("https://www.crunchbase.com",url[0])
        contact_phone = response.xpath("//fields-card/ul/li/field-formatter[@class='ng-star-inserted']/blob-formatter/span/text()").extract()
        description = response.xpath("//div[@class='section-content-wrapper']/div/description-card/div/span/text()").extract()
        founded_date = response.xpath("//span[@class='component--field-formatter field-type-date_precision ng-star-inserted']/text()").extract()
        Headquarters = response.xpath("//ul[@class='text_and_value']/li//span[@class='component--field-formatter field-type-identifier-multi']/a[contains(@href , 'search')]/text()").extract()
        Industries  = response.xpath("//span/chips-container/a/chip/div/div/text()").extract()
        for i in response.xpath("//ul[@class='text_and_value']/li//span[@class='component--field-formatter field-type-identifier-multi']/a[contains(@href , 'person')]"):
            name = i.xpath("./text()").extract()
            person_name.append(name[0])
            url1 = i.xpath("./@href").extract()
            url1s = urljoin("https://www.crunchbase.com",url1[0])
            person_url.append(url1s)
            position = 'Founder'
            person_position.append(position)
        person = []
        for n,u,p in zip(person_name,person_url,person_position):
            peo = {
                    'name' : n,
                    'url' : u,
                    'position' : p,
                    'source' : 'crunchbase'
                }
            person.append(peo)
        if Headquarters:
            for l in Headquarters:
                if r:
                    r = r + ',' + l
                else:
                    r =  l
        yield scrapy.Request(urls,callback=self.people,errback = self.errback_httpbin,dont_filter=True,
        #Sending the variables value to the next callback function
        meta = {'Company_Name' : Company_Name,
        'location':loc,
        'company_type' : company_type,
        'company_url' : company_url,
        'members':members,
        'funding_type':funding_type,
        'rank':rank,
        'contact_phone':contact_phone,
        'people' : person,
        'link':link,
        'description':description,
        'founded_date':founded_date,
        'Headquarters': r,
        'Industries':Industries})
        

    def people(self,response):
        #Reciving the variables value to the perivous function
        details = []
        person_url = []
        person_position = []
        person_name = []
        Industries = response.request.meta['Industries']
        link = response.request.meta['link']
        person = response.request.meta['people']
        contact_phone = response.request.meta['contact_phone']
        location = response.request.meta['location']
        company_type = response.request.meta['company_type']
        website = response.request.meta['company_url']
        members = response.request.meta['members']
        funding_type = response.request.meta['funding_type']
        rank = response.request.meta['rank']
        description = response.request.meta['description']
        founded_date = response.request.meta['founded_date']
        headquarter = response.request.meta['Headquarters']
        if members:
            size = members[0]
            if '-' in size and '+' in size:
                k = size.split('-').replace("+", "")
                employeeSize = int(k[1])
            elif '-' in size:
                k = size.split('-')
                employeeSize = int(k[1])
            elif '+' in size:
                k = size.replace("+", "")
                employeeSize = int(k)
            else:
                employeeSize = int(size)
        else:
            size = " "
        data ={
                'url' : link,
                'website' : "",
                'companyType' : "",
                'fundingType' : "",
                'location' : "", 
                'companyEmail' : "",
                'rank' : "",
                'employeeSize' : "",
                'people' : "",
                'description': "",
                'founded':"",
                'headquarters':"",
                'number':"",
                'domain' : ""
            }
        if contact_phone:
            if len(contact_phone) == 3:
                temp = contact_phone[2].replace('+',"").replace(' ',"").replace('-',"").replace('(',"").replace(')',"")
                data['number'] = int(temp)
                data['companyEmail'] = contact_phone[1]
            elif len(contact_phone) == 2:
                try:
                    temp = contact_phone[1].replace('+',"").replace(' ',"").replace('-',"").replace('(',"").replace(')',"")
                    data['number'] = int(temp)
                except ValueError:
                    data['companyEmail'] = contact_phone[1]
        i = ""
        if Industries:
            for l in Industries:
                if i:
                    i = i + ',' + l
                else:
                    i = l
        data['domain'] = i
        if contact_phone:
            if len(contact_phone) > 3:
                temp = contact_phone[2].replace('+',"").replace(' ',"").replace('-',"").replace('(',"").replace(')',"")
                data['number'] = int(temp)
                data['companyEmail'] = contact_phone[1]
            elif len(contact_phone) > 2:
                try:
                    temp = contact_phone[1].replace('+',"").replace(' ',"").replace('-',"").replace('(',"").replace(')',"")
                    data['number'] = int(temp)
                except ValueError:
                    data['companyEmail'] = contact_phone[1]
        if description:
            data['description'] = description[0] 
        else:
            data['description'] = " "
        if founded_date:
            data['founded'] = founded_date[0]
        else:
            data['founded'] = " "
        if headquarter:
            data['headquarters'] = headquarter
        else:
            data['headquarters'] = " "
        if location:
            data['location'] = location 
        else:
            data['location'] = " "
        if company_type:
            data['companyType'] = company_type[0] 
        else:
            data['companyType'] = " "
        if website:
            data['website'] = website[0] 
        else:
            data['website'] = " "
        if members:
            data['employeeSize'] = employeeSize
        else:
            data['employeeSize'] = " "
        if funding_type:
            data['fundingType'] = funding_type[0] 
        else:
            data['fundingType'] = " "
        if rank:
            data['rank'] = rank[0] 
        else:
            data['rank'] = " "
        #To scrapy the requested url and get required information
        for i in response.xpath("//ul[@class='two-column ng-star-inserted']/li/div"):
            name = i.xpath("./a/text()").extract()
            person_name.append(name[0])
            url = i.xpath("./a/@href").extract()
            urls = urljoin("https://www.crunchbase.com",url[0])
            person_url.append(urls)
            position = i.xpath("./field-formatter/span/text()").extract()
            person_position.append(position[0])
        for n,u,p in zip(person_name,person_url,person_position):
            count = 0
            y = ""
            for j in person:
                y = j['name'].replace(" ", "")
                if y == n.replace(" ", ""):
                    count = 1 
                    break  
            if count == 1:
                pass
            else:
                peo = {
                    'name' : n,
                    'url' : u,
                    'position' : p,
                    'source' : 'crunchbase'
                    }
                person.append(peo)
        data['people'] = person
        details.append(data)
        header = {'auth' : 'test'}
        r = requests.post("https://banao-bd-scrapper-testing.herokuapp.com/api/save-CompanyDetails",json=details,headers=header)
        print("One website Scrapyed")

    def errback_httpbin(self, failure): 
      self.logger.error(repr(failure))
    
  
