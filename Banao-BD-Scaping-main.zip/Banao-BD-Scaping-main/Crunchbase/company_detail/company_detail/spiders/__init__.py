# This package will contain the spiders of your Scrapy project
#
# Please refer to the documentation for information on how to create and manage
# your spiders.
# from company_details import CompanyDetailsSpider
# from scrapy.crawler import CrawlerProcess
# links = ['https://www.crunchbase.com/organization/engage-for-business','https://www.crunchbase.com/organization/ray-capital-3250','https://www.crunchbase.com/organization/grabjobs-bv-the-netherlands']
# for i in links:
#     process = CrawlerProcess()
#     process.crawl(CompanyDetailsSpider)
#     process.start()
# global value
# value = 0
# print("dslkajflksjdkfj\
#     lkasj;dlkjf;laksjd lkjfas\
#         slkdj f;lkjas;ldkj lkasjdfkj\
#             skladjfl; kjasdlkfj sadjfkajsd\
#                 ksadlfkjsalkdjf")
