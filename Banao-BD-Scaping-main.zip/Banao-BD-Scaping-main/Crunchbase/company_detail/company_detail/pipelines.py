# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface

import mysql.connector
from decouple import config

class CompanyDetailPipeline:
    def __init__(self):
        self.create_connection()
        # self.create_table2()
        # self.create_table3()
        

    def process_item(self, item, spider):
        self.store_db2(item)
        self.store_db3(item)
        return item

    def create_connection(self):
        self.conn = mysql.connector.connect(
            user = config('DB_user'),#The username for mysql database
            passwd = config('DB_passwd'), #Password for mysql database
            host = config('DB_host'),#Host name or any URL for mysql database
            database = config('DB_database'),#Schema name
            )
        self.curr = self.conn.cursor()

    # def create_table2(self):
    #     self.curr.execute("""create table Company_Details(
    #         Id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    #         Company_Name text,
    #         company_type text,
    #         company_url text,
    #         contact_url text,
    #         funding_type text,
    #         location text,
    #         members text,
    #         ranks text
    #     )""")
        

    # def create_table3(self):
    #     self.curr.execute("""create table Company_People(
    #         Id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    #         Company_Name text,
    #         person_name text,
    #         person_position text,
    #         person_url text
    #     )""")


    def store_db2(self,item):
        sql = """Insert into Company_Details(Company_Name,company_type,company_url,contact_url,funding_type,location,members,ranks) \
            select * from(Select '{0}','{1}','{2}','{3}','{4}',"{5}",'{6}','{7}') as temp \
                where not exists \
                       (Select Company_Name from Company_Details where Company_Name='{8}') LIMIT 1""".format(item['Company_Name'],item['company_type'],item['company_url'],item['contact_url'],item['funding_type'],item['location'],item['members'],item['rank'],item['Company_Name'])
        self.curr.execute(sql)
        self.conn.commit()

    def store_db3(self,item):
        self.curr.execute("""insert into Company_People values(%s,%s,%s,%s,%s)""",(
            "0",
            item['Company_Name'],
            item['person_name'],
            item['person_position'],
            item['person_url']
        ))
        self.conn.commit()