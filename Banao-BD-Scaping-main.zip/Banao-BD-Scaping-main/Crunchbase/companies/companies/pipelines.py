# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from scrapy.pipelines.files import FilesPipeline
import mysql.connector
from decouple import config



class CompaniesPipeline:
    def __init__(self):
        self.create_connection()
        self.create_tables()

    def process_item(self, item, spider):
        self.store_dbs(item)
        return item

    def create_connection(self):
        #Establish a connection between the script and Databse
        self.conn = mysql.connector.connect(
            user = config('DB_user'),#The username for mysql database
            passwd = config('DB_passwd'), #Password for mysql database
            host = config('DB_host'),#Host name or any URL for mysql database
            database = config('DB_database'),#Schema name
            )
        self.curr = self.conn.cursor()


    def create_tables(self):
        self.curr.execute("""create table companies(
            Id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            url text,
            name text,
            source text
        )""")

    def store_dbs(self,item):
        # Inserting the values into Table without Repetation
        sql = """Insert into companies(url,name,source) \
            select * from(Select '{0}','{1}','{2}') as temp \
                where not exists \
                    (Select name from companies where name='{3}') LIMIT 1""".format(item['Company_url_search'],item['Company_Name'],item['Source'],item['Company_Name'])
        self.curr.execute(sql)
        self.conn.commit()


class CustumFilePipelines(FilesPipeline):
    #To download the files in custum name
    def file_path(self, request, response=None, info=None, *, item=None):
        j = item.get('i')
        return str(j) + '.xml.gz'

