#Table schema
"""
create table banao_bd.employees( id int(11) primary key auto_increment,
 url text,
 name varchar(255),
 status enum('Not_scraped','Scraped','Processing') default 'Not_scraped',
 people_status int(11) default 0, source enum("Linkedin",'Crunchbase') default 'Linkedin',
 linkedin_id varchar(20),
 createdAt datetime DEFAULT CURRENT_TIMESTAMP,
 updatedAt datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)

"""
import os
import re
import csv
import shutil
import mysql.connector
import logging
logging.basicConfig(filename='output.log',format='%(levelname)s:%(message)s', level=logging.DEBUG)#Logging to a file named as output.log
#Database credentials
mydb = mysql.connector.connect(
  host="scrapdb2.crbyejbc1y6i.ap-south-1.rds.amazonaws.com",
  user="BanaoBDTest",
  password="OJPLf6c5mFlUMXsD",
  database="BanaoBDTest",
)
mycursor = mydb.cursor()
location = r"C:\users\hp\desktop\data"#Data folder location (which contains all csv files)
done = r"C:\users\hp\desktop\done"
l = []
try:
    os.mkdir(r"C:\users\hp\desktop\done")
except:
    pass
for i in os.listdir(location):#Appending all the csv files to a list
    z = re.findall("\d+\.\d+", i)
    l.append([z[0],i])
l = sorted(l,key=lambda x:float(x[0]))#sorting the file names in order
file_count = 0
rows_count = 0
for i in l:
    file_location = location+rf"\{i[1]}"#Appending the file
    with open(file_location) as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        count = 0
        logging.info("Processing file %s",i[1])
        for j in csv_reader:
            if count==0:#Excluding the column names like (name,url,title)
                count = count + 1;
                continue
            else:
                values = tuple(j)#Converting list to title
                url = values[0]
                regex = ("((http|https)://)(www.)?" +
             "[a-zA-Z0-9@:%._\\+~#?&//=]" +
             "{2,256}\\.[a-z]" +
             "{2,6}\\b([-a-zA-Z0-9@:%" +
             "._\\+~#?&//=]*)")#Regex for validating the url field
                if re.search(regex,url):#If regext is valid the insert record into database
                    smt = """INSERT INTO BanaoBDTest.companies (url,name,source) VALUES (%s,%s,%s)"""#Insert statment
                    try:
                        mycursor.execute(smt,values)
                    except Exception as ex:
                        #If error raises then print the file name and the record at which the error is raised
                        logging.error("Error occured while handiling %s file and the record is %d",i[1],count)
                else:#If url is not valid then log the error into a file
                    logging.error("The url in the file %s in record %d",i[1],count+1)
                rows_count = rows_count + mycursor.rowcount#Incrementing the inserted row count
                mydb.commit()
            count = count + 1;#Incrementing the count value to track the file record
        logging.info("%d records processed in the file %s",count-1,i[1])
    file_to_move = done + rf"\{i[1]}"
    shutil.move(file_location,file_to_move)
    logging.info(f"The file {i[1]} is moved to this location {file_to_move}")
logging.info("%d record inserted.",rows_count)
