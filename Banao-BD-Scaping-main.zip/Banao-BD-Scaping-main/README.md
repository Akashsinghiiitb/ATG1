# Banao-BD-Scaping

Banao BD Api generation and Access
Created by Snehal Borkar
Documention of generating and Accessng Api in Banao BD

Login - for generating Api

1. User in auth User table whose staff status is checked can only login.
2. Normal user created cannot login


Captain/Api-generator's dashboard

i. New user creation
    1.Register user button is given to create new marketing member
      who is going to access Api people data
    2.Dublicate username is not allowed

ii.Api Generation
    A.Select User 
        1. for all the users Admin-superuser,active, or staff user API can be generated 
        2. Single user select is allowed at a time
    B.Select State 
        1. Multiple State select is allowed for an Api but if the number of people
            is less than the count in first selected state then only it will go for the next state,
            if the count is satisfied on first state other states people data will not going to return
        2.state select is optional must.
    C.Count
        1.minimum count should be 1 maximum can be any
        2.if count is more than people for selected states only number of people avalible
            will be returned
    D.Test
        1.default test is False, means api response will going to be saved in Log_t table  
        2.for True test api response can be checked that API is not stored in database and record like people indexes,updated and last-used datetime will not be saved in database




Api Response

1.For first time response to api, User/marketing person object/id is created at Log_t table
    and datetime of creation will be saved in created field, and datetime at updated and
    last_used time will also saved as same.And accessed status changes to 1 in people table means that data
    is used in marketing.

2.For the second /more no. of time for same Api, gives same response within 24 hrs and last_used datetime will
    be changed to second/ more no. of response datetime . After 24 hrs it returns different/new people data whose accessed is 0
    and that people data will be  newly saved in indexes field and  newly saved  people date and time will be
    updated in updated field and last used will also changed and accessed to 1.

3.If new  Api is created for existing marketing person within or after
    24hrs , new token will be generated and old API will not give any response
