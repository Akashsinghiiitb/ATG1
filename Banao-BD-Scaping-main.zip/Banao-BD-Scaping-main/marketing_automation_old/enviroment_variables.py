import json
import os

if (os.name == 'nt'):
    path = os.path.dirname(__file__) + '\\environment.json'
elif (os.name == 'posix'):
    path = os.path.dirname(__file__) + '/environment.json'
else:
    path = os.path.dirname(__file__) + '/environment.json'


with open(path) as json_file:
    data = json.load(json_file)
    for env in data['env_variables']:
        party_url = env["party_url"]
