from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from time import sleep
from selenium.webdriver.common.action_chains import ActionChains
import keys
from marketing_automation.getting_server_ip import get_server_ip

# IP fetched from atg.party/ms.txt
SERVER_IP = get_server_ip()

driver = webdriver.Firefox()
driver.get(f"http://{SERVER_IP}/phpmyadmin/")
driver.find_element_by_xpath("//input[contains(@id,'input_username')]").send_keys("root")
driver.find_element_by_xpath("//input[contains(@id,'input_password')]").send_keys("H3ll0W0rld78&*")
driver.find_element_by_xpath("//input[contains(@id,'input_go')]").click()
driver.find_element_by_xpath('//*[@id="pma_navigation_tree_content"]/ul/li[2]/a').click()
sleep(5)
driver.execute_script("$('tr#row_tbl_1 th > a').click()")
sleep(5)
driver.execute_script("$('div#page_content a.inline_edit_sql').click()")
sleep(5)
elem = driver.switch_to.active_element
elem.send_keys(Keys.CONTROL + "a", Keys.DELETE)
driver.switch_to.active_element.send_keys("SELECT email FROM `form_details` WHERE lower(group_name) ='yoga' and email IS NOT null;")
sleep(1)
driver.execute_script("$('input#sql_query_edit_save').click()")
sleep(3)
driver.execute_script("$('div#page_content a:nth-child(4) > span').click()")
sleep(3)
select = Select(driver.find_element_by_id("plugins"))
sleep(3)
select.select_by_visible_text("CSV")
driver.execute_script("$('input#buttonGo').click()")
topic, group = keys.randomizer('interests')
driver.get("http://sendy.atg.party//login")
driver.find_element_by_xpath("//input[@id='email']").send_keys("hello@atg.party")
driver.find_element_by_xpath("//input[contains(@type,'password')]").send_keys("H3ll0W0rld78&*")
driver.find_element_by_xpath("//button[@type='submit'][contains(.,'Sign in')]").click()
driver.find_element_by_xpath("(//a[@href='http://sendy.atg.party//app?i=1'])[2]").click()
driver.find_element_by_xpath("//a[@href='http://sendy.atg.party//list?i=1'][contains(.,'View all lists')]").click()
driver.find_element_by_xpath("//a[@href='http://sendy.atg.party//subscribers?i=1&l=11'][contains(.,'yoga')]").click()
driver.find_element_by_xpath("//tr/td/a[contains(text(), '"+topic+"')]").click()
driver.find_element_by_xpath("//button[@class='btn'][contains(.,'Add subscribers')]").click()
driver.find_element_by_xpath("//input[contains(@id,'csv_file')]").send_keys("C:\\Users\\lavisha.kapoor\\Downloads\\form_details.csv")
driver.find_element_by_xpath("//button[@type='submit'][contains(.,'Import')]").click()
driver.find_element_by_xpath("//a[@href='http://sendy.atg.party//templates?i=1'][contains(.,'All templates')]").click()
row = driver.find_element_by_xpath("//tr/td/a[contains(text(), '"+topic+"')]/ancestor::tr")
m = row.get_attribute('id')
k = []
k = driver.find_element_by_css_selector("a[href*='use-template.php?i=1&t="+m+"']")
k.click()
sleep(8)
a = driver.find_elements_by_tag_name("input")
sleep(5)
a[1].clear()
a[1].send_keys("Connecting the " +group+ " across the globe")#subject
sleep(5)
a[2].clear()
a[2].send_keys(group + " across the globe")#from-name
sleep(5)
a[3].clear()
a[3].send_keys("admin@motherskitchen.ml")#from-email
sleep(5)
a[4].clear()
a[4].send_keys("admin@motherskitchen.ml")#replyto-email
sleep(5)
driver.execute_script("$('#edit-form > div.span3 > button').click()")
sleep(8)
select = Select(driver.find_element_by_id("email_list"))
select.select_by_visible_text("private_our_emails")
sleep(2)
select.select_by_visible_text(topic)
sleep(2)
driver.find_element_by_css_selector("#real-btn").click()
driver.switch_to.alert.accept()
