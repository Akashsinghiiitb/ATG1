from random import randrange as rn
from random import uniform as un
from random import choice
from time import sleep
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service as ChromeService
from webdriver_manager.chrome import ChromeDriverManager
import requests
import re
import selenium
import keys
from bs4 import BeautifulSoup
import urllib3
import os
from log_generator import generate_log
from datetime import date, datetime

# Log file name
current_date = date.today()
current_time = datetime.now().strftime("%H:%M").replace(":", ",")
LOG_FILE = f"{current_time} {current_date} gclass"

def do_log(*message):
    output_data = ''
    for i in message:
        output_data += f"{i} "
    print(output_data)
    generate_log(output_data, LOG_FILE)
# from marketing_automation.getting_server_ip import get_server_ip

# IP fetched from atg.party/ms.txt
SERVER_IP = "intranet.atg.party:8989"#get_server_ip()
start_time = datetime.now()
do_log(start_time)

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class Scraper():
    """Variables for storing all data in current run"""
    all_eml = []
    all_phn = []
    all_web = []

    def tag_visible(element):
        """Checks visible tags on a page"""
        if element.parent.name in ['style', 'script', 'head', 'title', 'meta', '[document]']:
            return False
        return True

    def scrapdata(URL):
        """Data scraping function"""
        link = URL
        page = requests.get(link, verify=False)
        main_contact = page.content
        main_contact_soup = BeautifulSoup(main_contact, 'html.parser')  # Parse html code
        text_of_main_contact = main_contact_soup.findAll(text=True)
        visible_texts = filter(Scraper.tag_visible, text_of_main_contact)
        return u" ".join(t.strip() for t in visible_texts)

    def getEmails(data):
        """To find emails in given data"""
        mail_list_final = []
        mail_list = re.findall("[A-Za-z0-9\.\-+_]+@[A-Za-z0-9\.\-+_]+\.[A-Za-z]+", data)
        for i in mail_list:
            if i.endswith(r'"'):
                mail_list[mail_list.index(i)] = i[0:-1]
            if i.endswith(r","):
                mail_list[mail_list.index(i)] = i[0:-1]
        for i in mail_list:
            if i in Scraper.all_eml:
                pass
            else:
                mail_list_final.append(i)
                Scraper.all_eml.append(i)
        return mail_list_final

    def getPhone(data):
        """To find phone numbers in given data"""
        phone_list_final = []
        phone_list = re.findall(
            "\+\d\d?-? ?\d{3}-\d{3}-\d{4}|\+\d\d?-? ?\d{10}|\+\d\d?-? ?\d{5} \d{5}|\+\d\d?-? ?\d{3}\-? ?\d{7}|\+\d\d?-? ?\d{4}\-? ?\d{6}",
            data)
        for i in phone_list:
            if i in Scraper.all_phn:
                pass
            else:
                phone_list_final.append(i)
                Scraper.all_phn.append(i)
        return phone_list_final

    def getSites(data):
        """To find websites in given data"""
        site_list_final = []
        site_list = re.findall(
            r"(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})",
            data)
        for i in site_list:
            if i in Scraper.all_web or (r'"' in i) or (r">" in i) or (r"<" in i) or (r"..." in i) or (r".css" in i) or (
                    r".js" in i) or (r".jpeg" in i) or (r".png" in i) or (r".jpg" in i):
                pass
            else:
                site_list_final.append(i)
                Scraper.all_web.append(i)
        do_log(site_list_final)
        return site_list_final


class Google():
    """variables for current group,location and the list of sites that correspond to it"""
    grp = ""
    lct = ""
    sitelist = []

    def __init__(self):
        """Init Function"""
        prefs = {"profile.default_content_setting_values.notifications": 2}
        option = webdriver.ChromeOptions()
        option.add_experimental_option("excludeSwitches", ["ignore-certificate-errors"])
        option.add_argument('headless')
        option.add_argument('--no-sandbox')
        option.add_experimental_option("prefs", prefs)
        # option.add_argument("--start-maximized")
        option.add_argument("--window-size=1920x1080")
        option.add_argument("--disable-extensions")
        option.add_argument("--disable-gpu")
        option.add_argument("--disable-dev-shm-usage")
        option.add_argument("disable-infobars")
        # path = r"/home/omprakash/Desktop/GMAP/chromedriver"
        # path=r"/home/ubuntu/Om1/chromedriver"
        # path=r"/home/ubuntu/atg_ui_automation/drivers/chromedriver33"
        # path=r"/home/atg/Om1/chromedriver"
        # path = r"../chromedriver"
        self.browser = webdriver.Chrome(ChromeDriverManager().install(), options=option)

    def setInterest(self, group, location):
        """Sets the Interest for the current run"""
        self.setgrp(group)
        self.setloc(location)

    def setgrp(self, group="dance"):
        """Sets the group variable for the current run"""
        ##self.grp=keys.randomizer('interests')
        self.grp = group

    def setloc(self, location="bangalore"):
        """Sets the Location variable for the current run"""
        ##self.lct=keys.randomizer('location')
        self.lct = location

    def getInterest(self):
        """Returns the Interest for the current run"""
        return self.grp + " " + self.lct

    def getgrp(self):
        """Returns the group for the current run"""
        return self.grp

    def getloc(self):
        """Returns the location for the current run"""
        return self.lct

    def goTo(self, URL):
        """Visits specified URL"""
        self.browser.get(URL)

    def currURL(self):
        """Returns current URL"""
        return self.browser.current_url

    def spslp(self, x, y):
        """Sleep for a random amount of time between x and y"""
        sleep(un(x, y))

    def scroll(self, times):
        """Scrolls a given number of times"""
        for i in range(times):
            self.browser.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            self.spslp(2, 3)

    def weblist(self):
        """Returns the titles of search results as shown on results page in google"""
        dt = self.browser.find_elements_by_css_selector("a>h3")
        rtdt = []
        for i in dt:
            rtdt.append(i.find_element_by_xpath(".."))
        return rtdt

    def complist(self):
        """Populates the site list with items"""
        for i in self.weblist():
            if i.get_attribute("href") not in self.sitelist:
                self.sitelist.append(i.get_attribute("href"))
        self.spslp(0.1, 0.5)

    def srch_fx(self, term="Bangalore Dance +91"):
        """Searches for the given term. (To be used when on google search home page)."""
        cs1 = self.browser.find_element_by_css_selector("input[aria-label='Search']")
        ActionChains(self.browser).move_to_element(cs1).send_keys(term).perform()
        cs1.send_keys(Keys.RETURN)
        self.complist()

    def scrapFunc(self):
        """Scrapes data line 1-4 then posts data to the API"""
        body = Scraper.scrapdata(self.currURL())
        em = Scraper.getEmails(body)
        ph = Scraper.getPhone(body)
        ws = Scraper.getSites(body)
        if (len(em) > 0 or len(ph) > 0):
            data1 = "group1=" + self.getgrp() + "&location1=" + self.getloc() + ApiCaller.updatedata(em,
                                                                                                     ph) + "&url1=search " + self.currURL()
            do_log(data1)
            ApiCaller.new_api_poster(data1)
        if (len(ws) > 0):
            data2 = "group=" + self.getgrp() + "&location=" + self.getloc() + ApiCaller.updatewebdata(ws)
            do_log(data2)
            ApiCaller.web_api_poster(data2)

    def nextpage(self):
        """Go to next page in google search results"""

        try:
            ActionChains(self.browser).move_to_element(
                self.browser.find_element_by_css_selector("a[id='pnnext']")).click().perform()
        except selenium.common.exceptions.MoveTargetOutOfBoundsException:
            ele = self.browser.find_element_by_css_selector("a[id='pnnext']")
            self.browser.execute_script("arguments[0].scrollIntoView();", ele)

            # self.nextpage()
        except selenium.common.exceptions.NoSuchElementException:
            # self.spslp(1,2)
            pass
            # self.nextpage()
        finally:
            self.spslp(2, 3)

    def geturls(self, pages=3):
        """Gets the URLS of specified numbers of pages in search results"""
        do_log(str(self.sitelist.__len__()))
        for i in range(pages):
            self.spslp(0.3, 0.5)
            # do_log("bf"+str(self.sitelist.__len__()))
            self.complist()
            # do_log("af"+str(self.sitelist.__len__()))
            try:
                self.nextpage()
            except Exception as e:
                do_log(e)
                pass

        do_log("Results: " + str(self.sitelist.__len__()))

    def routine(self, pages=3, term="Bangalore Dance +91"):
        """A regular routine performing search and getting urls of the pages"""
        self.goTo("https://google.com")
        sleep(3)
        self.srch_fx(term)
        self.spslp(5, 10)
        self.geturls(pages)

    def sendSites(self):
        """Send the website base website list to API and posts"""
        sl = []
        for i in G.sitelist:
            te = re.findall(r'https?:?//[^/]+', i)
            isp = te[0].split('://')
            if len(isp) >1:
                isp = isp[1]
            else:
                isp = isp[0]
            isp = isp.split('/')
            isp = isp[0]
            isp = isp.strip('wwww.')
            if isp not in sl:
                sl.append(isp)
        if (len(sl) > 0):
            data3 = "group=" + self.getgrp() + "&location=" + self.getloc() + ApiCaller.updatewebdata(sl)
            do_log(data3)
            ApiCaller.web_api_poster(data3)


class ApiCaller():
    def new_api_poster(data):
        """Posts data to new API"""
        rq = requests.post(f"http://{SERVER_IP}/api/new-api?{data}")
        do_log("--" * 40)
        if rq.ok:
            do_log("Data sent and Response text is " + str(rq.content))
        else:
            do_log("Unsucessful")
        do_log("--" * 40)

    def web_api_poster(data):
        """Posts data to website API"""
        rq = requests.post(f"http://{SERVER_IP}/api/website?{data}")
        if rq.ok:
            do_log("Data sent and Response text is " + str(rq.content))
        else:
            do_log("Unsucessful")
        do_log("--" * 40)

    def updatedata(email, phone, about=True):
        """Formats email and phone data for API posting"""
        eml = ""
        phn = ""
        if len(email) > 0:
            eml += email[0]
        if len(phone) > 0:
            phn += phone[0]
        try:
            for i in email:
                if i != email[0]:
                    eml += "," + i
        except:
            pass

        try:
            for i in phone:
                if i != phone[0]:
                    try:
                        i = i.replace(" ", "")
                        i = i.replace("   ", "")
                        i = i.replace("\n", "")
                        i = i.replace(" ", "")
                        i = i.replace("\t", "")
                    except:
                        pass
                    phn += "," + i
        except:
            pass

        if len(eml) > 0:
            eml = "&email1=" + eml
        if len(phn) > 0:
            phn = "&phone1=" + phn
        if about == True:
            pass
        else:
            pass
        do_log(eml)
        do_log(phn)
        return eml + phn

    def updatewebdata(website):
        """Formats website data for API posting"""
        webs = ""
        if len(website) > 0:
            webs += website[0]
        try:
            for i in website:
                if i != website[0]:
                    webs += "," + i
        except:
            pass
        if len(webs) > 0:
            webs = "&website=" + webs
        else:
            pass
        do_log(webs)
        return webs


G = Google()
group = "devops"
location = "guntur"
group = keys.randomizer_local('interests')
location = keys.randomizer_local('location')
G.setInterest(group, location)
interest = G.getInterest()
do_log(interest)
terms = ["+91", "gmail.com"]
G.routine(pages=3, term=interest + " " + choice(terms))
G.sendSites()

for i in G.sitelist:
    try:
        G.goTo(i)
    except Exception as e:
        do_log(e)
        pass
    try:
        G.scrapFunc()
    except Exception as e:
        do_log(e)
        pass

G.browser.quit()
end_time = datetime.now()
do_log("start time", start_time)
do_log("end time", end_time)

