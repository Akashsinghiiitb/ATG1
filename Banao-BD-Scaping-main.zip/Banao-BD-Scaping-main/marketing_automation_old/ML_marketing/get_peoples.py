from flair.data import Sentence
from flair.models import SequenceTagger
from bs4 import BeautifulSoup
import time
import requests
import re

from fuzzywuzzy import fuzz
from fuzzywuzzy import process

from email_validator import validate
from api_update import predict_emails_fire_and_forget



global tagger
tagger = SequenceTagger.load('ner')

global position_list
position_list = ['ceo', 'founder', 'consultant', 'manager', 'coach', 'human resource', "founding partner", 'president', 'secretary', 'admin', 'director', 'analyst',
    'engineer']
ignore_list = ['_', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '+', '!' , '~', '%', '-', '(', ')', ':', '#', '@', '*', '/', '&']

global delta
delta = 3

class NameScrap:
    url = ""
    domain = ""
    data = {}
    peoples = []
    pnames = []
    email_detectable = True
    website_id = None

    def __init__(self, url, website_id=0) -> None:
        sp = url.split("://")
        if len(sp) > 1:
            url = sp[1]
        self.url = url
        self.data['url'] = url
        self.domain = url.split('/')[0].strip('www.')
        self.website_id = website_id
        print(self.email_detectable)

    def scrape(self):
        # driver = self.driver
        # driver.get(self.url)
        # time.sleep(3)
        # driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        
        names, text_list = self.get_names_form_bs()
        self.get_positions(names, text_list)
        # print("\n".join(text_list))
        # self.get_email()
        # predict_emails_fire_and_forget(self.website_id, self.domain, self.peoples)

        for p in self.peoples:
            print(p)
        
        return self.peoples


    def strip(self, lines):
        final_list = []
        for line in lines:
            if len(line.strip())!=0:
                final_list.append(line.strip().strip("[]{}();,.:<>?/|"))
        return final_list

    def get_names_form_bs(self):
        names = []
        print(self.url)
        soup=BeautifulSoup(requests.get('http://'+self.url, timeout=20).content,'html.parser',from_encoding="iso-8859-1")
        content_text=soup.get_text(separator='\n').title()
        text_lin_list = self.strip(content_text.replace(',','\n').replace('.','\n').split("\n"))
        for text_line in text_lin_list:
            if text_line in self.pnames:
                continue
            is_ignore = False
            for el in ignore_list:
                if el in text_line:
                    is_ignore = True
            if is_ignore:
                continue
            if(len(text_line)==0 or len(text_line.split(" "))>8 or len(text_line.split(","))>1  or len(text_line.split("|"))>1 or len(text_line.split("="))>1):
                continue
            sentence = Sentence(text_line)
            tagger.predict(sentence)
            for entity in sentence.get_spans('ner'):
                if entity.tag=='PER': 
                    # print(text_line)
                    names.append(text_line)
                    self.pnames.append(text_line)
        
        return (list(set(names)), text_lin_list)

    
    def get_positions(self, names, text_list):
        max_pos = len(text_list) -1
        for name in names:
            email=None
            pos = None
            linkedin = None
            instagram = None
            ind = text_list.index(name)
            start = ind - delta
            end = ind + delta + 1
            if end > max_pos:
                end = max_pos
            if start < 0:
                start = 0
            
            ev_text = " ".join(text_list[start:ind] + text_list[ind+1:end])
            ev_list = text_list[start:ind] + text_list[ind+1:end]
            breaker  = 0
            for position in position_list:
                for el in ev_list:
                    if position.lower() in str(el).lower():
                        pos = el
                        breaker = 1
                        break
                
                if breaker==1:
                    break


            emails=re.findall(r'[\w.+-]+@[\w-]+\.[\w.-]+',ev_text)

            if len(emails) > 0:
                max_sc = 0
                for mail in emails:
                    ratio = fuzz.ratio(name,mail)
                    if ratio > max_sc:
                        max_sc = ratio
                        email=mail
            
            linkedin_links = re.findall(r'[\w.+-]+linkedin[\w-]+\.[\w.-]+',ev_text)
            if len(linkedin_links) > 0:
                max_sc=0
                for link in linkedin_links:
                    ratio = fuzz.ratio(name,link)
                    if ratio > max_sc:
                        max_sc = ratio
                        linkedin = link
            
            instagram_links = re.findall(r'[\w.+-]+instagram[\w-]+\.[\w.-]+',ev_text)
            if len(instagram_links) > 0:
                max_sc=0
                for link in instagram_links:
                    ratio = fuzz.ratio(name,link)
                    if ratio > max_sc:
                        max_sc = ratio
                        instagram = link

            self.peoples.append({"name":name.strip(""";:-,'\""""),"position":pos, "email":email, "linkedin":linkedin, "instagram":instagram})
    
    def get_email(self):
        if not self.email_detectable:
            return None
        for people in self.peoples:
            if people['email'] != None:
                continue
            name = people['name'].split(" ")
            if validate(f"{name[0]}@{self.domain}"):
                email = f"{name[0]}@{self.domain}"
            elif validate(f"{''.join(name)}@{self.domain}"):
                email = f"{''.join(name)}@{self.domain}"
            elif validate(f"{'_'.join(name)}@{self.domain}"):
                email = f"{'_'.join(name)}@{self.domain}"
            elif validate(f"{'.'.join(name)}@{self.domain}"):
                email = f"{'.'.join(name)}@{self.domain}"
            else:
                email = None
            people['email'] = email






# url = NameScrap("https://brainworks.world/about/index.html")
# url = NameScrap("https://www.bytheriver.in/aboutus")
# url = NameScrap("https://www.mooretalent.com/contact")
# url = NameScrap("https://ncatalent.com/staff-directory")
# url = NameScrap("https://aspireimpact.in/leadership-team/")
# url = NameScrap("https://nainabatra.ca/about/").scrape()
# url = NameScrap("https://www.synthesia.io/about").scrape()

