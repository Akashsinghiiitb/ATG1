import requests

def get_performance(url):
    if not "http" in url:
        url = "https://"+ url
    response = requests.get(f'https://www.googleapis.com/pagespeedonline/v5/runPagespeed?url={url}&key=AIzaSyCuNTv0CXFlXmhdKP5Y9VyoQsxRotYHX4U').json()
    data = {
        'score': response['lighthouseResult']['categories']['performance']['score'] * 100,
        'link': f"https://pagespeed.web.dev/report?url={url}"
    }
    return data

if __name__ == "__main__":
    print(get_performance("tulas.edu.in"))