import time
from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service as ChromeService
from webdriver_manager.chrome import ChromeDriverManager
import json
import pprint
import api_update
import page_speed



prefs = {"profile.default_content_setting_values.notifications": 2}
option=webdriver.ChromeOptions()
option.add_experimental_option("excludeSwitches", ["ignore-certificate-errors"])
option.add_argument('headless')
option.add_argument('--no-sandbox')
option.add_experimental_option("prefs", prefs)
#option.add_argument("--start-maximized")
option.add_argument("--window-size=1920x1080")
option.add_argument("--disable-extensions")
option.add_argument("--disable-gpu")
option.add_argument("--disable-dev-shm-usage")
option.add_argument("disable-infobars")
path=r"/home/omprakash/Desktop/GMAP/chromedriver"
#path=r"/home/ubuntu/Om1/chromedriver"
#path=r"/home/ubuntu/atg_ui_automation/drivers/chromedriver33"
#path=r"/home/atg/Om1/chromedriver"
path=r"../../drivers/chromedriver"
capabilities = DesiredCapabilities.CHROME
capabilities["goog:loggingPrefs"] = {"performance": "ALL"}  # chromedriver 75+

driver = webdriver.Chrome(ChromeDriverManager().install(), options=option, desired_capabilities=capabilities)

inp_tags = ['input', 'textarea', 'checkbox']


def get_message(url):
    pagespeed_msg = ""
    try:
        pagespeed_rank = page_speed.get_performance(url)
        pagespeed_score  = pagespeed_rank['score']
        if pagespeed_score < 80 :
            pagespeed_msg = f"""

            I also happened to do an initial free SEO research on your website. If you notice the pagespeed rank (from Google) link below, there is a huge chance of improvement for your website. The website performance is {pagespeed_score}% and we can help increase to 90%.
            {pagespeed_rank['link']}

            """
    except:
        pass
    msg = f"""
    Hi,
    I am Saurabh, Head of Development at Banao Technologies (www.banao.tech). Please accept my humble greetings.
    I was researching about {url} from social media and understood that Banao can be a great fit for your website/app development, SEO and marketing needs.
    We have worked with 500+ clients from 10+ countries over the last 7 years. We suggest you please have a look at our portfolio.

    Development Portfolio:
    https://bit.ly/banao-tech-development-portfolio
    Marketing Portfolio:
    https://bit.ly/banao-tech-marketing-portfolio
    {pagespeed_msg}
    
    Please visit www.banao.tech and contact us, or Whatsapp me at +91-9900036467.
    Thanks & Regards
    Saurabh Bassi
    Head of Development
    Banao Technologies
    www.banao.tech
    +91-9900036467
    """

    keys = {
        "name": "Banao Technologies",
        "email":"hello@banao.tech",
        "phone": "9900036467", #Bassi
        "sub": "Development and Marketing services from Banao Technologies", #Hi XYZ, Development and Marketing services from Banao Technologies :-after website rank
        "msg" : msg,
        "city": "Bangalore",
        "web":"www.banao.tech"
    }

    return keys


def process_browser_logs_for_network_events(logs, ts):
    """
    Return only logs which have a method that start with "Network.response", "Network.request", or "Network.webSocket"
    since we're interested in the network events specifically.
    """
    post_request_ids = {} # {requestId:log{}}
    responses = {} # {requestId:log{}}
    is_allowed = False
    for entry in logs:
        try:
            log = json.loads(entry["message"])["message"]
            is_form_data = False
            is_json = False
            has_post_data = False
            has_response = False
            if is_allowed == False:
                try:
                    if log['params']['wallTime'] > ts:
                        is_allowed =True
                        print("is allowed set")
                except:
                    pass
            try:
                print(log['params']['wallTime'])
            except:
                pass

            try:
                if 'form' in log['params']['request']['headers']['Content-Type'].lower():
                    is_form_data = True
            except:
                pass

            try:
                if 'json' in log['params']['request']['headers']['Content-Type'].lower():
                    is_json = True
            except:
                pass

            try:
                has_post_data = log['params']['request']['hasPostData']
                print("has post data")
            except:
                has_post_data = False

            try:
                log['params']['response']
                has_response = True
            except:
                pass
            try:
                if (
                    "Network.response" in log["method"]
                    or "Network.request" in log["method"]
                ) and is_allowed and (has_post_data or has_response):
                    if has_post_data and (is_json or is_form_data):
                        post_request_ids[log['params']['requestId']] = log
                        print("req added")

                    if has_response:
                        if log['params']['requestId'] in post_request_ids.keys():
                            responses[log['params']['requestId']] = {'status':log['params']['response']['status'], 'log': log}
                            print("response added")

                
            except Exception as e:
                # print(e)
                pass
        except:
            pass

    return (post_request_ids, responses)


def traverse_form(form,keys, sp = " "):
    email_exist = False
    all_element = form.find_elements(By.CSS_SELECTOR,"*")
    print(sp,len(all_element))
    for el in all_element:
        # print(sp, "-> ", el.tag_name, el.get_attribute('type'))
        if el.tag_name not in inp_tags:
            inp_fields = form.find_elements(By.TAG_NAME,"input")
            textarea_fields = form.find_elements(By.TAG_NAME,"textarea")
            checkbox_fields = form.find_elements(By.TAG_NAME,"checkbox")
            button_fields = form.find_elements(By.TAG_NAME,"button")
            if len(inp_fields) > 0 or len(textarea_fields) > 0 or len(checkbox_fields)>0 or len(button_fields)>0:
                email_exist_temp = traverse_form(el, keys=keys, sp= sp+"    ")
                if email_exist_temp == 200:
                    print(sp,"returnning 200 from ln 59")
                    return 200
                if not email_exist:
                    email_exist = email_exist_temp

        else:
            i = 1
            # print(sp, "----------------")
            # print(sp,el.tag_name)
            # print(sp, el.get_attribute('required'))
            # print(sp, el.get_attribute('type'))
            # print(sp, el.get_attribute('class'))
            # print(sp, el.get_attribute('name'))
            try:
                label = form.find_element_by_xpath(f"""//label[@for="{el.get_attribute('id')}"]""").get_attribute('for')
            except Exception as e:
                label= ""
            print(sp, "label ---> ", label)
            try:
                attributes = str(el.get_attribute('type')) + str(el.get_attribute('class')) + str(el.get_attribute('name')) + str(el.get_attribute('id')) + label
                if "email" in attributes.lower():
                    if el.get_attribute('value') != keys["email"]:
                        el.send_keys(keys['email'])
                        email_exist = True
                        print("----------------------------------------------------------")
                elif "name" in attributes.lower() or "user" in attributes.lower():
                    if el.get_attribute('value') != keys["name"] and len(el.get_attribute('value')) < 2:
                        el.send_keys(keys['name'])
                elif "phone" in attributes.lower() or "tel" in attributes.lower() or "mobile" in attributes.lower():
                    if el.get_attribute('value') != keys["phone"] and len(el.get_attribute('value')) < 2:
                        el.send_keys(keys['phone'])
                elif "message" in attributes.lower() or "comment" in attributes.lower():
                    if el.get_attribute('value') != keys["msg"] and len(el.get_attribute('value')) < 2:
                        el.send_keys(keys['msg'])
                elif "sub" in attributes.lower():
                    if el.get_attribute('value') != keys["sub"] and len(el.get_attribute('value')) < 2:
                        el.send_keys(keys['sub'])
                elif el.tag_name == "textarea":
                    if el.get_attribute('value') != keys["msg"] and len(el.get_attribute('value')) < 2:
                        el.send_keys(keys['msg'])
                elif el.get_attribute('type') == "checkbox":
                    if not el.is_selected():
                        el.click()
                elif el.get_attribute('required'):
                    if el.get_attribute('type') == "text":
                        if el.get_attribute('value') != keys["sub"] and len(el.get_attribute('value')) < 2:
                            print( el.get_attribute('value'))
                            el.send_keys(keys['sub'])
                    elif el.get_attribute('type') == "email":
                        if el.get_attribute('value') != keys["email"]and len(el.get_attribute('value')) < 2:
                            el.send_keys(keys['email'])
                    elif el.get_attribute('type') == "tel":
                        if el.get_attribute('value') != keys["phone"] and len(el.get_attribute('value')) < 2:
                            el.send_keys(keys['phone'])
                if  el.get_attribute('type') == "button" or el.get_attribute('value') == "Submit":
                    try:
                        el.click()
                        print("button clicked")
                    except:
                        pass
                    print(sp,"returnning 200 from ln 100")
                    return 200

            except:
                pass
            # time.sleep(3)
     
    return email_exist


def write_form(form, keys):
    email_exist = False
    button_clicked = False
    inp_fields = form.find_elements(By.TAG_NAME,"input")
    textarea_fields = form.find_elements(By.TAG_NAME,"textarea")
    checkbox_fields = form.find_elements(By.TAG_NAME,"checkbox")
    button_fields = form.find_elements(By.TAG_NAME,"button")
    print("vvvvv")
    print(len(inp_fields))
    print(len(textarea_fields))
    print(len(button_fields))
    
    print("checkbox_fields count>",len(checkbox_fields))
    print(checkbox_fields)
    for el in checkbox_fields:
        print("checkbox_fields")
        if not el.is_selected():
            el.click()

    for el in textarea_fields:
        try:
            form.execute_script("arguments[0].scrollIntoView();", el)
        except:
            pass
        try:
            try:
                label = form.find_element_by_xpath(f"""//label[@for="{el.get_attribute('id')}"]""").text
            except Exception as e:
                label= ""
            attributes = str(el.get_attribute('type')) + str(el.get_attribute('class')) + str(el.get_attribute('name')) + str(el.get_attribute('id')) + str(el.get_attribute('placeholder')) + label
            if el.get_attribute('value') != keys["msg"] and len(el.get_attribute('value')) < 2:
                el.send_keys(keys['msg'])
            elif el.get_attribute('required'):
                if el.get_attribute('type') == "text":
                    if el.get_attribute('value') != keys["sub"] and len(el.get_attribute('value')) < 2:
                        print( el.get_attribute('value'))
                        el.send_keys(keys['sub'])
                elif el.get_attribute('type') == "email":
                    if el.get_attribute('value') != keys["email"]and len(el.get_attribute('value')) < 2:
                        el.send_keys(keys['email'])
                elif el.get_attribute('type') == "tel":
                    if el.get_attribute('value') != keys["phone"] and len(el.get_attribute('value')) < 2:
                        el.send_keys(Keys())
                        el.send_keys(keys['phone'])
                else:
                    try:
                        el.send_keys(keys['msg'])
                    except:
                        pass
        except:
            pass

    for el in inp_fields:
        try:
            form.execute_script("arguments[0].scrollIntoView();", el)
        except:
            pass
        try:
            try:
                label = form.find_element_by_xpath(f"""//label[@for="{el.get_attribute('id')}"]""").text
            except Exception as e:
                label= ""
            attributes = str(el.get_attribute('type')) + str(el.get_attribute('class')) + str(el.get_attribute('name')) + str(el.get_attribute('id')) + str(el.get_attribute('placeholder')) + label
            if "email" in attributes.lower():
                if el.get_attribute('value') != keys["email"]:
                    el.send_keys(keys['email'])
                    email_exist = True
                    print("----------------------------------------------------------")
            elif "name" in attributes.lower() or "user" in attributes.lower():
                if el.get_attribute('value') != keys["name"] and len(el.get_attribute('value')) < 2:
                    el.send_keys(keys['name'])
            elif "phone" in attributes.lower() or "tel" in attributes.lower() or "mobile" in attributes.lower():
                if el.get_attribute('value') != keys["phone"]:
                    el.send_keys(Keys.CONTROL, 'A')
                    el.send_keys(keys['phone'])
            elif "message" in attributes.lower() or "comment" in attributes.lower():
                if el.get_attribute('value') != keys["msg"] and len(el.get_attribute('value')) < 2:
                    el.send_keys(keys['msg'])
            elif "sub" in attributes.lower():
                if el.get_attribute('value') != keys["sub"] and len(el.get_attribute('value')) < 2:
                    el.send_keys(keys['sub'])
            elif el.get_attribute('required'):
                if el.get_attribute('type') == "text":
                    if el.get_attribute('value') != keys["sub"] and len(el.get_attribute('value')) < 2:
                        print( el.get_attribute('value'))
                        el.send_keys(keys['sub'])
                elif el.get_attribute('type') == "email":
                    if el.get_attribute('value') != keys["email"]and len(el.get_attribute('value')) < 2:
                        el.send_keys(keys['email'])
                        email_exist = True
                elif el.get_attribute('type') == "tel":
                    if el.get_attribute('value') != keys["phone"]:
                        ActionChains(el).send_keys(Keys.CONTROL).send_keys('A')
                        el.send_keys(keys['phone'])
            if "phone" in attributes.lower() or "tel" in attributes.lower() or "mobile" in attributes.lower():
                if el.get_attribute('value') != keys["phone"]:
                    print("phone_sent")
                    el.send_keys(Keys.CONTROL, 'A')
                    el.send_keys(keys['phone'])
            if  el.get_attribute('type') == "button" or el.get_attribute('value') == "Submit" or el.get_attribute('type') == "submit" or el.get_attribute('submit'):
                try:
                    if email_exist:
                        el.click()
                        print("button clicked")
                        button_clicked = True
                        return (email_exist,button_clicked)
                except:
                    pass
        except Exception as e:
            print(e)
            pass



    for el in button_fields:
        try:
            label = form.find_element_by_xpath(f"""//label[@for="{el.get_attribute('id')}"]""").get_attribute('for')
        except Exception as e:
            label= ""
        attributes = str(el.get_attribute('type')) + str(el.get_attribute('class')) + str(el.get_attribute('name')) + str(el.get_attribute('id')) + label
        if el.get_attribute('value') == "Submit" or el.get_attribute('type') == "submit" or el.get_attribute('submit'):
            try:
                el.click()
                button_clicked = True
                return (email_exist, button_clicked)
            except:
                pass

    return (email_exist, button_clicked)


def get_domain(url):
    isp = url.split('://')
    if len(isp) >1:
        isp = isp[1]
    else:
        isp = isp[0]
    isp = isp.split('/')
    isp = isp[0]
    isp = isp.strip('wwww.')
    return isp
    


def trigger_contact_us_form(url,driver=driver):
    clicked = False
    print(url)
    driver.get(url)
    time.sleep(2)
    domain = get_domain(url)
    keys = get_message(domain)
    genmsg = keys['msg']
    try:
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
    except:
        pass
    try:
        hidden_form = driver.find_element_by_xpath(f"""[@for="form"]""")
    except Exception as e:
        # print(e)
        hidden_form = ""
    forms = driver.find_elements(By.TAG_NAME,"form")
    total_form = len(forms)
    print(len(forms))
    print(len(hidden_form))
    for form in forms:
        try:
            driver.execute_script("arguments[0].scrollIntoView();", form)
        except:
            pass
        time.sleep(2)
        # email_exists = traverse_form(form, keys= keys)
        email_exists, clicked = write_form(form, keys=keys)
        ts = time.time()
        if email_exists and not clicked:
            try:
                time.sleep(3)
                # input()
                form.submit()
                print("form sent")
                clicked = True
            except Exception as e:
                print(e)
        else:
            try:
                form.submit()
            except:
                pass
            print("email exist ->",email_exists)
            print("clicked ->",clicked)
        if clicked:
            break
    if clicked:
        time.sleep(10)
        logs = driver.get_log("performance")
        reqs, responses = process_browser_logs_for_network_events(logs, ts-3)
        req_ids = reqs.keys()
        res_ids = responses.keys()
        if len(req_ids) > 0 and len(res_ids) > 0:
            for id in req_ids:
                try:
                    status = responses[id]['status']
                    if int(status)>= 200 and int(status) < 300:
                        msg = "success"
                        break

                    else:
                        msg = f"status: {status}"
                except:
                    msg = 'response missed'
        else:
            if len(req_ids) == 0:
                msg = "No post request Sent"
            else:
                msg = "No response recieved"
    else:
        if len(forms)==0:
            msg = "No form found on these page"
        else:
            msg = "form found but not submitted"
    
    return (msg, genmsg)

        # break

    # print("sleeping....")
    # time.sleep(300)
    # driver.close()

# trigger_contact_us_form("https://banao.tech/contact")
# trigger_contact_us_form("https://www.pacifichotels.in/contact-us/contact-us.html")
# trigger_contact_us_form("https://www.valmont.in/contact-us/become-a-dealer")
# trigger_contact_us_form("https://www.digitaldescribe.com/Digital-Marketing-Center-Udaipur.html")
# trigger_contact_us_form("http://drmadhok.in/contact_us.aspx")
# trigger_contact_us_form("https://bootstrapmade.com/contact/") #recieving 200 even in error
# trigger_contact_us_form("https://jecrcfoundation.com/contact-us")
# trigger_contact_us_form("https://www.tadobatrails.com/contact-for-jungle-safari-booking")
# trigger_contact_us_form("http://www.thecloudhotel.com/contact.php")
# trigger_contact_us_form("https://ramadaahmedabad.com/contact/")
# trigger_contact_us_form("http://resurgeconsultants.com/contactus")
# trigger_contact_us_form("https://www.solicitorsindia.com/contact-us") #captcha
# trigger_contact_us_form("https://nainabatra.ca/contact/")
# trigger_contact_us_form("https://jawedhabib.com/contact/contact-us/")
# print(trigger_contact_us_form("https://ineuron.ai/contact-us"))
# print(trigger_contact_us_form("https://ineuron.ai/about-us"))
# print(trigger_contact_us_form("https://tulas.edu.in/contact/"))
# time.sleep(300)

def run():
    sites = api_update.get_contact_us_forms()
    for site in sites:
        try:
            msg, genmsg = trigger_contact_us_form(site['contact_us_link'])
        except Exception as e:
            msg = "failed to start" + str(e)
            genmsg = ""
        api_update.update_contact_form_status(site['id'], msg, genmsg)

run()
try:
    driver.quit()
except:
    pass
