import locationtagger

def main(text):
    # print(len(text))
    if len(text) > 1000000:
        text = text[len(text)-1000000:]
    place_entity = locationtagger.find_locations(text = text)
    location_l = place_entity.other_countries + place_entity.cities + place_entity.regions + place_entity.countries
    location_l = list(set(location_l))
    print("------------------>",location_l)
    return location_l