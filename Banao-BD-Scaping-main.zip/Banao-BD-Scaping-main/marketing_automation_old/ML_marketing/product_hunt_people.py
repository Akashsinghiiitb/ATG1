
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from webdriver_manager.chrome import ChromeDriverManager


prefs = {"profile.default_content_setting_values.notifications": 2}
option=webdriver.ChromeOptions()
option.add_experimental_option("excludeSwitches", ["ignore-certificate-errors"])
option.add_argument('headless')
option.add_argument('--no-sandbox')
option.add_experimental_option("prefs", prefs)
#option.add_argument("--start-maximized")
option.add_argument("--window-size=1920x1080")
option.add_argument("--disable-extensions")
option.add_argument("--disable-gpu")
option.add_argument("--disable-dev-shm-usage")
option.add_argument("disable-infobars")

prefs = {"profile.default_content_setting_values.notifications" : 2}
option.add_experimental_option("prefs",prefs)

import xmltodict
import json

sitemap1 = open('users_sitemap1.xml', 'r')
sitemap2 = open('users_sitemap2.xml', 'r')

sitemap1 = xmltodict.parse(sitemap1.read())
sitemap2 = xmltodict.parse(sitemap2.read())

sitemap1 = json.loads(json.dumps(sitemap1))
sitemap2 = json.loads(json.dumps(sitemap2))

print(len(sitemap1['urlset']['url']))
print(len(sitemap2['urlset']['url']))


def getPeopleData(link):
    print(link)
    driver = webdriver.Chrome(ChromeDriverManager().install(), options=option)
    driver.get(link)
    person = {
        'name': "",
        'position': "",
        'link': link,
        'links': [],
    }
    try:
        name = driver.find_element(By.XPATH, '/html/body/div[1]/div[2]/div/header/div[1]/div/div/header/div/div[2]/h1').text
        position = driver.find_element(By.XPATH, '/html/body/div[1]/div[2]/div/header/div[1]/div/div/header/div/div[2]/div[1]').text
        links = [i.get_attribute('href') for i in driver.find_elements(By.XPATH, '//a[@data-test="user-link"]')]
        person['name'] = name
        person['position'] = position
        person['links'] = links
        person['origin'] = 'producthunt'
        for link in links:
            if 'twitter' in link:
                person['twitter'] = link
            elif 'linkedin' in link:
                person['linkedin'] = link
            elif 'facebook' in link:
                person['facebook'] = link
            elif 'instagram' in link:
                person['instagram'] = link
            else:
                person['website'] = link
        del person['links']
        driver.close()
        return person
    except:
        try:driver.close()
        except:pass
        return None



p_urls = sitemap1['urlset']['url'] + sitemap2['urlset']['url']

import requests

# url = "http://127.0.0.1:8000/api/saveExternalPeopleDetails"
url = "http://intranet.atg.party:8989/api/saveExternalPeopleDetails"
n = 10400
j=n
for i in p_urls[n:]:
    print(j)
    j = j + 1
    people= [getPeopleData(i['loc'])]
    request = requests.post(url, json=people)
    print(request.text)

