import requests
from bs4 import BeautifulSoup
import re
# import locationtagger
import json
from log_generator import generate_log

# import Website_categorization
# import get_peoples
# import website_location
import site_rank
import api_update

def do_log(*message):
    output_data = ''
    for i in message:
        output_data += f"{i} "
    print(output_data)
    generate_log(output_data)

def get_domain(url):
    url_without_proto = url.split('://')[-1]
    url_without_dirs = url_without_proto.split('/')[0]
    domain = url_without_dirs.strip('w.')
    do_log(domain)
    return domain

def scrape_main(url, id):
    crawl_status = 1

    if 'http' not in url:
        url = "http://" + url
    
    try:
        res = requests.get(url, timeout=30)
    except Exception as e:
        do_log(e)
        return {'id': id,'crawl_status':2}
    soup = BeautifulSoup(res.content, 'html.parser')
    domain = get_domain(url)
    try:
        category = None#Website_categorization.url_predictor(soup)
    except Exception as e:
        do_log('==============>',e)
        category = None
    try:
        rank = site_rank.get_rank(domain=domain)
    except:
        rank = None
    all_links = list(set(soup.find_all('a',href=True)))
    emails = []
    phones = []
    location_l = []
    peoples = []
    contact_us_page = None
    insta = None
    fb = None
    wa = None
    linkedin = None
    twitter = None
    # location_l = location_l + website_location.main(res.text)
    main_mail_list = re.findall('^[A-Za-z0-9\.\-+_]+@[A-Za-z0-9\.\-+_]+\.[A-Za-z]+', res.text) 
    emails = main_mail_list
    main_phone_list=re.findall("|".join(["\+\d\d?-? ?\d{3}-\d{3}-\d{4}","\\+\\d\\d?-? ?\\d{10}","\\+\\d\\d?-? ?\\d{5} \\d{5}","\\+\\d\\d?-? ?\\d{3}\\-? ?\\d{7}","\\+\\d\\d?-? ?\\d{4}\\-? ?\\d{6}"]), res.text)
    phones = main_phone_list
    do_log(emails, phones, category, rank)
    scraped_urls = []
    for link in all_links:
        if link['href'] in scraped_urls:
            continue
        scraped_urls.append(link['href'])
        if link['href'].split('/')[0]=='':
            link['href'] = "http://"+ domain+ link['href']
        do_log(link['href'])
        try:
            # if "team" in str(link['href']).lower() or "about" in str(link['href']).lower() or "staff" in str(link['href']).lower():
            #     try:
            #         peoples += get_peoples.NameScrap(link['href']).scrape()
            #     except Exception as e:
            #         do_log('people->> ', e)
            #         pass

            if 'contact' in str(link['href']).lower() or 'feedback' in str(link['href']).lower() or 'enquiry' in str(link['href']).lower():
                res_contact = requests.get(link['href'], timeout=30)
                soup_contact = BeautifulSoup(res_contact.content, 'html.parser')
                # location_l = location_l + website_location.main(res_contact.text)
                contact_mail_list = re.findall('^[A-Za-z0-9\.\-+_]+@[A-Za-z0-9\.\-+_]+\.[A-Za-z]+', res_contact.text)
                contact_phone_list=re.findall("|".join(["\+\d\d?-? ?\d{3}-\d{3}-\d{4}","\\+\\d\\d?-? ?\\d{10}","\\+\\d\\d?-? ?\\d{5} \\d{5}","\\+\\d\\d?-? ?\\d{3}\\-? ?\\d{7}","\\+\\d\\d?-? ?\\d{4}\\-? ?\\d{6}"]), res_contact.text)
                emails = emails + contact_mail_list
                phones = phones + contact_phone_list
                if not contact_us_page:
                    contact_us_page = link['href']

            insta_reg= re.search("(\/[a-zA-Z0-9+_.-])?instagram+[a-zA-Z0-9.-]+", link['href'])
            fb_reg= re.search("(\/[a-zA-Z0-9+_.-])?facebook+[a-zA-Z0-9.-]+", link['href'])
            wa_reg= re.search("(\/[a-zA-Z0-9+_.-])?whatsapp+[a-zA-Z0-9.-]+", link['href'])
            linkedin_reg= re.search("(\/[a-zA-Z0-9+_.-])?linkedin+[a-zA-Z0-9.-]+", link['href'])
            twitter_reg= re.search("(\/[a-zA-Z0-9+_.-])?twitter+[a-zA-Z0-9.-]+", link['href'])

            if insta_reg:
                do_log("instagram ->", link['href'])
                insta = link['href']
            elif fb_reg:
                do_log("facebook ->", link['href'])
                fb = link['href']
            elif wa_reg:
                do_log("whatsapp ->", link['href'])
                wa = link['href']
            elif linkedin_reg:
                do_log("linkedin ->", link['href'])
                linkedin = link['href']
            elif twitter_reg:
                do_log("twitter ->", link['href'])
                twitter = link['href']
        except Exception as e:
            do_log(e)
            pass
    do_log(emails)
    emails = list(set(emails))
    phones = list(set(phones))
    location = ", ".join(list(set(location_l)))

    data = {
        'id': id,
        'industry':category,
        'rank':rank,
        'location': location,
        'crawl_status': crawl_status,
        'contact_us_link': contact_us_page,
        'linkedin': linkedin,
        'facebook': fb,
        'twitter': twitter,
        'instagram': insta,
        'emails': emails,
        'phones': phones,
        'peoples': peoples
    }

    do_log(data)
    return data

if __name__ == "__main__":
    # scrape_main("https://celeristx.com/", 0)
    # scrape_main("https://www.pharmatutor.org", 0)
    # get_domain("https://www.celeristx.com.in/a/d/s")
    SERVER_IP = api_update.SERVER_IP
    websites = website_data_api=f"http://{SERVER_IP}/api/website-data?count=10"
    r = requests.get(website_data_api) 
    sites=json.loads(r.text)

    for site in sites:
        url = site['website']
        id = site['id']
        try:
            data = scrape_main(url, id)
            api_update.post_website_data(data)
        except Exception as e:
            do_log(e)
            data = {'id':id, 'crawl_status':2}
            api_update.post_website_data(data)
        


