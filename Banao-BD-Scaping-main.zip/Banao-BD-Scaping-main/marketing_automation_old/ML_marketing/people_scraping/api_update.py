import requests
from urllib.parse import quote
import threading
# from marketing_automation.getting_server_ip import get_server_ip

# IP fetched from atg.party/ms.txt
SERVER_IP = "intranet.atg.party:8989"#get_server_ip()
email_predictor_ip ="banao-email-validator.atgworld.repl.co"
# SERVER_IP = "127.0.0.1:8000"#get_server_ip()
# email_predictor_ip ="127.0.0.1:5000"

def new_api(api2_update):
	print(">>>>>>>>>>>",f"http://{SERVER_IP}/api/new-api?{api2_update}")

	api2_request=requests.post(f"http://{SERVER_IP}/api/new-api?{api2_update}")


	if api2_request.status_code==200:
		print('New API POST SUCCESSFUL')
	else:
		print('Status code is ',api2_request.status_code)
		print('New API COULD NOT POST')


def website_data_api(api3_update,id):
	print('*'*88)
	print(api3_update, id)
	r=requests.post(f"http://{SERVER_IP}/api/website-data/{id}?{api3_update}")
	print(f"http://{SERVER_IP}/api/website-data/{id}?{api3_update}")


	if r.status_code==200:
		print('Website data POST IS SUCCESSFUL')
	else:
		print('Status code is ',r.status_code)
		print('website data COULD NOT POST')

def update_contact_form_status(id,msg, genmsg):
	r=requests.get(f"http://{SERVER_IP}/api/update-contact-page-status?website_id={id}&message={quote(msg)}&genmsg={quote(genmsg)}")
	print(f"http://{SERVER_IP}/api/update-contact-page-status?website_id={id}&message={quote(msg)}")


	if r.status_code==200:
		print('Website data POST IS SUCCESSFUL')
	else:
		print('Status code is ',r.status_code)
		print('website data COULD NOT POST')

def get_contact_us_forms(count=5):
	r = requests.get(f"http://{SERVER_IP}/api/contact-page-links?count=5")
	return r.json()

def save_people(website_id, peoples):
	r = requests.post(f"http://{SERVER_IP}/api/save-ml-people", json={"website_id":website_id,"peoples":peoples})
	if r.status_code==200:
		print('people data POST IS SUCCESSFUL')
	else:
		print('Status code is ',r.status_code)
		print('people data COULD NOT POST')
	return r

def predict_emails(website_id,domain,peoples):
	r = requests.post(f"http://{email_predictor_ip}/bulk-validate", json={"website_id":website_id,"peoples":peoples, "domain":domain})
	if r.status_code==200:
		print('email validator POST IS SUCCESSFUL')
	else:
		print('Status code is ',r.status_code)
		print('email validator COULD NOT POST')
	return r


def predict_emails_fire_and_forget(website_id,domain,peoples):
    threading.Thread(target=predict_emails, args=(website_id,domain,peoples)).start()