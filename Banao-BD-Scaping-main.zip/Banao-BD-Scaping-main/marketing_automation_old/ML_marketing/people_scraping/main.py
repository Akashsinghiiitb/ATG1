from flask import Flask, request
import get_peoples
import asyncio

app = Flask(__name__)

@app.route('/')
def hello_world():
    return "Hello World"

@app.route('/scrape', methods=['GET'])
def single_validator():
    args = request.args
    id = args.get('id')
    url = args.get('url')
    try:
        a = get_peoples.NameScrap(url, id).scrape()
        return "success"
    except Exception as e:
        return str(e)





if __name__ == '__main__':
     app.run()