#!/usr/bin/env python
# coding: utf-8

# In[1]:


import requests
import pandas as pd
import time
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from bs4 import BeautifulSoup
from csv import writer
import re


# In[2]:


def url_predictor(url):
    list_of_lists=[]
    lst=[]
    driver = webdriver.Chrome(ChromeDriverManager().install())
    lst.append(url)
    website = requests.get(url)
    time.sleep(10)
    soup = BeautifulSoup(website.content)
    text = [''.join(s.findAll(text=True))for s in soup.findAll('p')]
    
    words=''
    for i in text:
        words+=str(i)
    #print(words)
            
    from flashtext import KeywordProcessor
       
    sports = ["sports", "athletics", "competitions", "events", "teams", "scores", "results", "stats", "athletes", "football", "basketball", "baseball", "soccer", "hockey", "tennis", "golf", "rugby", "cricket", "swimming", "cycling", "boxing", "wrestling", "martial arts", "motorsports", "track and field", "volleyball", "gymnastics", "sports news"]
    entertainment = ["entertainment", "movies", "tv shows", "celebrities", "music", "arts", "culture", "reviews", "gossip", "fashion", "comedy", "drama", "documentary", "horror", "romance", "action", "adventure", "animation", "fantasy", "sci-fi", "thriller", "concerts", "festivals", "entertainment news"]
    health_care = ["healthcare", "health", "medicine", "medical", "wellness", "fitness", "nutrition", "mental health", "disease", "treatment", "medications", "doctors", "hospitals", "clinics", "health insurance", "health policy", "public health"]
    restaurant = ["restaurant", "food", "cuisine", "menu", "reviews", "recipes", "chefs", "dining", "hospitality", "culinary"]
    m_learning = ['lms','mobile','mobiles','phone','phones','smart','smartphone','smartphones','improvement','building','microlearning','training','trains','course','courses','LMS','learn','learning','learners','collaborative','skills','organisation','programs','motivation','week','program','management','access','video','clip','clips','collaborative','Corporate','Training','Platform','development','holistic','growth','comprehensive','coach','Speech','Assistant','speaking','accent','accents','recognition','performance']
    real_estate = ["real estate", "property", "homes", "apartments", "condos", "commercial property", "mortgage", "rentals", "buying", "selling", "home values", "real estate news"]
    finance = ["finance", "investing", "stocks", "bonds", "mutual funds", "retirement planning", "taxes", "financial advice", "budgeting", "personal finance", "financial news"]
    fitness = ["fitness", "exercise", "workouts", "nutrition", "diet", "weight loss", "yoga", "pilates", "running", "strength training", "cardio", "personal training", "fitness equipment"]
    travel = ["travel", "hotels", "flights", "vacations", "cruises", "tourism", "destinations", "travel tips", "budget travel", "adventure travel", "solo travel", "luxury travel"]
    business = ["business", "entrepreneurship", "startups", "management", "leadership", "innovation", "marketing", "sales", "strategy", "finance", "operations", "human resources", "business news"]
    government = ["government", "politics", "public policy", "legislation", "regulations", "public services", "national security", "international relations", "foreign policy"]
    politics = ['politics','politic','attacker','interview','perty','parties','truth','election','elections','police','crime','freedom','vote','weekday','idea','ideas','votes','voters','voter','reporter','truth','republicans','natinal','nationalism','nationalists','nationalist','violence','republic','affairs','magazine','affair','political','report','reports','weapons','weapon','news','newsletter','prime','minister','controversial']
    
    adtech_keywords = ["adtech", "advertising", "digital marketing", "programmatic", "ad exchange", "RTB", "DSP", "SSP", "ad servers", "ad networks", "ad optimization", "ad targeting", "display advertising", "video advertising", "mobile advertising", "native advertising", "social media advertising"]
    advanced_manufacturing_keywords = ["advanced manufacturing", "smart manufacturing", "industry 4.0", "automation", "robotics", "machine learning", "artificial intelligence", "data analytics", "supply chain management", "digital twin", "cybersecurity", "sustainability", "additive manufacturing", "3D printing", "precision manufacturing", "nanomanufacturing"]
    agtech_keywords = ["Agtech", "Agriculture", "Farming", "Precision agriculture", "Crop management", "Livestock management", "Irrigation", "Soil health", "Sustainable agriculture"]
    ai_ml_keywords = ['artificial intelligence', 'machine learning', 'deep learning', 'neural networks', 'data mining', 'predictive modeling', 'natural language processing', 'computer vision', 'image recognition']
    audiotech_keywords = ['audiotech', 'audio equipment', 'audio technology', 'audio engineering', 'sound design', 'acoustics', 'audio processing', 'audio software', 'music production']
    ar_keywords = ['augmented reality', 'ar technology', 'mixed reality', 'virtual reality', 'ar applications', 'ar gaming', 'ar hardware', 'ar software', 'ar development']
    Autonomous_cars = ['self-driving', 'driverless', 'autonomous vehicles', 'robot cars', 'smart transportation', 'vehicle automation', 'intelligent vehicles', 'automated driving systems']
    B2B_payments = ['business-to-business payments', 'digital invoicing', 'vendor payments', 'payment processing', 'supplier payments', 'accounts payable automation', 'electronic payments', 'financial supply chain management']
    Beauty = ['skincare', 'cosmetics', 'makeup', 'haircare', 'fragrances', 'beauty tech', 'clean beauty', 'natural beauty']
    Big_Data = ['data analytics', 'data mining', 'big data processing', 'data warehousing', 'data integration', 'business intelligence', 'data management', 'predictive analytics']
    
    Cannabis = ['marijuana', 'CBD', 'cannabis-infused products', 'medical marijuana', 'cannabis cultivation', 'hemp products', 'cannabis delivery services', 'cannabis testing']
    Carsharing = ['car rental', 'car sharing', 'peer-to-peer car sharing', 'car subscription', 'ridesharing', 'carpooling', 'ride-hailing', 'mobility-as-a-service']
    Cleantech = ['clean energy', 'renewable energy', 'sustainable technology', 'green technology', 'energy efficiency', 'carbon capture', 'smart grids', 'biofuels']
    Climate_tech = ['climate change', 'carbon reduction', 'carbon offsetting', 'climate modeling', 'renewable energy', 'sustainability', 'climate adaptation', 'green infrastructure']
    Cloudtech_DevOps = ['cloud computing', 'DevOps', 'continuous integration', 'continuous delivery', 'infrastructure as code', 'microservices', 'containerization', 'serverless computing']
    Construction_technology = ['construction management software', 'building information modeling', 'construction robotics', 'drones in construction', 'smart building systems', 'prefabrication', 'construction safety technology', 'construction materials technology']
    Cryptocurrency_blockchain = ['cryptocurrency', 'blockchain', 'smart contracts', 'digital wallets', 'decentralized finance', 'crypto mining', 'crypto trading', 'stablecoins']
    Cybersecurity = ['network security', 'endpoint security', 'cloud security', 'data protection', 'identity and access management', 'security analytics', 'vulnerability management', 'threat intelligence']
    Digital_health = ['healthcare technology', 'telehealth', 'digital therapeutics', 'wearable technology', 'artificial intelligence in healthcare', 'precision medicine', 'remote patient monitoring', 'personalized medicine']
    Ecommerce = ['online shopping', 'marketplace', 'e-commerce platforms', 'dropshipping', 'mobile commerce', 'social commerce', 'subscription e-commerce', 'cross-border e-commerce']
    
    Edtech = ['online education', 'e-learning', 'educational software', 'distance learning', 'adaptive learning', 'gamification in education', 'learning analytics', 'MOOCs']
    Ephemeral_content = ['disappearing messages', 'ephemeral social media', 'self-destructing photos', 'ephemeral marketing', 'ephemeral video', 'transient content', 'ephemeral messaging', 'ephemeral user-generated content']
    esports_keywords = ["eSports","Gaming","Online Gaming","Competitive Gaming","Professional Gaming","Video Games","Tournaments","Gaming Industry","eSports Events","Gaming Leagues","Gaming News","Gaming Community","Gaming Culture","Streaming","Gaming Influencers","eSports Teams","eSports Championships","eSports Sponsorship","Virtual Reality","Augmented Reality"]
    Femtech_keywords = ['Women’s Health', 'Menstrual', 'Reproductive Health', 'Fertility', 'Periods', 'Pregnancy', 'Childbirth', 'Breastfeeding', 'Pelvic Health', 'Menopause', 'Perimenopause', 'PCOS', 'Endometriosis', 'STI Testing', 'STI Treatment', 'Sexual Health', 'Contraception', 'Family Planning', 'Breast Cancer', 'Cervical Cancer', 'Ovarian Cancer', 'Women’s Wellness', 'Telemedicine', 'Digital Health', 'Mobile Health', 'Personalized Medicine', 'E-Health', 'M-Health', 'Artificial Intelligence', 'Data Analytics', 'Blockchain', 'Wearable Technology', 'Remote Monitoring', 'Virtual Reality', 'Augmented Reality']
    fintech_keywords = ['banking','blockchain','cryptocurrency','credit','debit','digital','e-commerce','financial','fintech','investing','investment','mobile','online','payments','platform','robo-advisor','savings','security','smart contracts','trading']
    Foodtech = ["food delivery", "meal kit", "online grocery", "meal planning", "food safety",  "smart kitchen", "food waste reduction", "supply chain optimization", "agtech", "nutrition tracking", "recipe sharing", "food traceability", "foodtech innovation", "farm to table", "mobile ordering", "restaurant technology", "food industry disruption"]
    Gaming = ['gaming','video games','console','PC gaming','mobile gaming','online gaming','esports','streaming','game development','game design','gameplay','multiplayer','single player','first person shooter','role-playing games','action games','adventure games','strategy games','sports games','racing games','virtual reality','gaming community','gaming news','game reviews','game forums','game merchandise','gaming events']
    Healthtech = ['Healthtech', 'Healthcare', 'Medical', 'Health', 'Telemedicine', 'EHR', 'EMR', 'mHealth', 'DigitalHealth', 'PrecisionMedicine', 'MedicalDevices', 'HealthAnalytics', 'HealthInformatics', 'PopulationHealth', 'MedicalSoftware', 'HealthcareIT', 'ElectronicHealth', 'MedicalRecords', 'HealthIT', 'ClinicalDecisionSupport', 'MedicalImaging', 'HealthTechStartup', 'HealthTechIncubator', 'HealthTechAccelerator', 'HealthTechInvestment', 'HealthcareInvestment', 'HealthTechFunding']
    HRtech = ["Human Resources","HR","HRtech", "Recruiting", "Talent Acquisition", "Onboarding", "Employee Engagement","Performance Management", "Learning and Development","Workforce Management","People Analytics","HR Analytics","Benefits Administration","Payroll Management","Time and Attendance","Employee Experience","Career Development","Succession Planning","Diversity and Inclusion","Remote Work","Workplace Culture","Employment Law","Compliance","Hiring", "Human Capital Management"]
    impact_investing_keywords = ["socially responsible investing","environmental, social, and governance","ESG investing","sustainable investing","climate change","impact investing","positive impact","impact funds","impact measurement","impact reporting","social impact","green investing","ethical investing","impact capital","responsible investing","double bottom line","triple bottom line","mission-driven investing","values-aligned investing","impact portfolio","impactful investments","social impact bonds","impact entrepreneurship","impact metrics","impact assessment","impact evaluation","impact due diligence","impact investing networks","impact investors","impact-driven","impactful companies","impactful solutions","impactful startups","sustainable development goals","SDGs","impact ecosystem","impact-oriented","impactful initiatives", "impact finance", "impactful leadership", "impact investment consulting", "impact investing conferences","impact investment advisory","impact investment platforms", "impact investment opportunities", "impact investing community","impact investing funds","impact investing examples","impact investing strategies", "impact investing companies", "impact investing trends","impact investing jobs","impact investing events", "impact investing news","impact investing resources","impact investing organizations","impact investing education","impact investing challenges", "impact investing risks","impact investing returns",  "impact investing research",  "impact investing success stories","impact investing reports", "impact investing best practices", "impact investing benchmarks","impact investing statistics"]
        
    Industrials_keywords = ['manufacturing', 'industrial', 'engineering', 'process control', 'automation', 'maintenance', 'sustainability', 'energy efficiency', 'robotics', 'supply chain management', 'logistics', 'material handling', 'safety', 'productivity', 'efficiency', 'innovation']
    Infrastructure = ['Asset Management', 'Bridges', 'Dams', 'Design-Build', 'EPC Contracts', 'Environmental', 'Facility Management', 'Highways', 'Infrastructure Financing', 'Infrastructure Planning', 'Irrigation', 'Municipal', 'Ports', 'PPP', 'Project Management', 'Railways', 'Roads', 'Smart Cities', 'Tunnels', 'Urban Development', 'Water Management']
    Insurtech = ['Insurance', 'Insurtech', 'Underwriting', 'Claims', 'Policies', 'Premiums', 'Risk management', 'Digital insurance', 'Automated claims', 'Fraud detection', 'Telematics', 'IoT', 'Blockchain', 'Artificial intelligence', 'Big data', 'Predictive analytics', 'Customer experience', 'Regulatory compliance', 'Cybersecurity']
    Internet_of_Things_keywords = ["IoT","Internet of Things","connected devices","smart home","smart city","smart grid","wearables","machine-to-machine (M2M)","data analytics","cloud computing","edge computing","artificial intelligence (AI)",    "augmented reality (AR)",    "virtual reality (VR)",    "smart sensors",    "energy management",    "predictive maintenance",    "industrial IoT (IIoT)",    "smart manufacturing",    "smart agriculture",    "smart transportation",    "smart logistics",    "blockchain",    "cybersecurity"]
    Legal_tech = ['Legaltech', 'Lawtech', 'Artificial Intelligence', 'Contract Management', 'Legal Document Automation', 'Document Management', 'E-Discovery', 'Legal Analytics', 'Legal Operations', 'Regtech', 'Compliance', 'Litigation Management', 'Intellectual Property Management', 'Data Privacy', 'Cybersecurity', 'Blockchain', 'Smart Contracts', 'Online Dispute Resolution', 'Alternative Legal Services', 'Virtual Law Firms']
    life_sciences_keywords = ['biotech', 'biotechnology', 'clinical_trials', 'drug_development', 'genomics', 'healthcare', 'medical_devices', 'medical_technology', 'pharmaceuticals', 'precision_medicine', 'regenerative_medicine', 'stem_cells']
    Lifestyles_of_Health_Sustainability_wellness = ["Organic", "Sustainable", "Wellness", "Health", "Nutrition", "Fitness", "Environmentally-friendly", "Plant-based", "Mindfulness", "Yoga", "Meditation", "Eco-friendly", "Natural", "Non-toxic", "Green living", "Holistic", "Alternative medicine", "Renewable energy", "Zero-waste"]
    Manufacturing = ['3D printing', 'Additive manufacturing', 'Advanced materials', 'Automation', 'CAD/CAM', 'CNC', 'Digital twin', 'Factory of the future', 'Industrial IoT', 'Industry 4.0', 'Lean manufacturing', 'Machine learning', 'MES', 'PLM', 'Predictive maintenance', 'Robotics', 'Smart manufacturing', 'Supply chain management', 'Virtual reality']
    Marketing_tech = ['Adtech', 'Analytics', 'Branding', 'Content marketing', 'Customer engagement', 'Digital marketing', 'Email marketing', 'Influencer marketing', 'Marketing automation', 'Market research', 'Mobile marketing', 'Performance marketing', 'Personalization', 'Search engine optimization (SEO)', 'Social media marketing', 'User experience (UX)', 'Video marketing']
    Micro_mobility = ['Electric scooters', 'Bike sharing', 'Last-mile transportation', 'E-bikes', 'Dockless bikes', 'Ride sharing', 'Urban mobility', 'Transportation as a service (TaaS)', 'Mobility solutions', 'Sustainable transportation', 'Personal transportation', 'Micromobility solutions', 'Smart cities', 'Transportation technology', 'Commuting solutions']
        
    Mobile = ['mobile', 'smartphones', 'apps', 'android', 'iOS', 'operating systems', 'mobile devices', 'mobile development', 'mobile security', 'mobile marketing', 'mobile payments', 'mobile analytics', 'mobile UI/UX', 'mobile gaming']
    Mobile_commerce = ['mobile commerce', 'mobile payments', 'mobile banking', 'mobile wallet', 'mobile money', 'mobile transactions', 'mobile checkout', 'mobile invoicing', 'mobile point of sale', 'mobile shopping', 'mobile coupons', 'mobile loyalty programs', 'mobile marketing', 'mobile advertising', 'mobile engagement']
    Mobility_tech = ["autonomous vehicles", "ride-sharing", "car-sharing", "e-bikes", "e-scooters", "micro-mobility", "urban mobility", "connected cars", "transportation as a service", "mobility solutions"]
    Mortgage_tech = ['Mortgage automation', 'Digital lending', 'Loan origination', 'Mortgage servicing', 'Underwriting technology', 'Mortgage processing', 'Loan management system', 'Mortgage analytics', 'Mortgage software', 'Closing technology']
    Nanotechnology = [    "Nanotechnology",    "Nanoparticles",    "Nanomaterials",    "Nanofabrication",    "Nanoelectronics",    "Nanomedicine",    "Nanobiotechnology",    "Nanophysics",    "Nanocarriers",    "Nanomanufacturing",    "Nanosensors",    "Nanotoxicology",    "Nanorobotics",    "Nanotubes",    "Nanowires",    "Quantum Dots",    "Carbon Nanotubes",    "Fullerenes",    "Graphene",    "Nanocatalysis",    "Nanofluidics",    "Nanopatterning",    "Nanocomposites",    "Nanosecond Laser Pulses",    "Self-Assembly",    "Supramolecular Chemistry",    "Biosensors"]
    Oil_gas = ["Exploration", "Drilling", "Production", "Upstream", "Midstream", "Downstream", "Refining", "Reservoir", "Oilfield services", "Petrochemicals", "Pipeline", "LNG", "Offshore", "Onshore", "Fracking", "Refinery", "E&P", "Geology", "Geophysics", "Wellbore", "Seismic", "Rig", "Pumpjack", "Natural gas", "Crude oil", "Petroleum", "Energy"]
    Oncology = [    "cancer",    "oncology",    "tumor",    "chemotherapy",    "radiation therapy",    "immunotherapy",    "precision medicine",    "genomics",    "proteomics",    "biomarkers",    "clinical trials",    "patient care",    "support groups",    "cancer research",    "cancer treatment",    "diagnosis",    "screening",    "prevention"]
    Pet_tech = [    "Pet tracking",    "Pet health monitoring",    "Pet food and nutrition",    "Pet grooming",    "Pet training",    "Pet adoption and rescue",    "Pet-friendly accommodations",    "Pet insurance",    "Pet toys and accessories",    "Pet waste management"]
    Ridesharing = ['ridesharing', 'carpooling', 'ride-hailing', 'ride-sharing', 'car-sharing', 'ride-pooling', 'car-pooling', 'rideshare', 'riders', 'drivers', 'commuting', 'transportation', 'ride-to-work', 'lift-sharing', 'ride-matching', 'ride-splitting', 'shared-mobility']
    Robotics_drones = [    'Robotics',     'Drones',     'Unmanned Vehicles',     'Autonomous Robotics',     'Aerial Robotics',     'Industrial Robotics',     'Robotics Engineering',     'Drone Technology',     'Robotics Software',     'Robotics Applications',     'Robotics Innovation',     'Robotics Industry',     'Robotics and AI',     'Robotics Research',     'Robotic Systems',     'Robotics Control Systems',     'Robotics Sensors',     'Drone Racing',     'Robotics Startups']
        
    SaaS = ['Cloud computing', 'Enterprise software', 'Business software', 'Cloud-based solutions', 'Collaboration', 'CRM (Customer Relationship Management)', 'ERP (Enterprise Resource Planning)', 'Project management', 'Productivity', 'Communication', 'Marketing automation', 'Customer support', 'Analytics', 'Data management', 'Integration', 'Automation', 'Scalability']
    Space_tech = ['space exploration', 'satellite', 'rocket', 'spacecraft', 'orbital', 'asteroid mining', 'space tourism', 'space settlement', 'space technology', 'commercial space', 'space launch', 'spacex', 'nasa', 'blue origin', 'isro', 'esa', 'roscosmos', 'space science', 'space industry', 'space policy']
    Supply_chain_technology = ['Inventory management', 'Logistics', 'Warehouse management', 'Transportation management', 'Demand planning', 'Procurement', 'Supplier relationship management', 'Supply chain analytics', 'Traceability', 'Visibility'] 
    Virtual_reality = ['VR', 'Augmented Reality', 'Immersive Technology', 'Virtual Environment', '3D Modeling', 'Simulation', 'Headset', 'Haptic Feedback', 'Interactive Experience', 'Spatial Computing']
    Wearables_quantified_self = [    'fitness tracking',     'health monitoring',     'sleep tracking',     'heart rate monitoring',     'activity tracking',     'step counting',     'biometric sensors',     'wearable technology',     'exercise tracking',     'calorie counting',     'health data',     'wellness tracking',     'sports tracking']
    printing_3D = ['3D modeling', 'Additive manufacturing', 'CAD', 'Fused deposition modeling (FDM)', 'Stereolithography (SLA)', 'Selective Laser Sintering (SLS)', 'Powder Bed Fusion (PBF)', 'Rapid prototyping', 'Digital fabrication', 'G-code', 'Filament', 'Resin', 'Build volume', 'Layer height', 'Nozzle diameter', 'Build plate', 'Build platform', 'Support structures', 'Post-processing']
    Accounting_Auditing = ['accounting', 'auditing', 'financial reporting', 'taxation', 'compliance', 'bookkeeping', 'payroll', 'budgeting', 'forecasting', 'internal controls', 'audit assurance', 'fraud detection', 'forensic accounting', 'valuation', 'risk management', 'SOX compliance', 'external auditing', 'management accounting', 'cost accounting', 'tax planning', 'financial analysis', 'CPA', 'IFRS', 'GAAP']
    Agriculture = ['Agribusiness', 'Agroecology', 'Agrotechnology', 'Crop management', 'Farm equipment', 'Farm management', 'Precision agriculture', 'Soil health', 'Sustainable farming', 'Vertical farming']
    Airlines = ["Airline tickets", "Flight schedules", "Flight status", "Airport information", "Baggage allowances", "Loyalty programs", "In-flight services", "Airline fleet", "Safety and security", "Check-in process", "Boarding process", "Aircraft cabin classes", "Airline partnerships", "Travel insurance", "Destination information", "Airline news and updates"]
    Amusement_Recreation = ['Amusement parks', 'Theme parks', 'Water parks', 'Zoos', 'Aquariums', 'Museums', 'Art galleries', 'Concerts', 'Festivals', 'Sports events', 'Outdoor activities', 'Adventure activities', 'Recreational vehicles', 'Camping', 'Hiking', 'Fishing', 'Hunting', 'Boating', 'Golfing', 'Skiing', 'Snowboarding', 'Cycling', 'Fitness', 'Yoga', 'Meditation']
        
    Banking = ['Banking', 'Bank', 'Finance', 'Financial', 'Deposit', 'Loan', 'Credit', 'Debit', 'Checking', 'Savings', 'Interest', 'Investment', 'ATM', 'Online Banking', 'Mobile Banking', 'Wealth Management', 'Mortgage', 'Commercial Banking', 'Small Business Banking', 'Corporate Banking', 'Retail Banking', 'Private Banking']
    Business_Services = [    "Business consulting",    "Management consulting",    "Strategy consulting",    "Financial consulting",    "Risk management",    "Outsourcing",    "Business process outsourcing (BPO)",    "Human resources (HR) consulting",    "IT consulting",    "Marketing consulting",    "Sales consulting",    "Accounting services",    "Bookkeeping services",    "Tax services",    "Legal services",    "Intellectual property (IP) services",    "Translation services",    "Document management",    "Facilities management",    "Supply chain management",    "Logistics",    "Procurement",    "Business intelligence",    "Data analytics",    "Market research",    "Customer experience (CX) consulting",    "Employee engagement",    "Leadership development",    "Training and development",    "Change management",    "Project management"]
    Chemical_Industry = ['chemicals', 'manufacturing', 'industrial', 'science', 'research', 'engineering', 'production', 'supply chain', 'materials', 'pharmaceuticals', 'biotech', 'petrochemicals', 'energy', 'environment', 'sustainability', 'innovation', 'quality control', 'process optimization', 'product development', 'safety', 'regulations']
    Construction = [    'Architecture',    'Building materials',    'Civil engineering',    'Construction management',    'Cost estimation',    'Design',    'Green building',    'Infrastructure',    'Project management',    'Real estate development',    'Safety',    'Structural engineering']
    Consumer_Discretionary = ["Apparel", "Automotive", "Beauty", "Consumer Electronics", "Entertainment", "Gaming", "Home Goods", "Hospitality", "Luxury Goods", "Retail", "Sporting Goods", "Travel"]
    Consumer_Services = ['customer service', 'customer support', 'consumer products', 'consumer goods', 'consumer reviews', 'consumer surveys', 'consumer feedback', 'consumer trends', 'consumer insights', 'consumer behavior', 'consumer research', 'consumer advocacy', 'consumer protection', 'consumer education', 'consumer rights', 'consumer empowerment', 'consumer decision making', 'consumer satisfaction', 'consumer engagement', 'consumer experience', 'consumer loyalty', 'consumer retention', 'consumer marketing', 'consumer advertising', 'consumer promotions']
    Consumer_Staples = [    "food",     "beverage",     "snack",     "candy",     "grocery",     "retail",     "consumer goods",     "household essentials",     "personal care",     "health",     "hygiene",     "cleaning products",     "baby care",     "pet food",     "tobacco",     "alcohol"]
    Energy = ["Energy","Alternative energy", "Bioenergy", "Clean energy", "Coal", "Electricity", "Energy efficiency", "Energy storage", "Fossil fuels", "Geothermal energy", "Hydroelectricity", "Natural gas", "Nuclear energy", "Oil", "Renewable energy", "Solar energy", "Wind energy"]
    Engineering = ['Civil Engineering', 'Mechanical Engineering', 'Electrical Engineering', 'Chemical Engineering', 'Industrial Engineering', 'Aerospace Engineering', 'Biomedical Engineering', 'Environmental Engineering', 'Materials Engineering', 'Nuclear Engineering']
    Environment =[    "sustainability",    "renewable energy",    "recycling",    "climate change",    "green technology",    "ecology",    "conservation",    "natural resources",    "carbon footprint",    "biodiversity",    "pollution",    "waste management",    "sustainable development",    "greenhouse gases",    "clean energy",    "environmental impact",    "sustainable living",    "environmental responsibility",    "energy efficiency",    "ocean conservation"]
        
    Fashion = ["fashion", "apparel", "clothing", "designer", "luxury", "style", "accessories", "footwear", "retail", "boutique", "trend", "textile", "garment", "collection", "fashionista", "model", "runway", "brand", "shopping", "e-commerce"]
    Heavy_Industry = ["Industrial", "Manufacturing", "Heavy Machinery", "Heavy Equipment", "Heavy Duty",  "Infrastructure", "Construction", "Engineering", "Logistics", "Mining", "Metals",  "Materials Handling", "Oil and Gas", "Power Generation", "Renewable Energy",  "Utilities", "Water Treatment", "Waste Management", "Environmental Services"]
    Hotels = ['hotel', 'booking', 'reservation', 'room', 'suite', 'amenities', 'luxury', 'discounts', 'deals', 'vacation', 'travel', 'accommodation', 'guests', 'hospitality', 'front desk', 'check-in', 'check-out', 'rates', 'packages', 'business center', 'conferences', 'events', 'weddings', 'catering', 'restaurant', 'bar', 'room service', 'spa', 'fitness center', 'pool', 'beach', 'airport shuttle', 'parking', 'loyalty program', 'reviews', 'feedback', 'location', 'attractions', 'nearby']
    Information_Technology = ['IT', 'software', 'hardware', 'networking', 'database', 'programming', 'cloud computing', 'big data', 'cybersecurity', 'artificial intelligence', 'machine learning', 'data analytics', 'web development', 'mobile app development', 'digital transformation', 'internet of things', 'blockchain', 'devops']
    Law = ['law firm', 'attorney', 'lawyer', 'legal services', 'legal advice', 'litigation', 'contract', 'arbitration', 'mediation', 'intellectual property', 'patent', 'trademark', 'copyright', 'employment law', 'immigration law', 'corporate law', 'business law', 'tax law', 'real estate law', 'family law', 'personal injury law', 'criminal law', 'trial', 'appeal']
    Logistics = ['Freight', 'Transportation', 'Supply chain', 'Warehousing', 'Distribution', 'Inventory', 'Shipping', 'Tracking', 'Logistics management', 'Freight forwarding', 'Last-mile delivery', 'E-commerce fulfillment', 'Cross-docking', 'Intermodal', 'Reverse logistics', 'Customs brokerage', '3PL', '4PL', 'Carrier', 'Load optimization', 'Route optimization']
    Media = ["Entertainment", "News", "Broadcasting", "Television", "Radio", "Magazines", "Newspapers", "Journalism", "Social Media", "Digital Media", "Video Production", "Content Creation", "Advertising", "Public Relations"]
    Mining = ["Exploration", "Extraction", "Production", "Minerals", "Metals", "Gold", "Silver", "Copper", "Iron", "Zinc", "Nickel", "Aluminum", "Diamond", "Coal", "Oil shale", "Fracking", "Refining", "Smelting", "Mine safety", "Sustainability"]
    Non_profits = ['Charity', 'Donations', 'Volunteers', 'Fundraising', 'Philanthropy', 'Social responsibility', 'Non-governmental organization (NGO)', 'Community service', 'Advocacy', 'Grantmaking']
    Professional_Services = ['consulting', 'advisory', 'professional services', 'business services', 'finance', 'legal', 'tax', 'strategy', 'management consulting', 'risk management', 'supply chain', 'operations', 'human resources', 'marketing', 'outsourcing', 'project management', 'information technology', 'change management', 'process improvement', 'performance improvement']
    
    Publishing = ["Books", "E-books", "Audiobooks", "Magazines", "Newspapers", "Publishing houses", "Literary agents", "Self-publishing", "Editing", "Printing", "Distribution", "Content creation", "Copyright", "Author", "Reader", "Genre", "Bestsellers", "Sales"]
    Retail = ['Online shopping', 'Discounts', 'Sales', 'Free shipping', 'Return policy', 'Customer service', 'Products', 'Brands', 'Clothing', 'Shoes', 'Accessories', 'Beauty', 'Home decor', 'Gifts', 'Shopping cart', 'Checkout', 'Payment options', 'Reviews', 'Ratings', 'New arrivals', 'Popular items', 'Trending products', 'Seasonal offers']
    Science_Technology = ["research", "innovation", "discovery", "technology", "science", "engineering", "experiment", "data", "analysis", "simulation", "modeling", "disruptive", "artificial intelligence", "machine learning", "big data", "internet of things", "robotics", "nanotechnology", "biotechnology", "medicine", "healthcare", "energy", "sustainability", "climate change", "environment", "quantum", "genetics", "chemistry", "physics", "mathematics"]
    Telecom = ['5G', 'Broadband', 'Carrier', 'Cloud computing', 'Fiber optics', 'Internet of things (IoT)', 'Mobile networks', 'Network infrastructure', 'Satellite', 'Telephony']
    tourism_keywords = ['Accommodation', 'Adventure tourism', 'Airline', 'All-inclusive', 'Amusement park', 'Attractions', 'Backpacking', 'Beach', 'Booking', 'Budget travel', 'Car rental', 'Cruise', 'Destination', 'Eco-tourism', 'Family-friendly', 'Food and beverage', 'Group tours', 'Heritage tourism', 'Hiking', 'Hospitality', 'Hotel', 'Leisure', 'Lodging', 'Luxury', 'Museum', 'Nature tourism', 'Package tour', 'Resort', 'Sightseeing', 'Sustainable tourism', 'Theme park', 'Tour guide', 'Tour operator', 'Tour package', 'Tourist information', 'Transportation', 'Travel agency', 'Vacation', 'Wildlife tourism']
    Transportation = ['Autonomous vehicles', 'Electric vehicles', 'Connected cars', 'Mobility as a Service (MaaS)', 'Transportation as a Service (TaaS)', 'Ride-hailing', 'Ride-sharing', 'Public transportation', 'Infrastructure', 'Logistics', 'Fleet management', 'Traffic management', 'Vehicle-to-vehicle communication (V2V)', 'Vehicle-to-everything communication (V2X)', 'Intelligent Transportation Systems (ITS)', 'Smart cities', 'Last mile delivery', 'Freight transportation']
    Utilities = ['Energy', 'Utility', 'Power', 'Water', 'Gas', 'Electricity', 'Renewable energy', 'Smart grid', 'Energy efficiency', 'Energy management']
    
    import numpy as np
    
    kp_sports = KeywordProcessor()
    for i in sports:
        kp_sports.add_keyword(i)
    kp_sports=kp_sports.extract_keywords(words)
    kp_sports = np.unique(kp_sports)
    kp_sports = list(kp_sports)
    
    kp_entertainment = KeywordProcessor()
    for i in entertainment:
        kp_entertainment.add_keyword(i)
    kp_entertainment = kp_entertainment.extract_keywords(words)
    kp_entertainment = np.unique(kp_entertainment)
    kp_entertainment = list(kp_entertainment)
    
    kp_health_care = KeywordProcessor()
    for i in health_care:
        kp_health_care.add_keyword(i)
    kp_health_care = kp_health_care.extract_keywords(words)
    kp_health_care = np.unique(kp_health_care)
    kp_health_care = list(kp_health_care)
    
    kp_restaurant = KeywordProcessor()
    for i in restaurant:
        kp_restaurant.add_keyword(i)
    kp_restaurant = kp_restaurant.extract_keywords(words)
    kp_restaurant = np.unique(kp_restaurant)
    kp_restaurant = list(kp_restaurant)
    
    kp_m_learning = KeywordProcessor()
    for i in m_learning:
        kp_m_learning.add_keyword(i)
    kp_m_learning = kp_m_learning.extract_keywords(words)
    kp_m_learning = np.unique(kp_m_learning)
    kp_m_learning = list(kp_m_learning)
    
    kp_real_estate = KeywordProcessor()
    for i in real_estate:
        kp_real_estate.add_keyword(i)
    kp_real_estate = kp_real_estate.extract_keywords(words)
    kp_real_estate = np.unique(kp_real_estate)
    kp_real_estate = list(kp_real_estate)
    
    kp_finance = KeywordProcessor()
    for i in finance:
        kp_finance.add_keyword(i)
    kp_finance = kp_finance.extract_keywords(words)
    kp_finance = np.unique(kp_finance)
    kp_finance = list(kp_finance)
    
    kp_fitness = KeywordProcessor()
    for i in fitness:
        kp_fitness.add_keyword(i)
    kp_fitness = kp_fitness.extract_keywords(words)
    kp_fitness = np.unique(kp_fitness)
    kp_fitness = list(kp_fitness)
    
    kp_travel = KeywordProcessor()
    for i in travel:
        kp_travel.add_keyword(i)
    kp_travel = kp_travel.extract_keywords(words)
    kp_travel = np.unique(kp_travel)
    kp_travel = list(kp_travel)
    
    kp_business = KeywordProcessor()
    for i in business:
        kp_business.add_keyword(i)
    kp_business = kp_business.extract_keywords(words)
    kp_business = np.unique(kp_business)
    kp_business = list(kp_business)
    
    kp_government = KeywordProcessor()
    for i in government:
        kp_government.add_keyword(i)
    kp_government = kp_government.extract_keywords(words)
    kp_government = np.unique(kp_government)
    kp_government = list(kp_government)

    kp_politics = KeywordProcessor()
    for i in politics:
        kp_politics.add_keyword(i)
    kp_politics = kp_politics.extract_keywords(words)
    kp_politics = np.unique(kp_politics)
    kp_politics = list(kp_politics)
      
    kp_adtech_keywords = KeywordProcessor()
    for i in adtech_keywords:
        kp_adtech_keywords.add_keyword(i)
    kp_adtech_keywords = kp_adtech_keywords.extract_keywords(words)
    kp_adtech_keywords = np.unique(kp_adtech_keywords)
    kp_adtech_keywords = list(kp_adtech_keywords)
    
    kp_advanced_manufacturing_keywords = KeywordProcessor()
    for i in advanced_manufacturing_keywords:
        kp_advanced_manufacturing_keywords.add_keyword(i)
    kp_advanced_manufacturing_keywords = kp_advanced_manufacturing_keywords.extract_keywords(words)
    kp_advanced_manufacturing_keywords = np.unique(kp_advanced_manufacturing_keywords)
    kp_advanced_manufacturing_keywords = list(kp_advanced_manufacturing_keywords)
    
    kp_agtech_keywords = KeywordProcessor()
    for i in agtech_keywords:
        kp_agtech_keywords.add_keyword(i)
    kp_agtech_keywords = kp_agtech_keywords.extract_keywords(words)
    kp_agtech_keywords = np.unique(kp_agtech_keywords)
    kp_agtech_keywords = list(kp_agtech_keywords)
    
    kp_ai_ml_keywords = KeywordProcessor()
    for i in ai_ml_keywords:
        kp_ai_ml_keywords.add_keyword(i)
    kp_ai_ml_keywords = kp_ai_ml_keywords.extract_keywords(words)
    kp_ai_ml_keywords = np.unique(kp_ai_ml_keywords)
    kp_ai_ml_keywords = list(kp_ai_ml_keywords)
    
    kp_audiotech_keywords = KeywordProcessor()
    for i in audiotech_keywords:
        kp_audiotech_keywords.add_keyword(i)
    kp_audiotech_keywords = kp_audiotech_keywords.extract_keywords(words)
    kp_audiotech_keywords = np.unique(kp_audiotech_keywords)
    kp_audiotech_keywords = list(kp_audiotech_keywords)
    
    kp_ar_keywords = KeywordProcessor()
    for i in ar_keywords:
        kp_ar_keywords.add_keyword(i)
    kp_ar_keywords = kp_ar_keywords.extract_keywords(words)
    kp_ar_keywords = np.unique(kp_ar_keywords)
    kp_ar_keywords = list(kp_ar_keywords)
    
    kp_Autonomous_cars = KeywordProcessor()
    for i in Autonomous_cars:
        kp_Autonomous_cars.add_keyword(i)
    kp_Autonomous_cars = kp_Autonomous_cars.extract_keywords(words)
    kp_Autonomous_cars = np.unique(kp_Autonomous_cars)
    kp_Autonomous_cars = list(kp_Autonomous_cars)
    
    kp_B2B_payments = KeywordProcessor()
    for i in B2B_payments:
        kp_B2B_payments.add_keyword(i)
    kp_B2B_payments = kp_B2B_payments.extract_keywords(words)
    kp_B2B_payments = np.unique(kp_B2B_payments)
    kp_B2B_payments = list(kp_B2B_payments)
    
    kp_Beauty = KeywordProcessor()
    for i in Beauty:
        kp_Beauty.add_keyword(i)
    kp_Beauty = kp_Beauty.extract_keywords(words)
    kp_Beauty = np.unique(kp_Beauty)
    kp_Beauty = list(kp_Beauty)
    
    kp_Big_Data = KeywordProcessor()
    for i in Big_Data:
        kp_Big_Data.add_keyword(i)
    kp_Big_Data = kp_Big_Data.extract_keywords(words)
    kp_Big_Data = np.unique(kp_Big_Data)
    kp_Big_Data = list(kp_Big_Data)

    kp_Cannabis = KeywordProcessor()
    for i in Cannabis:
        kp_Cannabis.add_keyword(i)
    kp_Cannabis = kp_Cannabis.extract_keywords(words)
    kp_Cannabis = np.unique(kp_Cannabis)
    kp_Cannabis = list(kp_Cannabis)
    
    kp_Carsharing = KeywordProcessor()
    for i in Carsharing:
        kp_Carsharing.add_keyword(i)
    kp_Carsharing = kp_Carsharing.extract_keywords(words)
    kp_Carsharing = np.unique(kp_Carsharing)
    kp_Carsharing = list(kp_Carsharing)
    
    kp_Cleantech = KeywordProcessor()
    for i in Cleantech:
        kp_Cleantech.add_keyword(i)
    kp_Cleantech = kp_Cleantech.extract_keywords(words)
    kp_Cleantech = np.unique(kp_Cleantech)
    kp_Cleantech = list(kp_Cleantech)
    
    kp_Climate_tech = KeywordProcessor()
    for i in Climate_tech:
        kp_Climate_tech.add_keyword(i)
    kp_Climate_tech = kp_Climate_tech.extract_keywords(words)
    kp_Climate_tech = np.unique(kp_Climate_tech)
    kp_Climate_tech = list(kp_Climate_tech)
    
    kp_Cloudtech_DevOps = KeywordProcessor()
    for i in Cloudtech_DevOps:
        kp_Cloudtech_DevOps.add_keyword(i)
    kp_Cloudtech_DevOps = kp_Cloudtech_DevOps.extract_keywords(words)
    kp_Cloudtech_DevOps = np.unique(kp_Cloudtech_DevOps)
    kp_Cloudtech_DevOps = list(kp_Cloudtech_DevOps)
    
    kp_Construction_technology = KeywordProcessor()
    for i in Construction_technology:
        kp_Construction_technology.add_keyword(i)
    kp_Construction_technology = kp_Construction_technology.extract_keywords(words)
    kp_Construction_technology = np.unique(kp_Construction_technology)
    kp_Construction_technology = list(kp_Construction_technology)
    
    kp_Cryptocurrency_blockchain = KeywordProcessor()
    for i in Cryptocurrency_blockchain:
        kp_Cryptocurrency_blockchain.add_keyword(i)
    kp_Cryptocurrency_blockchain = kp_Cryptocurrency_blockchain.extract_keywords(words)
    kp_Cryptocurrency_blockchain = np.unique(kp_Cryptocurrency_blockchain)
    kp_Cryptocurrency_blockchain = list(kp_Cryptocurrency_blockchain)
    
    kp_Cybersecurity = KeywordProcessor()
    for i in Cybersecurity:
        kp_Cybersecurity.add_keyword(i)
    kp_Cybersecurity = kp_Cybersecurity.extract_keywords(words)
    kp_Cybersecurity = np.unique(kp_Cybersecurity)
    kp_Cybersecurity = list(kp_Cybersecurity)
    
    kp_Digital_health = KeywordProcessor()
    for i in Digital_health:
        kp_Digital_health.add_keyword(i)
    kp_Digital_health = kp_Digital_health.extract_keywords(words)
    kp_Digital_health = np.unique(kp_Digital_health)
    kp_Digital_health = list(kp_Digital_health)
    
    kp_Ecommerce = KeywordProcessor()
    for i in Ecommerce:
        kp_Ecommerce.add_keyword(i)
    kp_Ecommerce = kp_Ecommerce.extract_keywords(words)
    kp_Ecommerce = np.unique(kp_Ecommerce)
    kp_Ecommerce = list(kp_Ecommerce)
    
    kp_Edtech = KeywordProcessor()
    for i in Edtech:
        kp_Edtech.add_keyword(i)
    kp_Edtech = kp_Edtech.extract_keywords(words)
    kp_Edtech = np.unique(kp_Edtech)
    kp_Edtech = list(kp_Edtech)
    
    kp_Ephemeral_content = KeywordProcessor()
    for i in Ephemeral_content:
        kp_Ephemeral_content.add_keyword(i)
    kp_Ephemeral_content = kp_Ephemeral_content.extract_keywords(words)
    kp_Ephemeral_content = np.unique(kp_Ephemeral_content)
    kp_Ephemeral_content = list(kp_Ephemeral_content)
    
    kp_esports_keywords = KeywordProcessor()
    for i in esports_keywords:
        kp_esports_keywords.add_keyword(i)
    kp_esports_keywords = kp_esports_keywords.extract_keywords(words)
    kp_esports_keywords = np.unique(kp_esports_keywords)
    kp_esports_keywords = list(kp_esports_keywords)
    
    kp_Femtech_keywords = KeywordProcessor()
    for i in Femtech_keywords:
        kp_Femtech_keywords.add_keyword(i)
    kp_Femtech_keywords = kp_Femtech_keywords.extract_keywords(words)
    kp_Femtech_keywords = np.unique(kp_Femtech_keywords)
    kp_Femtech_keywords = list(kp_Femtech_keywords)
    
    kp_fintech_keywords = KeywordProcessor()
    for i in fintech_keywords:
        kp_fintech_keywords.add_keyword(i)
    kp_fintech_keywords = kp_fintech_keywords.extract_keywords(words)
    kp_fintech_keywords = np.unique(kp_fintech_keywords)
    kp_fintech_keywords = list(kp_fintech_keywords)
    
    kp_Foodtech = KeywordProcessor()
    for i in Foodtech:
        kp_Foodtech.add_keyword(i)
    kp_Foodtech = kp_Foodtech.extract_keywords(words)
    kp_Foodtech = np.unique(kp_Foodtech)
    kp_Foodtech = list(kp_Foodtech)
    
    kp_Gaming = KeywordProcessor()
    for i in Gaming:
        kp_Gaming.add_keyword(i)
    kp_Gaming = kp_Gaming.extract_keywords(words)
    kp_Gaming = np.unique(kp_Gaming)
    kp_Gaming = list(kp_Gaming)
    
    kp_Healthtech = KeywordProcessor()
    for i in Healthtech:
        kp_Healthtech.add_keyword(i)
    kp_Healthtech = kp_Healthtech.extract_keywords(words)
    kp_Healthtech = np.unique(kp_Healthtech)
    kp_Healthtech = list(kp_Healthtech)
    
    kp_HRtech = KeywordProcessor()
    for i in HRtech:
        kp_HRtech.add_keyword(i)
    kp_HRtech = kp_HRtech.extract_keywords(words)
    kp_HRtech = np.unique(kp_HRtech)
    kp_HRtech = list(kp_HRtech)
    
    kp_impact_investing_keywords = KeywordProcessor()
    for i in impact_investing_keywords:
        kp_impact_investing_keywords.add_keyword(i)
    kp_impact_investing_keywords = kp_impact_investing_keywords.extract_keywords(words)
    kp_impact_investing_keywords = np.unique(kp_impact_investing_keywords)
    kp_impact_investing_keywords = list(kp_impact_investing_keywords)
    
    kp_Industrials_keywords = KeywordProcessor()
    for i in Industrials_keywords:
        kp_Industrials_keywords.add_keyword(i)
    kp_Industrials_keywords = kp_Industrials_keywords.extract_keywords(words)
    kp_Industrials_keywords = np.unique(kp_Industrials_keywords)
    kp_Industrials_keywords = list(kp_Industrials_keywords)
    
    kp_Infrastructure = KeywordProcessor()
    for i in Infrastructure:
        kp_Infrastructure.add_keyword(i)
    kp_Infrastructure = kp_Infrastructure.extract_keywords(words)
    kp_Infrastructure = np.unique(kp_Infrastructure)
    kp_Infrastructure = list(kp_Infrastructure)
    
    kp_Insurtech = KeywordProcessor()
    for i in Insurtech:
        kp_Insurtech.add_keyword(i)
    kp_Insurtech = kp_Insurtech.extract_keywords(words)
    kp_Insurtech = np.unique(kp_Insurtech)
    kp_Insurtech = list(kp_Insurtech)
    
    kp_Internet_of_Things_keywords = KeywordProcessor()
    for i in Internet_of_Things_keywords:
        kp_Internet_of_Things_keywords.add_keyword(i)
    kp_Internet_of_Things_keywords = kp_Internet_of_Things_keywords.extract_keywords(words)
    kp_Internet_of_Things_keywords = np.unique(kp_Internet_of_Things_keywords)
    kp_Internet_of_Things_keywords = list(kp_Internet_of_Things_keywords)
    
    kp_Legal_tech = KeywordProcessor()
    for i in Legal_tech:
        kp_Legal_tech.add_keyword(i)
    kp_Legal_tech = kp_Legal_tech.extract_keywords(words)
    kp_Legal_tech = np.unique(kp_Legal_tech)
    kp_Legal_tech = list(kp_Legal_tech)
    
    kp_life_sciences_keywords = KeywordProcessor()
    for i in life_sciences_keywords:
        kp_life_sciences_keywords.add_keyword(i)
    kp_life_sciences_keywords = kp_life_sciences_keywords.extract_keywords(words)
    kp_life_sciences_keywords = np.unique(kp_life_sciences_keywords)
    kp_life_sciences_keywords = list(kp_life_sciences_keywords)
    
    kp_Lifestyles_of_Health_Sustainability_wellness = KeywordProcessor()
    for i in Lifestyles_of_Health_Sustainability_wellness:
        kp_Lifestyles_of_Health_Sustainability_wellness.add_keyword(i)
    kp_Lifestyles_of_Health_Sustainability_wellness = kp_Lifestyles_of_Health_Sustainability_wellness.extract_keywords(words)
    kp_Lifestyles_of_Health_Sustainability_wellness = np.unique(kp_Lifestyles_of_Health_Sustainability_wellness)
    kp_Lifestyles_of_Health_Sustainability_wellness = list(kp_Lifestyles_of_Health_Sustainability_wellness)
    
    kp_Manufacturing = KeywordProcessor()
    for i in Manufacturing:
        kp_Manufacturing.add_keyword(i)
    kp_Manufacturing = kp_Manufacturing.extract_keywords(words)
    kp_Manufacturing = np.unique(kp_Manufacturing)
    kp_Manufacturing = list(kp_Manufacturing)
    
    kp_Marketing_tech = KeywordProcessor()
    for i in Marketing_tech:
        kp_Marketing_tech.add_keyword(i)
    kp_Marketing_tech = kp_Marketing_tech.extract_keywords(words)
    kp_Marketing_tech = np.unique(kp_Marketing_tech)
    kp_Marketing_tech = list(kp_Marketing_tech)
    
    kp_Micro_mobility = KeywordProcessor()
    for i in Micro_mobility:
        kp_Micro_mobility.add_keyword(i)
    kp_Micro_mobility = kp_Micro_mobility.extract_keywords(words)
    kp_Micro_mobility = np.unique(kp_Micro_mobility)
    kp_Micro_mobility = list(kp_Micro_mobility)
    
    kp_Mobile = KeywordProcessor()
    for i in Mobile:
        kp_Mobile.add_keyword(i)
    kp_Mobile = kp_Mobile.extract_keywords(words)
    kp_Mobile = np.unique(kp_Mobile)
    kp_Mobile = list(kp_Mobile)
    
    kp_Mobile_commerce = KeywordProcessor()
    for i in Mobile_commerce:
        kp_Mobile_commerce.add_keyword(i)
    kp_Mobile_commerce = kp_Mobile_commerce.extract_keywords(words)
    kp_Mobile_commerce = np.unique(kp_Mobile_commerce)
    kp_Mobile_commerce = list(kp_Mobile_commerce)
    
    kp_Mobility_tech = KeywordProcessor()
    for i in Mobility_tech:
        kp_Mobility_tech.add_keyword(i)
    kp_Mobility_tech = kp_Mobility_tech.extract_keywords(words)
    kp_Mobility_tech = np.unique(kp_Mobility_tech)
    kp_Mobility_tech = list(kp_Mobility_tech)
    
    kp_Mortgage_tech = KeywordProcessor()
    for i in Mortgage_tech:
        kp_Mortgage_tech.add_keyword(i)
    kp_Mortgage_tech = kp_Mortgage_tech.extract_keywords(words)
    kp_Mortgage_tech = np.unique(kp_Mortgage_tech)
    kp_Mortgage_tech = list(kp_Mortgage_tech)
    
    kp_Nanotechnology = KeywordProcessor()
    for i in Nanotechnology:
        kp_Nanotechnology.add_keyword(i)
    kp_Nanotechnology = kp_Nanotechnology.extract_keywords(words)
    kp_Nanotechnology = np.unique(kp_Nanotechnology)
    kp_Nanotechnology = list(kp_Nanotechnology)
    
    kp_Oil_gas = KeywordProcessor()
    for i in Oil_gas:
        kp_Oil_gas.add_keyword(i)
    kp_Oil_gas = kp_Oil_gas.extract_keywords(words)
    kp_Oil_gas = np.unique(kp_Oil_gas)
    kp_Oil_gas = list(kp_Oil_gas)
    
    kp_Oncology = KeywordProcessor()
    for i in Oncology:
        kp_Oncology.add_keyword(i)
    kp_Oncology = kp_Oncology.extract_keywords(words)
    kp_Oncology = np.unique(kp_Oncology)
    kp_Oncology = list(kp_Oncology)
    
    kp_Pet_tech = KeywordProcessor()
    for i in Pet_tech:
        kp_Pet_tech.add_keyword(i)
    kp_Pet_tech = kp_Pet_tech.extract_keywords(words)
    kp_Pet_tech = np.unique(kp_Pet_tech)
    kp_Pet_tech = list(kp_Pet_tech)
    
    kp_Ridesharing = KeywordProcessor()
    for i in Ridesharing:
        kp_Ridesharing.add_keyword(i)
    kp_Ridesharing = kp_Ridesharing.extract_keywords(words)
    kp_Ridesharing = np.unique(kp_Ridesharing)
    kp_Ridesharing = list(kp_Ridesharing)
    
    kp_Robotics_drones = KeywordProcessor()
    for i in Robotics_drones:
        kp_Robotics_drones.add_keyword(i)
    kp_Robotics_drones = kp_Robotics_drones.extract_keywords(words)
    kp_Robotics_drones = np.unique(kp_Robotics_drones)
    kp_Robotics_drones = list(kp_Robotics_drones)
    
    kp_SaaS = KeywordProcessor()
    for i in SaaS:
        kp_SaaS.add_keyword(i)
    kp_SaaS = kp_SaaS.extract_keywords(words)
    kp_SaaS = np.unique(kp_SaaS)
    kp_SaaS = list(kp_SaaS)
    
    kp_Space_tech = KeywordProcessor()
    for i in Space_tech:
        kp_Space_tech.add_keyword(i)
    kp_Space_tech = kp_Space_tech.extract_keywords(words)
    kp_Space_tech = np.unique(kp_Space_tech)
    kp_Space_tech = list(kp_Space_tech)
    
    kp_Supply_chain_technology = KeywordProcessor()
    for i in Supply_chain_technology:
        kp_Supply_chain_technology.add_keyword(i)
    kp_Supply_chain_technology = kp_Supply_chain_technology.extract_keywords(words)
    kp_Supply_chain_technology = np.unique(kp_Supply_chain_technology)
    kp_Supply_chain_technology = list(kp_Supply_chain_technology)
    
    kp_Virtual_reality = KeywordProcessor()
    for i in Virtual_reality:
        kp_Virtual_reality.add_keyword(i)
    kp_Virtual_reality = kp_Virtual_reality.extract_keywords(words)
    kp_Virtual_reality = np.unique(kp_Virtual_reality)
    kp_Virtual_reality = list(kp_Virtual_reality)
    
    kp_Wearables_quantified_self = KeywordProcessor()
    for i in Wearables_quantified_self:
        kp_Wearables_quantified_self.add_keyword(i)
    kp_Wearables_quantified_self = kp_Wearables_quantified_self.extract_keywords(words)
    kp_Wearables_quantified_self = np.unique(kp_Wearables_quantified_self)
    kp_Wearables_quantified_self = list(kp_Wearables_quantified_self)
    
    kp_printing_3D = KeywordProcessor()
    for i in printing_3D:
        kp_printing_3D.add_keyword(i)
    kp_printing_3D = kp_printing_3D.extract_keywords(words)
    kp_printing_3D = np.unique(kp_printing_3D)
    kp_printing_3D = list(kp_printing_3D)
    
    kp_Accounting_Auditing = KeywordProcessor()
    for i in Accounting_Auditing:
        kp_Accounting_Auditing.add_keyword(i)
    kp_Accounting_Auditing = kp_Accounting_Auditing.extract_keywords(words)
    kp_Accounting_Auditing = np.unique(kp_Accounting_Auditing)
    kp_Accounting_Auditing = list(kp_Accounting_Auditing)
    
    kp_Agriculture = KeywordProcessor()
    for i in Agriculture:
        kp_Agriculture.add_keyword(i)
    kp_Agriculture = kp_Agriculture.extract_keywords(words)
    kp_Agriculture = np.unique(kp_Agriculture)
    kp_Agriculture = list(kp_Agriculture)
    
    kp_Airlines = KeywordProcessor()
    for i in Airlines:
        kp_Airlines.add_keyword(i)
    kp_Airlines = kp_Airlines.extract_keywords(words)
    kp_Airlines = np.unique(kp_Airlines)
    kp_Airlines = list(kp_Airlines)
    
    kp_Amusement_Recreation = KeywordProcessor()
    for i in Amusement_Recreation:
        kp_Amusement_Recreation.add_keyword(i)
    kp_Amusement_Recreation = kp_Amusement_Recreation.extract_keywords(words)
    kp_Amusement_Recreation = np.unique(kp_Amusement_Recreation)
    kp_Amusement_Recreation = list(kp_Amusement_Recreation)
    
    kp_Banking = KeywordProcessor()
    for i in Banking:
        kp_Banking.add_keyword(i)
    kp_Banking = kp_Banking.extract_keywords(words)
    kp_Banking = np.unique(kp_Banking)
    kp_Banking = list(kp_Banking)
    
    kp_Business_Services = KeywordProcessor()
    for i in Business_Services:
        kp_Business_Services.add_keyword(i)
    kp_Business_Services = kp_Business_Services.extract_keywords(words)
    kp_Business_Services = np.unique(kp_Business_Services)
    kp_Business_Services = list(kp_Business_Services)
    
    kp_Chemical_Industry = KeywordProcessor()
    for i in Chemical_Industry:
        kp_Chemical_Industry.add_keyword(i)
    kp_Chemical_Industry = kp_Chemical_Industry.extract_keywords(words)
    kp_Chemical_Industry = np.unique(kp_Chemical_Industry)
    kp_Chemical_Industry = list(kp_Chemical_Industry)
    
    kp_Construction = KeywordProcessor()
    for i in Construction:
        kp_Construction.add_keyword(i)
    kp_Construction = kp_Construction.extract_keywords(words)
    kp_Construction = np.unique(kp_Construction)
    kp_Construction = list(kp_Construction)
    
    kp_Consumer_Discretionary = KeywordProcessor()
    for i in Consumer_Discretionary:
        kp_Consumer_Discretionary.add_keyword(i)
    kp_Consumer_Discretionary = kp_Consumer_Discretionary.extract_keywords(words)
    kp_Consumer_Discretionary = np.unique(kp_Consumer_Discretionary)
    kp_Consumer_Discretionary = list(kp_Consumer_Discretionary)
    
    kp_Consumer_Services = KeywordProcessor()
    for i in Consumer_Services:
        kp_Consumer_Services.add_keyword(i)
    kp_Consumer_Services = kp_Consumer_Services.extract_keywords(words)
    kp_Consumer_Services = np.unique(kp_Consumer_Services)
    kp_Consumer_Services = list(kp_Consumer_Services)
    
    kp_Consumer_Staples = KeywordProcessor()
    for i in Consumer_Staples:
        kp_Consumer_Staples.add_keyword(i)
    kp_Consumer_Staples = kp_Consumer_Staples.extract_keywords(words)
    kp_Consumer_Staples = np.unique(kp_Consumer_Staples)
    kp_Consumer_Staples = list(kp_Consumer_Staples)
    
    kp_Energy = KeywordProcessor()
    for i in Energy:
        kp_Energy.add_keyword(i)
    kp_Energy = kp_Energy.extract_keywords(words)
    kp_Energy = np.unique(kp_Energy)
    kp_Energy = list(kp_Energy)
    
    kp_Engineering = KeywordProcessor()
    for i in Engineering:
        kp_Engineering.add_keyword(i)
    kp_Engineering = kp_Engineering.extract_keywords(words)
    kp_Engineering = np.unique(kp_Engineering)
    kp_Engineering = list(kp_Engineering)
    
    kp_Environment = KeywordProcessor()
    for i in Environment:
        kp_Environment.add_keyword(i)
    kp_Environment = kp_Environment.extract_keywords(words)
    kp_Environment = np.unique(kp_Environment)
    kp_Environment = list(kp_Environment)
    
    kp_Fashion = KeywordProcessor()
    for i in Fashion:
        kp_Fashion.add_keyword(i)
    kp_Fashion = kp_Fashion.extract_keywords(words)
    kp_Fashion = np.unique(kp_Fashion)
    kp_Fashion = list(kp_Fashion)
    
    kp_Heavy_Industry = KeywordProcessor()
    for i in Heavy_Industry:
        kp_Heavy_Industry.add_keyword(i)
    kp_Heavy_Industry = kp_Heavy_Industry.extract_keywords(words)
    kp_Heavy_Industry = np.unique(kp_Heavy_Industry)
    kp_Heavy_Industry = list(kp_Heavy_Industry)
    
    kp_Hotels = KeywordProcessor()
    for i in Hotels:
        kp_Hotels.add_keyword(i)
    kp_Hotels = kp_Hotels.extract_keywords(words)
    kp_Hotels = np.unique(kp_Hotels)
    kp_Hotels = list(kp_Hotels)
    
    kp_Information_Technology = KeywordProcessor()
    for i in Information_Technology:
        kp_Information_Technology.add_keyword(i)
    kp_Information_Technology = kp_Information_Technology.extract_keywords(words)
    kp_Information_Technology = np.unique(kp_Information_Technology)
    kp_Information_Technology = list(kp_Information_Technology)
    
    kp_Law = KeywordProcessor()
    for i in Law:
        kp_Law.add_keyword(i)
    kp_Law = kp_Law.extract_keywords(words)
    kp_Law = np.unique(kp_Law)
    kp_Law = list(kp_Law)
    
    kp_Logistics = KeywordProcessor()
    for i in Logistics:
        kp_Logistics.add_keyword(i)
    kp_Logistics = kp_Logistics.extract_keywords(words)
    kp_Logistics = np.unique(kp_Logistics)
    kp_Logistics = list(kp_Logistics)
    
    kp_Media = KeywordProcessor()
    for i in Media:
        kp_Media.add_keyword(i)
    kp_Media = kp_Media.extract_keywords(words)
    kp_Media = np.unique(kp_Media)
    kp_Media = list(kp_Media)
    
    kp_Mining = KeywordProcessor()
    for i in Mining:
        kp_Mining.add_keyword(i)
    kp_Mining = kp_Mining.extract_keywords(words)
    kp_Mining = np.unique(kp_Mining)
    kp_Mining = list(kp_Mining)
    
    kp_Non_profits = KeywordProcessor()
    for i in Non_profits:
        kp_Non_profits.add_keyword(i)
    kp_Non_profits = kp_Non_profits.extract_keywords(words)
    kp_Non_profits = np.unique(kp_Non_profits)
    kp_Non_profits = list(kp_Non_profits)
    
    kp_Professional_Services = KeywordProcessor()
    for i in Professional_Services:
        kp_Professional_Services.add_keyword(i)
    kp_Professional_Services = kp_Professional_Services.extract_keywords(words)
    kp_Professional_Services = np.unique(kp_Professional_Services)
    kp_Professional_Services = list(kp_Professional_Services)
    
    kp_Publishing = KeywordProcessor()
    for i in Publishing:
        kp_Publishing.add_keyword(i)
    kp_Publishing = kp_Publishing.extract_keywords(words)
    kp_Publishing = np.unique(kp_Publishing)
    kp_Publishing = list(kp_Publishing)
    
    kp_Retail = KeywordProcessor()
    for i in Retail:
        kp_Retail.add_keyword(i)
    kp_Retail = kp_Retail.extract_keywords(words)
    kp_Retail = np.unique(kp_Retail)
    kp_Retail = list(kp_Retail)
    
    kp_Science_Technology = KeywordProcessor()
    for i in Science_Technology:
        kp_Science_Technology.add_keyword(i)
    kp_Science_Technology = kp_Science_Technology.extract_keywords(words)
    kp_Science_Technology = np.unique(kp_Science_Technology)
    kp_Science_Technology = list(kp_Science_Technology)
    
    kp_Telecom = KeywordProcessor()
    for i in Telecom:
        kp_Telecom.add_keyword(i)
    kp_Telecom = kp_Telecom.extract_keywords(words)
    kp_Telecom = np.unique(kp_Telecom)
    kp_Telecom = list(kp_Telecom)
    
    kp_tourism_keywords = KeywordProcessor()
    for i in tourism_keywords:
        kp_tourism_keywords.add_keyword(i)
    kp_tourism_keywords = kp_tourism_keywords.extract_keywords(words)
    kp_tourism_keywords = np.unique(kp_tourism_keywords)
    kp_tourism_keywords = list(kp_tourism_keywords)
    
    kp_Transportation = KeywordProcessor()
    for i in Transportation:
        kp_Transportation.add_keyword(i)
    kp_Transportation = kp_Transportation.extract_keywords(words)
    kp_Transportation = np.unique(kp_Transportation)
    kp_Transportation = list(kp_Transportation)
    
    kp_Utilities = KeywordProcessor()
    for i in Utilities:
        kp_Utilities.add_keyword(i)
    kp_Utilities = kp_Utilities.extract_keywords(words)
    kp_Utilities = np.unique(kp_Utilities)
    kp_Utilities = list(kp_Utilities)
    
    
    def findmaxlength(lst):
        maxlist = max(lst, key=len)
        return maxlist
    
    category_list = [kp_sports,kp_entertainment,kp_health_care,kp_restaurant,kp_m_learning,kp_real_estate,kp_finance,kp_fitness,kp_travel,kp_business,kp_government,kp_politics,kp_adtech_keywords,kp_advanced_manufacturing_keywords,kp_agtech_keywords,kp_ai_ml_keywords,kp_audiotech_keywords,kp_ar_keywords,kp_Autonomous_cars,kp_B2B_payments,kp_Beauty, kp_Big_Data,kp_Cannabis,kp_Carsharing, kp_Cleantech, kp_Cloudtech_DevOps, kp_Construction_technology, kp_Cryptocurrency_blockchain, kp_Cybersecurity, kp_Digital_health,	kp_Ecommerce, kp_Edtech,kp_Ephemeral_content,kp_esports_keywords,kp_Femtech_keywords, kp_fintech_keywords,kp_Foodtech, kp_Gaming, kp_Healthtech, kp_HRtech, kp_impact_investing_keywords,kp_Industrials_keywords, kp_Infrastructure, kp_Insurtech,kp_Internet_of_Things_keywords, kp_Legal_tech, kp_life_sciences_keywords, kp_Lifestyles_of_Health_Sustainability_wellness,kp_Manufacturing, kp_Marketing_tech, kp_Micro_mobility, kp_Mobile, kp_Mobile_commerce, kp_Mobility_tech, kp_Mortgage_tech,	kp_Nanotechnology, kp_Oil_gas, kp_Oncology, kp_Pet_tech,  kp_Ridesharing, kp_Robotics_drones,  kp_SaaS,	kp_Space_tech, kp_Supply_chain_technology,  kp_Virtual_reality, kp_Wearables_quantified_self, kp_printing_3D, kp_Accounting_Auditing, kp_Agriculture, kp_Airlines, kp_Amusement_Recreation, kp_Banking, kp_Business_Services, kp_Chemical_Industry,kp_Construction,kp_Consumer_Discretionary,kp_Consumer_Services,kp_Consumer_Staples,kp_Energy,kp_Engineering,kp_Environment,kp_Fashion,kp_Heavy_Industry, kp_Hotels,kp_Information_Technology,kp_Law, kp_Logistics,kp_Media,kp_Mining,kp_Non_profits,kp_Professional_Services,kp_Publishing,kp_Retail,kp_Science_Technology, kp_Telecom,kp_tourism_keywords,kp_Transportation,kp_Utilities]
    max_category_list = findmaxlength(category_list)
    
    lst.append(max_category_list)
    print(max_category_list)
    
    if max_category_list == kp_sports:
        category = 'sports'
    elif max_category_list == kp_entertainment:
        category = 'entertainment'
    elif max_category_list == kp_health_care:
        category = 'health care'
    elif max_category_list == kp_restaurant:
        category = 'restaurant'
    elif max_category_list == kp_m_learning:
        category = 'm learning'
    elif max_category_list == kp_real_estate:
        category = 'real_estate'
    elif max_category_list == kp_finance:
        category = 'finance'
    elif max_category_list == kp_fitness:
        category = 'fitness'
    elif max_category_list == kp_travel:
        category = 'travel'
    elif max_category_list == kp_business:
        category = 'business'
    elif max_category_list == kp_government:
        category = 'government'
    elif max_category_list == kp_politics:
        category = 'politics'
        
    
    elif max_category_list == kp_adtech_keywords:
        category = 'Adtech'   
    elif max_category_list == kp_advanced_manufacturing_keywords:
        category = 'Advanced manufacturing keywords'   
    elif max_category_list == kp_agtech_keywords:
        category = 'Agtech'   
    elif max_category_list == kp_ai_ml_keywords:
        category = 'AI/ML'   
    elif max_category_list == kp_audiotech_keywords:
        category = 'Audiotech'   
    elif max_category_list == kp_ar_keywords:
        category = 'AR'
    elif max_category_list == kp_Autonomous_cars:
        category = 'Autonomous cars'   
    elif max_category_list == kp_B2B_payments:
        category = 'B2B payments'   
    
    elif max_category_list == kp_Beauty:
        category = 'Beauty'   
    elif max_category_list == kp_Big_Data:
        category = 'Big Data'   
    elif max_category_list == kp_Cannabis:
        category = 'Cannabis'   
    elif max_category_list == kp_Carsharing:
        category = 'Carsharing'   
    elif max_category_list == kp_Cleantech:
        category = 'Cleantech'   
    elif max_category_list == kp_Cloudtech_DevOps:
        category = 'Cloudtech DevOps'   
    elif max_category_list == kp_Construction_technology:
        category = 'Construction technology'   
    elif max_category_list == kp_Cryptocurrency_blockchain:
        category = 'Cryptocurrency blockchain'   
    elif max_category_list == kp_Cybersecurity:
        category = 'Cybersecurity'   
    elif max_category_list == kp_Digital_health:
        category = 'Digital health'   
    
    elif max_category_list == kp_Ecommerce:
        category = 'Ecommerce'   
    elif max_category_list == kp_Edtech:
        category = 'Edtech'   
    elif max_category_list == kp_Ephemeral_content:
        category = 'Ephemeral content'   
    elif max_category_list == kp_esports_keywords:
        category = 'eSports'   
    elif max_category_list == kp_Femtech_keywords:
        category = 'Femtech'   
    elif max_category_list == kp_fintech_keywords:
        category = 'fintech'   
    elif max_category_list == kp_Foodtech:
        category = 'Foodtech'   
    elif max_category_list == kp_Gaming:
        category = 'Gaming'   
    elif max_category_list == kp_Healthtech:
        category = 'Healthtech'   
    elif max_category_list == kp_HRtech:
        category = 'HRtech'   
    
    elif max_category_list == kp_impact_investing_keywords:
        category = 'impact investing'   
    elif max_category_list == kp_Industrials_keywords:
        category = 'Industrials'   
    elif max_category_list == kp_Infrastructure:
        category = 'Infrastructure'   
    elif max_category_list == kp_Insurtech:
        category = 'Insurtech'   
    elif max_category_list == kp_Internet_of_Things_keywords:
        category = 'IOT'   
    elif max_category_list == kp_Legal_tech:
        category = 'Legal tech'   
    elif max_category_list == kp_life_sciences_keywords:
        category = 'life sciences'   
    elif max_category_list == kp_Lifestyles_of_Health_Sustainability_wellness:
        category = 'Lifestyles of Health and Sustainability wellness'   
    elif max_category_list == kp_Manufacturing:
        category = 'Manufacturing'   
    elif max_category_list == kp_Marketing_tech:
        category = 'Marketing tech'   
    
    elif max_category_list == kp_Micro_mobility:
        category = 'Micro mobility'   
    elif max_category_list == kp_Mobile:
        category = 'Mobile'   
    elif max_category_list == kp_Mobile_commerce:
        category = 'Mobile commerce'   
    elif max_category_list == kp_Mobility_tech:
        category = 'Mobility tech'   
    elif max_category_list == kp_Mortgage_tech:
        category = 'Mortgage tech'   
    elif max_category_list == kp_Nanotechnology:
        category = 'Nanotechnology'   
    elif max_category_list == kp_Oil_gas:
        category = 'Oil gas'   
    elif max_category_list == kp_Oncology:
        category = 'Oncology'   
    elif max_category_list == kp_Pet_tech:
        category = 'Pet tech'   
    elif max_category_list == kp_Ridesharing:
        category = 'Ridesharing'   
    
    elif max_category_list == kp_Robotics_drones:
        category = 'Robotics drones'   
    elif max_category_list == kp_SaaS:
        category = 'SaaS'   
    elif max_category_list == kp_Space_tech:
        category = 'Space tech'   
    elif max_category_list == kp_Supply_chain_technology:
        category = 'Supply chain technology'   
    elif max_category_list == kp_Virtual_reality:
        category = 'Virtual reality'   
    elif max_category_list == kp_Wearables_quantified_self:
        category = 'Wearables quantified self'   
    elif max_category_list == kp_printing_3D:
        category = '3D printing'   
    elif max_category_list == kp_Accounting_Auditing:
        category = 'Accounting and Auditing'   
    elif max_category_list == kp_Agriculture:
        category = 'Agriculture'   
    elif max_category_list == kp_Airlines:
        category = 'Airlines'   
    
    elif max_category_list == kp_Amusement_Recreation:
        category = 'Amusement Recreation'   
    elif max_category_list == kp_Banking:
        category = 'kp Banking'   
    elif max_category_list == kp_Business_Services:
        category = 'Business Services'   
    elif max_category_list == kp_Chemical_Industry:
        category = 'Chemical Industry'   
    elif max_category_list == kp_Construction:
        category = 'Construction'   
    elif max_category_list == kp_Consumer_Discretionary:
        category = 'Consumer Discretionary'   
    elif max_category_list == kp_Consumer_Services:
        category = 'Consumer Services'   
    elif max_category_list == kp_Consumer_Staples:
        category = 'Consumer Staples'   
    elif max_category_list == kp_Energy:
        category = 'Energy'   
    elif max_category_list == kp_Engineering:
        category = 'Engineering'   
    
    elif max_category_list == kp_Environment:
        category = 'Environment'   
    elif max_category_list == kp_Fashion:
        category = 'Fashion'   
    elif max_category_list == kp_Heavy_Industry:
        category = 'Heavy Industry'   
    elif max_category_list == kp_Hotels:
        category = 'Hotels'   
    elif max_category_list == kp_Information_Technology:
        category = 'Information Technology'   
    elif max_category_list == kp_Law:
        category = 'Law '   
    elif max_category_list == kp_Logistics:
        category = 'Logistics'   
    elif max_category_list == kp_Media:
        category = 'Media'   
    elif max_category_list == kp_Mining:
        category = 'Mining'   
    elif max_category_list == kp_Non_profits:
        category = 'Non profits'   
    
    elif max_category_list == kp_Professional_Services:
        category = 'Professional Services'   
    elif max_category_list == kp_Publishing:
        category = 'Publishing'   
    elif max_category_list == kp_Retail:
        category = 'Retail'   
    elif max_category_list == kp_Science_Technology:
        category = 'Science and Technology'   
    elif max_category_list == kp_Telecom:
        category = 'Telecom'   
    elif max_category_list == kp_tourism_keywords:
        category = 'tourism'   
    elif max_category_list == kp_Transportation:
        category = 'Transportation'   
    elif max_category_list == kp_Utilities:
        category = 'Utilities'   
    
    
    
    lst.append(category)
    list_of_lists.append(lst)
    
    #print(list_of_lists)
    print()
    print("The category of ",url,"is ",category)
#url = input()
#url_predictor(url)

