import re
import smtplib
import dns.resolver

def validate(emailaddress):
    try:
        regex = '^[a-z0-9]+[\._]?[a-z0-9]+[@]\w+[.]\w{2,3}$'

        # emailaddress = input("Please enter the emailAddress to verify:").strip()

        # if not (re.search(regex, emailaddress)):
        #     print("--")
        #     return False

        splitAddress = emailaddress.split('@')
        domain = str(splitAddress[1])
        # print('Domain:', domain)

        records = dns.resolver.resolve(domain, 'MX')
        mxRecord = records[0].exchange
        mxRecord = str(mxRecord)

        # server = smtplib.SMTP()
        server = smtplib.SMTP('smtp.gmail.com:587')
        server.set_debuglevel(1)
        server.starttls()
        password = "hoavxpuvdmeduiuk"
        username = "isanursardar@gmail.com"
        server.login(username,password)

        fromAddress = username

        server.connect(mxRecord)
        server.helo(server.local_hostname)
        server.mail(fromAddress)
        code, message = server.rcpt(str(emailaddress))
        server.quit()
        print("email validator :", emailaddress)
        print("email validator :", code)
        if code == 250:
            return True
        else:
            return False
    except Exception as e:
        print(e)
        print("Invalid email-->",emailaddress)
        return False

if __name__ == '__main__':
    validate('iam@isanur.me')