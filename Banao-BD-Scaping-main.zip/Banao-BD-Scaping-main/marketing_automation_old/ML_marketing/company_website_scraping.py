import website_scraping
import api_update
import requests
import json

if __name__ == "__main__":
    SERVER_IP = api_update.SERVER_IP
    websites = website_data_api=f"http://{SERVER_IP}/api/comapany-website?count=5"
    r = requests.get(website_data_api)
    sites=json.loads(r.text)
    print(len(sites))

    for site in sites:
        url = site['website'].strip()
        id = site['id']
        try:
            data = website_scraping.scrape_main(url, id)
            api_update.post_company_website_data(data)
        except Exception as e:
            print(e)
            data = {'id':id, 'crawl_status':2}
            api_update.post_company_website_data(data)