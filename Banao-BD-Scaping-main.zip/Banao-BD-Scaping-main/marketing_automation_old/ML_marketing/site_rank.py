import time
from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service as ChromeService
from webdriver_manager.chrome import ChromeDriverManager
import json
import pprint
import api_update
import page_speed




prefs = {"profile.default_content_setting_values.notifications": 2}
option=webdriver.ChromeOptions()
option.add_experimental_option("excludeSwitches", ["ignore-certificate-errors"])
option.add_argument('headless')
option.add_argument('--no-sandbox')
option.add_experimental_option("prefs", prefs)
#option.add_argument("--start-maximized")
option.add_argument("--window-size=1920x1080")
option.add_argument("--disable-extensions")
option.add_argument("--disable-gpu")
option.add_argument("--disable-dev-shm-usage")
option.add_argument("disable-infobars")



def process_site(domain, driver):
    driver.set_page_load_timeout(100)
    try:
        update_button = driver.find_element(By.ID,"updateButton")
        update_button.click()
        time.sleep(100)
    except:
        return -1
    return get_rank(domain,1)

def get_rank(domain,x=0):
    driver = webdriver.Chrome(ChromeDriverManager().install(), options=option)
    driver.set_page_load_timeout(10)
    base_url = "https://"+ domain + ".cutestat.com"
    try:
        driver.get(base_url)
    except Exception as e:
        print("Timeout", e)
        pass
    time.sleep(10)
    time_el = driver.find_element(By.XPATH, "/html/body/div/div/div/div[2]/div/div/div/div[1]/div/div[3]/div[1]/div[2]/div[2]/small/time")
    time_text = time_el.text.lower()
    print(time_text)
    if 'month' in time_text or 'year' in time_text:
        rank = process_site(domain, driver)

    else:
        rank_p = driver.find_element(By.XPATH, "/html/body/div/div/div/div[2]/div/div/div/div[1]/div/div[3]/div[1]/div[2]/p")
        rank_p_text = rank_p.text.split('#')[1].split(" ")[0].replace(',', '')
        rank = float(rank_p_text)
        print(rank)
    driver.quit()
    return rank

if __name__ == '__main__':
    get_rank("banao.tech", 0)

