import website_scraping
import api_update
import requests
import json
import time
from log_generator import generate_log


print("Version:23.7.6 \nGreetings from Banao Technologies!\n"
"Please enter your Banao Token in the designated fields and relax while our program extracts the "
"necessary data for you. We respect your privacy and want to assure you that any data entered by you will be not stored in any way."
"Please note that this program is designed solely for the purpose of aiding Banao Technologies, and we strongly advise against using it for any other purpose.\n\n"
"NOTE : This script will take 6 hours to complete.")

token = input("Token > ")
start = time.time()
BASE_URL = "https://bbd.atg.party"

def do_log(*message):
    output_data = ''
    for i in message:
        output_data += f"{i} "
    print(output_data)
    generate_log(output_data)

def get_run_id(token):
    res = requests.post(f"{BASE_URL}/api/create-entry-of-userstats", json={'token':token, 'extension':'website_scraping_exe'})
    if res.status_code != 200:
        return None , res.text
    return res.json()['id'] , None

run_id, err =  get_run_id(token)
if err:
    do_log("Wrong Token \n")
    input("Press enter to close and try again")
    exit()


def main():
    SERVER_IP = api_update.SERVER_IP
    websites = website_data_api=f"http://{SERVER_IP}/api/comapany-website?count=5"
    r = requests.get(website_data_api)
    sites=json.loads(r.text)
    do_log(len(sites))
    if len(sites) == 0:
        do_log('sleeping for 2 minutes')
        time.sleep(120)

    for site in sites:
        url = site['website'].strip()
        id = site['id']
        try:
            data = website_scraping.scrape_main(url, id)
            api_update.post_company_website_data(data)
        except Exception as e:
            do_log(e)
            data = {'id':id, 'crawl_status':2}
            api_update.post_company_website_data(data)

def get_run_id(token):
    global run_id
    run_id = 0
    
def do_kill():
    run_time = time.time() - start
    do_log("Runtime: ",run_time)
    if run_time > 6*60*60:
        do_log("Run COmpleted you can close now.")
        return True
    return False

def increase_run_count(run_id):
    x = requests.post(f"{BASE_URL}/api/increment-run-count", json={'id':run_id}, headers={"auth":token})
    do_log(x.text)

if __name__ == "__main__":
    fail_count = 0
    do_log(run_id)
    while True:
        try:
            main()
            fail_count = 0
            increase_run_count(run_id)
        except Exception as e:
            do_log(f"Error on main function: ",e)
            fail_count += 1
            if fail_count > 5:
                do_log("Check your network connection or contact support")
                break
            
        if do_kill():
            break