import requests
import time
from bs4 import BeautifulSoup
from csv import writer
import re
import time
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from bs4 import BeautifulSoup
from csv import writer
import re
import api_update

prefs = {"profile.default_content_setting_values.notifications": 2}
option = webdriver.ChromeOptions()
option.add_experimental_option("excludeSwitches", ["ignore-certificate-errors"])
option.add_argument('headless')
option.add_argument('--no-sandbox')
option.add_experimental_option("prefs", prefs)
# option.add_argument("--start-maximized")
option.add_argument("--window-size=1920x1080")
option.add_argument("--disable-extensions")
option.add_argument("--disable-gpu")
option.add_argument("--disable-dev-shm-usage")
option.add_argument("disable-infobars")

driver = webdriver.Chrome(ChromeDriverManager().install(), options=option)

def get_urls(page):
    driver.get(f"https://yourstory.com/companies/search?page={page}")
    time.sleep(5)

    table = driver.find_element(by=By.XPATH, value = '//*[@id="root"]/main/div/main/section/div[1]/div[1]/table')

    trs = table.find_elements(By.TAG_NAME, 'tr')
    print(len(trs))
    OWN_TEXT_SCRIPT = "if(arguments[0].hasChildNodes()){var r='';var C=arguments[0].childNodes;for(var n=0;n<C.length;n++){if(C[n].nodeType==Node.TEXT_NODE){r+=' '+C[n].nodeValue}}return r.trim()}else{return arguments[0].innerText}"

    main_list = []

    for tr in trs:
        links = tr.find_elements(By.TAG_NAME, 'a')
        if len(links)>1:
            name_el = links[1]
            name = name_el.find_element(By.TAG_NAME, 'div').get_attribute('textContent')
            url = name_el.get_attribute('href')

            sector_el = links[2]
            sector = sector_el.find_element(By.TAG_NAME, 'div').get_attribute('textContent')

            headquarters_el = links[3]
            headquarters = headquarters_el.find_element(By.TAG_NAME, 'div').get_attribute('textContent')

            funding_el = links[4]
            funding = funding_el.find_element(By.TAG_NAME, 'div').get_attribute('textContent')

            emp_count_el = links[5]
            emp_count = emp_count_el.find_element(By.TAG_NAME, 'div').get_attribute('textContent')

            data = {
                'name':name,
                'url':url,
                'sector':sector,
                'headquarter': headquarters,
                'funding': funding,
                'emp_count': emp_count
            }
            print(data)
            main_list.append(data)
    return main_list

def process_details(data, links):
    print(data)
    res = {}
    #Legal Name
    try:
        legal_name_index = data.index("Legal Name")
        legal_name = data[legal_name_index+2]
    except:
        legal_name = None
    res['legal_name'] = legal_name

    #Headquarters
    try:
        headquarters_index = data.index("Headquarters")
        headquarters = data[headquarters_index+2]
    except:
        headquarters = None
    res['headquarters'] = headquarters

    #Business Model
    try:
        business_model_index = data.index("Business Model")
        business_model = data[business_model_index + 2]
    except:
        business_model = None
    res['business_model'] = business_model

    #Funding Date
    try:
        founding_date_index = data.index("Founding Date")
        founding_date = data[founding_date_index+2]
    except:
        founding_date = None
    res['founding_date'] = founding_date

    #Core Team
    employees = []
    try:
        core_team_index = data.index("Core Team")
        core_team = data[core_team_index+2:]
        print(core_team)
        employees =[]
        j = 0
        k = 0
        l =3
        number_of_emp = len(core_team)/3
        print('1'*10)
        if number_of_emp != int(len(core_team)/3):
            print("number didn't matched")
            number_of_emp = len(core_team)/2
            l =2
        number_of_emp = int(number_of_emp)
        for i in range(number_of_emp):
            linkedin_profile = None
            name = core_team[j+1]
            if l !=2:
                position = core_team[j+2]
            else:
                position = None
            j = j + l
            first_name = name.split(" ")[0]
            for linkedin_link in links:
                if first_name.lower() in linkedin_link:
                    linkedin_profile = linkedin_link
                    break
            employees.append({'name':name,'position':position, 'linkedin':linkedin_profile})
    except Exception as e:
        print(e)
        pass
    res['team'] = employees
        

    return res

def process_target_market(data):
    res = {}
    

def get_details(url):
    other_company_url = []
    company_details = {}


    driver.get(url)
    time.sleep(5)
    company_name_el = driver.find_element(by=By.XPATH, value ='//*[@id="root"]/main/div/div/div/div[1]/div[1]/div[1]/div[2]/div[1]')
    company_name = company_name_el.text
    company_details['name'] = company_name
    print("Company Name--> ",company_name)

    req = requests.get(url)
    soup = BeautifulSoup(req.text, 'html.parser')
    basic_info = soup.find(attrs={'class':'sc-lgfUwS gAQxLe'}).text
    company_details['description'] = basic_info
    print("\nBasic info-->",basic_info)

    company_lnk_el = driver.find_element(by=By.XPATH, value ='//*[@id="root"]/main/div/div/div/div[1]/div[1]/div[1]/div[2]/div[1]/a')
    company_lnk = company_lnk_el.get_attribute("href")
    company_details['website'] = company_lnk
    print("\nCompany Link-->",company_lnk)

    details = driver.find_element(by=By.XPATH, value ="/html/body/div[1]/main/div/div/div/div[1]/div[1]/div[4]/div[2]/div[3]")
    details = details.text.split('\n')
    team_a = []
    b = driver.find_element(by=By.XPATH, value ='//*[@id="root"]/main/div/div/div/div[1]/div[1]/div[4]/div[2]/div[3]')
    tags = b.find_elements(by = By.TAG_NAME , value = 'a')
    for element in tags:
        team_a.append(element.get_attribute('href'))
    details = process_details(details, team_a)
    print("\ncompany details-->",details)
    company_details['details'] = details


    list_of_hrefs = []
    content_blocks = driver.find_element(By.XPATH, '//*[@id="root"]/main/div/div/div/div[1]/div[1]/div[1]')

    elements = content_blocks.find_elements(By.TAG_NAME,"a")
    for el in elements:
        list_of_hrefs.append(el.get_attribute("href"))
    links = []
    fb_id=[]
    linkedin_id = []
    ps_link = [] # Play Store
    for link in list_of_hrefs:
        fb_reg = re.search("(\/[a-zA-Z0-9+_.-])?facebook+[a-zA-Z0-9.-]+", link)
        linkedin_reg= re.search("(\/[a-zA-Z0-9+_.-])?linkedin+[a-zA-Z0-9.-]+", link)
        googleps_reg= re.search("(\/[a-zA-Z0-9+_.-])?play.google+[a-zA-Z0-9.-]+", link)
        if fb_reg:
            fb_id.append(link)
        elif linkedin_reg:
            linkedin_id.append(link)
        elif googleps_reg:
            ps_link.append(link)
    print("fb id ->",fb_id)
    print('linkedIn id ->',linkedin_id)
    print('Play Store id ->',ps_link)
    if len(fb_id) > 0:
        company_details['fb'] = fb_id[0]
    else:
        company_details['fb'] = None

    if len(linkedin_id) > 0:
        company_details['linkedin'] = linkedin_id[0]
    else:
        company_details['linkedin'] = None

    if len(ps_link) > 0:
        company_details['play_store'] = ps_link [0]
    else:
        company_details['play_store'] = None 
        
    
    try:
        rev_list = []
        revenue = driver.find_elements(by=By.XPATH, value ='//*[@id="root"]/main/div/div/div/div[1]/div[1]/div[8]/div[3]/div/div')
        for ele in revenue:
            print("\nrevenue-->",ele.text)
        company_details['revenue'] = rev_list

    except:
        pass
    try:
        target_market = driver.find_element(by=By.XPATH, value ='//*[@id="root"]/main/div/div/div/div[1]/div[1]/div[10]/div[3]/div/div/div[4]')
        target_market = target_market.text.split('\n')
        print("\ntarget market-->",target_market)
        company_details['target_market'] = target_market
    except:
        pass

    try:
        recent_startup_el = driver.find_element(By.XPATH, '//*[@id="root"]/main/div/div/div/div[2]')
        recent_startup_link_el = recent_startup_el.find_elements(By.TAG_NAME, 'a')
        for link_el in recent_startup_link_el:
            other_link =  link_el.get_attribute("href")
            if other_link not in other_company_url and 'search' not in other_link and 'companies' in other_link:
                other_company_url.append(other_link)

        company_details['other_url'] = other_company_url
    except Exception as e:
        print(e)
        pass
    print("-------------------------------------")
    print(company_details)
    return company_details

def start_crawling():
    for i in range(50):
        link_data = get_urls(1+i)
        print(link_data)
        api_update.save_yourstory_url(link_data)

def start_scraping():
    datas = api_update.get_yourstory_url()
    for d in datas:
        try:
            print(d['url'])
            res = get_details(d['url'])
            res['id'] = d['id']
            api_update.save_yourstory_data(res)
        except Exception as e:
            print(e)
            pass

# start_crawling()
start_scraping()

# get_details("https://yourstory.com/companies/qua")
# get_details("https://yourstory.com/companies/kaarva/amp")


driver.quit()
