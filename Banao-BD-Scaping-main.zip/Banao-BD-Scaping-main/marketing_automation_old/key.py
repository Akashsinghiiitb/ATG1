import os


locs = ["bangalore","delhi","surat","ahmedabad","chennai","karnataka"]
grp = {"a":"bars","b":"temple","c":"club","d":"mall","e":"ground","f":"adventure","g":"yoga center"}
grp = {"dancing":"dancer","yoga":"yogi","music":"musician","engineering":"engineer","meditation":"meditation","sports":"sportsperson","database":"database"}


    
