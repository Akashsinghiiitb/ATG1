from random import randrange as rn
from random import uniform as un
from time import sleep
from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
import selenium
import requests
from bs4 import BeautifulSoup
import random, pickle
import re
import ast
from log_generator import generate_log
from datetime import date, datetime

# Log file name
current_date = date.today()
current_time = datetime.now().strftime("%H:%M").replace(":", ",")
LOG_FILE = f"{current_time} {current_date} InstagramAuto"

def do_log(*message):
    output_data = ''
    for i in message:
        output_data += f"{i} "
    print(output_data)
    generate_log(output_data, LOG_FILE)

durl = "https://www.atg.party/sc.txt"
def fetch_values(url):
    r = requests.get(url)
    soup = BeautifulSoup(r.content, 'html.parser')
    return soup.text

def get_data(id_val):
    value_of_elem = fetch_values("https://www.atg.party/sc.txt")
    lst = re.split('=|\n', value_of_elem)
    it = iter(lst)
    res_dct = dict(zip(it, it))
    k = ast.literal_eval(res_dct[id_val])
    return k

def randomizer(subject):
    j = get_data(subject)
    if (isinstance(j,dict)):
        topic= random.choice(list(j))
        return (topic)
    else:
        location = random.choice(list(j))
        return(location)



<<<<<<< HEAD
<<<<<<< HEAD
<<<<<<< HEAD
uname="saurabh.atgworld@gmail.com"#Enter the email here
pwd="atgworld@2018"#Enter the password here

URL="https://www.twitter.com"
URL2=URL+r"/following"

=======
uname=""#Enter the email here
pwd=""#Enter the password here
>>>>>>> I am adding FB code here without login functionality
=======
uname=""#Enter the email here
pwd=""#Enter the password here
>>>>>>> I am adding FB code here without login functionality
=======
uname=""#Enter the email here
pwd=""#Enter the password here
>>>>>>> d0b60bfc160f8a93613b2e66ad782b30cb0f6ee0
class Instagram():
    count=0
    def __init__(self):
        option=webdriver.FirefoxOptions()
        profile=webdriver.FirefoxProfile()
        profile.set_preference('permissions.default.image',2)
        profile.set_preference('dom.ipc.plugins.enabled.libflashplayer.so','false')
        #option.add_argument("--headless")
        path=r'/usr/local/bin/geckodriver'
        self.browser=webdriver.Firefox(executable_path=path,firefox_profile=profile,firefox_options=option)
    def check_ele_by_css(self,element):
        delay=10
        try:
            ele=WebDriverWait(self.browser,delay).until(EC.presence_of_element_located((By.CSS_SELECTOR,element)))
        except TimeoutError:
            do_log("sorry not found")
    def login(self):
        try:
            self.goTo("https://www.instagram.com/")
            for cookie in pickle.load(open("InstaCookies.pkl", "rb")):
                self.browser.add_cookie(cookie)
            self.goTo("https://www.instagram.com/")
            sleep(3)
            self.checkNotifDialog()
        except Exception as e:
            self.goTo("https://www.facebook.com")
            self.check_ele_by_css("input[id='email']")
            self.browser.find_element_by_css_selector("input[id='email']").send_keys(uname)
            self.browser.find_element_by_css_selector("input[id='pass']").send_keys(pwd)
            self.browser.find_element_by_css_selector("input[value='Log In']").click()
            sleep(3)
            self.goTo("https://www.instagram.com/")
            # import pdb;pdb.set_trace()
            # self.browser.find_elements_by_css_selector("button[class='sqdOP']").click()
            self.browser.find_elements_by_xpath("//*[contains(text(), 'Continue as atg.world')]")[0].click()
            # import pdb; pdb.set_trace()
            # self.check_ele_by_css("input[aria-label='Phone number, username, or email']")
            # self.check_ele_by_css("input[aria-label='Password']")
            # import pdb; pdb.set_trace()
            # self.browser.find_element_by_css_selector("input[aria-label='Phone number, username, or email']").send_keys(uname)
            # self.browser.find_element_by_css_selector("input[aria-label='Password']").send_keys(pwd)
            # self.browser.find_element_by_css_selector("button[type='submit']").click()
            # sleep(5)
            self.checkNotifDialog()
            pickle.dump(self.browser.get_cookies() , open("InstaCookies.pkl","wb"))
    def goTo(self,URL):
        self.browser.get(URL)
    def checkNotifDialog(self):
        try:
            for i in self.browser.find_elements_by_css_selector("h2"):
                if i.text=="Turn on Notifications":
                    a=self.browser.find_elements_by_css_selector("button[tabindex='0']")
            for j in a:
                if j.text=="Not Now":
                    j.click()
        except:
            pass
        else:
            pass
    def routine(self,srchterm):
        self.login()
        self.browser.find_element_by_css_selector("input[placeholder='Search']").send_keys(srchterm)
        sleep(3)
        try:
            c=self.browser.find_element_by_xpath("//input[@placeholder='Search']/following-sibling::*/following-sibling::*/following-sibling::*")
        except:
            sleep(3)
            c=self.browser.find_element_by_xpath("//input[@placeholder='Search']/following-sibling::*/following-sibling::*/following-sibling::*")
        el=c.find_elements_by_css_selector("a[href]")
        do_log(el)
        sleep(0.2)
        link1=""
        for i in el:
            if i.text[0]!=r"#":
                link1=i.get_attribute("href")
                do_log(link1)
                self.goTo(link1)
                do_log(link1)
                sleep(0.2)
                break
        sleep(0.2)
        sleep(1)
        #This first method below is for starting the process, it does not do anything itself, the further calls to follow772 method work
        self.follow772()
        sleep(0.2)
        self.goDN()
        sleep(0.2)
        self.follow772()
        sleep(0.2)
        self.goDN()
        sleep(0.2)
        self.follow772()
        sleep(0.2)
        self.goDN()
        self.follow772()
        sleep(0.2)
        self.goDN()
        sleep(0.2)
        self.follow77()
        
       
    def follow77(self):
        """Follows 2 accounts"""
        ActionChains(self.browser).move_to_element(self.browser.find_element_by_css_selector("a[href$='followers/']")).click().perform()
        btns=self.btnFIND()
        for i in btns:
            if self.count<29:
                try:
                    ActionChains(self.browser).move_to_element(i).click().perform()
                    sleep(un(5,10))
                except:
                    for j in range(2):
                        try:
                            self.goDN()
                            if j==1:
                                self.goDN()
                            ActionChains(self.browser).move_to_element(i).click().perform()
                            sleep(un(1,3))
                        except:
                            self.goUP()
                            if j==1:
                                self.goUP()
                            ActionChains(self.browser).move_to_element(i).click().perform()
                            sleep(un(1,3))
        self.count+=2
    def follow772(self):
        """Follows 6 accounts"""
        ActionChains(self.browser).move_to_element(self.browser.find_element_by_css_selector("a[href$='followers/']")).click().perform()
        btns=self.btnFIND2()
        for i in btns:
            if self.count<23:
                try:
                    ActionChains(self.browser).move_to_element(i).click().perform()
                    sleep(un(5,10))
                except:
                    for j in range(2):
                        try:
                            self.goDN()
                            if j==1:
                                self.goDN()
                            ActionChains(self.browser).move_to_element(i).click().perform()
                            sleep(un(1,3))
                        except:
                            self.goUP()
                            if j==1:
                                self.goUP()
                            ActionChains(self.browser).move_to_element(i).click().perform()
                            sleep(un(1,3))
        self.count+=6
    
    def goDN(self):
        ActionChains(self.browser).move_to_element(self.browser.find_element_by_css_selector('ul')).send_keys(Keys.PAGE_DOWN).perform()
    def goUP(self):
        ActionChains(self.browser).move_to_element(self.browser.find_element_by_css_selector('ul')).send_keys(Keys.PAGE_UP).perform()
    def btnFIND(self):
        temmp=[]
        temp=self.browser.find_elements_by_css_selector("ul li button[type='button']")
        for i in temp:
            if i.text=="Follow":
                temmp.append(i)
                if len(temmp)==2:
                    break
        do_log(len(temmp))
        if len(temmp)<2:
            sleep(un(0,3))
            ActionChains(self.browser).move_to_element(self.browser.find_element_by_css_selector('ul')).send_keys(Keys.PAGE_DOWN).perform()
            self.btnFIND()

        return temmp
    def btnFIND2(self):
        temmp=[]
        temp=self.browser.find_elements_by_css_selector("ul li button[type='button']")
        for i in temp:
            if i.text=="Follow":
                temmp.append(i)
                if len(temmp)==6:
                    break
        do_log(len(temmp))
        if len(temmp)<6:
            sleep(un(0,3))
            ActionChains(self.browser).move_to_element(self.browser.find_element_by_css_selector('ul')).send_keys(Keys.PAGE_DOWN).perform()
            self.btnFIND()

        return temmp

srchterm1=randomizer('interests')+" "+randomizer('location')
srchterm1=randomizer('interests')
do_log(srchterm1)
I=Instagram()
I.routine(srchterm1)
I.browser.quit()
