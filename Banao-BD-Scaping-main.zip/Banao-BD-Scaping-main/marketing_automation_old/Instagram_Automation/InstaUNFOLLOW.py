from random import randrange as rn
from random import uniform as un
from time import sleep
from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
import pickle
#Imports Above
from log_generator import generate_log
from datetime import date, datetime

# Log file name
current_date = date.today()
current_time = datetime.now().strftime("%H:%M").replace(":", ",")
LOG_FILE = f"{current_time} {current_date} InstaUNFOLLOW"

def do_log(*message):
    output_data = ''
    for i in message:
        output_data += f"{i} "
    print(output_data)
    generate_log(output_data, LOG_FILE)

<<<<<<< HEAD
uname="saurabh.atgworld@gmail.com"#Enter the email here
pwd="atgworld@2018"#Enter the password here
=======
uname=""#Enter the email here
pwd=""#Enter the password here
<<<<<<< HEAD
>>>>>>> I am adding FB code here without login functionality
=======
>>>>>>> d0b60bfc160f8a93613b2e66ad782b30cb0f6ee0

class Instagram():
    count=0
    
    def check_ele_by_css(self,element):
        delay=10
        try:
            ele=WebDriverWait(self.browser,delay).until(EC.presence_of_element_located((By.CSS_SELECTOR,element)))
        except TimeoutError:
            do_log("sorry not found")
    

    #New functions Below
    def __init__(self):
        option=webdriver.FirefoxOptions()
        profile=webdriver.FirefoxProfile()
        profile.set_preference('permissions.default.image',2)
        profile.set_preference('dom.ipc.plugins.enabled.libflashplayer.so','false')
        #option.add_argument("--headless")
        path=r'/usr/local/bin/geckodriver'
        self.browser=webdriver.Firefox(executable_path=path,firefox_profile=profile,firefox_options=option)

    def login(self):
        try:
            self.goTo("https://www.instagram.com/")
            for cookie in pickle.load(open("InstaCookies.pkl", "rb")):
                self.browser.add_cookie(cookie)
            self.goTo("https://www.instagram.com/")
            sleep(3)
            self.checkNotifDialog()
        except Exception as e:
            self.goTo("https://www.facebook.com")
            self.check_ele_by_css("input[id='email']")
            self.browser.find_element_by_css_selector("input[id='email']").send_keys(uname)
            self.browser.find_element_by_css_selector("input[id='pass']").send_keys(pwd)
            self.browser.find_element_by_css_selector("input[value='Log In']").click()
            sleep(3)
            self.goTo("https://www.instagram.com/")
            # self.browser.find_elements_by_css_selector("button[class='sqdOP']").click()
            self.browser.find_elements_by_xpath("//*[contains(text(), 'Continue as atg.world')]")[0].click()
            # import pdb; pdb.set_trace()
            # self.check_ele_by_css("input[aria-label='Phone number, username, or email']")
            # self.check_ele_by_css("input[aria-label='Password']")
            # import pdb; pdb.set_trace()
            # self.browser.find_element_by_css_selector("input[aria-label='Phone number, username, or email']").send_keys(uname)
            # self.browser.find_element_by_css_selector("input[aria-label='Password']").send_keys(pwd)
            # self.browser.find_element_by_css_selector("button[type='submit']").click()
            # sleep(5)
            self.checkNotifDialog()
            pickle.dump(self.browser.get_cookies() , open("InstaCookies.pkl","wb"))
    def goTo(self,URL):
        self.browser.get(URL)
    def checkNotifDialog(self):
        try:
            for i in self.browser.find_elements_by_css_selector("h2"):
                if i.text=="Turn on Notifications":
                    a=self.browser.find_elements_by_css_selector("button[tabindex='0']")
            for j in a:
                if j.text=="Not Now":
                    j.click()
        except:
            pass
        else:
            pass
    #UNFOLLOW FROM BELOW
    def new_routine(self):
        self.login()
        sleep(un(1,3))
        self.myProfile()
        sleep(un(1,3))
        self.followinglist()
        sleep(un(1,3))
        self.scrolll()
        for i in range(19):
            self.subscr()
            sleep(un(0.5,0.7))
        bt=self.getallbuttons()
        self.unfollow(bt)


    def myProfile(self):
        ActionChains(self.browser).move_to_element(self.browser.find_element_by_css_selector("svg[aria-label='Profile']")).click().perform()
    def followinglist(self):
        ActionChains(self.browser).move_to_element(self.browser.find_element_by_css_selector("a[href$='following/']")).click().perform()
    def scrolll(self,go="down"):
        t1=self.browser.find_element_by_css_selector("ul>div")
        t=t1.find_element_by_xpath("..")
        ActionChains(self.browser).move_to_element(t).click().perform()
        ActionChains(self.browser).move_to_element(t).send_keys(Keys.PAGE_DOWN).perform()
    def subscr(self,go="down"):
        t1=self.browser.find_element_by_css_selector("ul>div")
        t=t1.find_element_by_xpath("..")
        if go=="down":
            ActionChains(self.browser).move_to_element(t).send_keys(Keys.PAGE_DOWN).perform()
        elif go=="up":
            ActionChains(self.browser).move_to_element(t).send_keys(Keys.PAGE_UP).perform()
    def getallbuttons(self):
        temmp=[]
        temp=self.browser.find_elements_by_css_selector("ul li button[type='button']")
        for i in temp:
            if i.text=="Following":
                temmp.append(i)
        return temmp
    def unfollow(self,list):
        for i in range(1,21):
            self.browser.execute_script("return arguments[0].scrollIntoView();", list[-i])
            ActionChains(self.browser).move_to_element(list[-i]).click().perform()
            sleep(un(0.1,0.5))
            ActionChains(self.browser).move_to_element(I.browser.find_element_by_css_selector("button[tabindex='0']")).click().perform()
            sleep(un(5,10))
            do_log("Unfollowed"+str(i))
            
        

I=Instagram()
I.new_routine()
I.browser.quit()
