from selenium import webdriver
from time import sleep
from selenium.webdriver.common.action_chains import ActionChains
from selenium import webdriver
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
import selenium
import requests
import keys
from marketing_automation.getting_server_ip import get_server_ip
from log_generator import generate_log
from datetime import date, datetime

# Log file name
current_date = date.today()
current_time = datetime.now().strftime("%H:%M").replace(":", ",")
LOG_FILE = f"{current_time} {current_date} gmap_scrapingv2"

def do_log(*message):
    output_data = ''
    for i in message:
        output_data += f"{i} "
    print(output_data)
    generate_log(output_data, LOG_FILE)

# IP fetched from atg.party/ms.txt
SERVER_IP = get_server_ip()


class ChromeBrowsing():
    grp = ""
    lct = ""
    done = False

    def __init__(self):
        prefs = {"profile.default_content_setting_values.notifications": 2}
        option = webdriver.ChromeOptions()
        option.add_experimental_option("excludeSwitches", ["ignore-certificate-errors"])
        option.add_argument('headless')
        option.add_argument('--no-sandbox')
        option.add_experimental_option("prefs", prefs)
        # option.add_argument("--start-maximized")
        option.add_argument("--window-size=1920x1080")
        option.add_argument("--disable-extensions")
        option.add_argument("--disable-gpu")
        option.add_argument("--disable-dev-shm-usage")
        option.add_argument("disable-infobars")
        path = r"../../drivers/chromedriver"
        # path=r"/home/ubuntu/atg_ui_automation/drivers/chromedriver33"
        # path=r"/home/atg/Om1/chromedriver"
        # path=r"/Users/saurabhbassi/Desktop/chromedriver2"
        self.browser = webdriver.Chrome(executable_path=path, options=option)

    def goTo(self, URL):
        self.browser.get(URL)

    def setInterest(self, group, location):
        self.setgrp(group)
        self.setloc(location)

    def setgrp(self, group="dance"):
        ##self.grp=keys.randomizer('interests')
        self.grp = group

    def setloc(self, location="bangalore"):
        ##self.lct=keys.randomizer('location')
        self.lct = location

    def getInterest(self):
        return self.grp + " " + self.lct

    def getgrp(self):
        return self.grp

    def getloc(self):
        return self.lct

    def gmaps(self):
        interest = self.getInterest()
        self.goTo("https://www.google.com/maps/search/" + interest + "/")
        self.browser.implicitly_wait(30)
        while self.done == False:
            self.lenres = self.getLen()
            do_log(self.lenres)
            do_log("=" * 40)
            self.routine()
        self.browser.quit()

    def routine(self):
        self.browser.implicitly_wait(30)
        res = self.browser.find_elements_by_css_selector("div[data-result-index]")

        lenres = len(res)

        for i in range(0, lenres):
            # do_log("Resource"+str(i))

            I = []
            self.browser.implicitly_wait(10)
            sleep(3)
            res1 = self.browser.find_elements_by_css_selector("div[data-result-index]")
            lenres = len(res1)
            if (i == len(res1) - 1):
                break
            try:
                self.browser.execute_script("arguments[0].scrollIntoView();", res1[i])
                ActionChains(self.browser).move_to_element(res1[i]).click().perform()
            except IndexError:
                continue
            except selenium.common.exceptions.ElementClickInterceptedException:
                pass
            self.browser.implicitly_wait(10)
            self.browser.save_screenshot("/home/ubuntu/Om1/test.png")
            try:
                element_present = EC.presence_of_element_located((By.CSS_SELECTOR, "div>h1"))

                WebDriverWait(self.browser, 3).until(element_present)
                title = self.getTitle()
            except Exception as e:
                try:
                    do_log(e)
                    sleep(1)
                    # res1[i].click()
                    self.browser.execute_script("arguments[0].scrollIntoView();", res1[i])
                    ActionChains(self.browser).move_to_element(res1[i]).click().perform()
                    self.browser.implicitly_wait(10)
                    sleep(1)
                    title = self.getTitle()
                except:
                    i -= 1
                    do_log("i minusing")
                    self.browser.save_screenshot("/home/ubuntu/Om1/test.png")
                    try:
                        self.browser.find_element_by_css_selector("button[jsaction='pane.place.backToList']").click()
                    except:
                        do_log("PRoblema")
                        self.browser.save_screenshot("/home/ubuntu/Om1/test.png")

            info = self.browser.find_elements_by_css_selector(
                "span[class='section-info-text']>span[class='widget-pane-link']")
            for i in info:
                I.append(i.text)
            try:
                Scraper.scrapresGMAP(I, self.getloc(), self.getgrp(), title)
            except Exception as e:
                do_log(e)
                pass

            self.browser.find_element_by_css_selector("button[jsaction='pane.place.backToList']").click()
        try:
            nextbtn = self.browser.find_element_by_css_selector('button[aria-label=" Next page "]')
        except Exception as e:
            do_log(e)
            pass
        try:
            if (nextbtn.get_attribute("disabled") == 'true'):
                self.done = True
                do_log("Last Page Results Done")
            else:
                nextbtn.click()
                do_log("Going To Next Page Now")
                self.browser.implicitly_wait(10)

        except Exception as e:
            do_log(e)
            pass

    def getTitle(self):
        return self.browser.find_element_by_css_selector("div>h1").text

    def getLen(self):
        return len(self.browser.find_elements_by_css_selector("div[data-result-index]"))


class Scraper():
    all_eml = []
    all_phn = []
    all_web = []

    def scrapresGMAP(li, loc, grp, title):
        eorw = []
        phone = []
        for i in li:
            try:
                phone.append(int((i).replace(' ', '')))
            except ValueError:
                k = i
                if (
                        k.endswith('.net') or
                        k.endswith('.com') or
                        k.endswith('.in') or
                        k.endswith('.gov') or
                        k.endswith('.org') or
                        k.endswith('.me')):
                    eorw.append(i)
        email = []
        site = []
        for l in eorw:
            if '@' in l:
                email.append(l)
            else:
                site.append(l)
                try:
                    site[0].replace('Menu\n', '')
                except:
                    pass

        # do_log(phone)
        # do_log(email)
        # do_log(site)
        for i in phone:
            if i in Scraper.all_phn:
                phone.remove(i)
            else:
                Scraper.all_phn.append(i)
        for i in email:
            if i in Scraper.all_eml:
                email.remove(i)
            else:
                Scraper.all_eml.append(i)
        for i in site:
            if i in Scraper.all_phn:
                site.remove(i)
            else:
                Scraper.all_web.append(i)
        do_log("Afterwards")
        do_log(phone)
        do_log(email)
        do_log(site)
        try:
            data1 = ApiCaller.updatedata(email, phone)
            if (len(data1) > 0):
                if (data1[0] == r"&"):
                    dt = "location1=" + loc + "&group1=" + grp + data1 + "&url1=gmap " + title
                    do_log(dt)
                    try:
                        ApiCaller.new_api_poster(dt)
                    except Exception as e:
                        do_log(e)
                        pass
                else:
                    do_log("Insufficient data")
            else:
                do_log("Insufficient data")
        except Exception as e:
            do_log(e)
        try:
            data2 = ApiCaller.updatewebdata(site)
            if (len(data2) > 0):

                dt = "location=" + loc + "&group=" + grp + data2
                do_log(dt)
                try:
                    ApiCaller.web_api_poster(dt)
                except Exception as e:
                    do_log(e)
                    pass

            else:
                do_log("Insufficient data")
        except Exception as e:
            do_log(e)
            pass


class ApiCaller():
    def new_api_poster(data):
        try:
            rq = requests.post(f"http://{SERVER_IP}/api/new-api?{data}")
        except Exception as e:
            # do_log(e)
            pass
        do_log("--" * 40)
        try:
            if rq.ok:
                do_log("Data sent and Response text is " + str(rq.content))
            else:
                do_log("Unsucessful")
            do_log("--" * 40)
        except Exception as e:
            # do_log(e)
            pass

    def web_api_poster(data):
        try:
            rq = requests.post(f"http://{SERVER_IP}/api/website?{data}")
        except Exception as e:
            # do_log(e)
            pass
        try:
            if rq.ok:
                do_log("Data sent and Response text is " + str(rq.content))
            else:
                do_log("Unsucessful")
            do_log("--" * 40)
        except Exception as e:
            # do_log(e)
            pass

    def updatedata(email, phone, about=True):
        eml = ""
        phn = ""
        if len(email) > 0:
            eml += email[0]
        if len(phone) > 0:
            phn += str(phone[0])
        try:
            for i in email:
                if i != email[0]:
                    eml += "," + i
        except:
            pass

        try:
            for i in phone:
                if i != phone[0]:
                    phn += "," + i
        except:
            pass

        if len(eml) > 0:
            eml = "&email1=" + eml
        if len(phn) > 0:
            phn = "&phone1=" + phn
        if about == True:
            pass
        else:
            pass
        # do_log(eml)
        # do_log(phn)
        return eml + phn

    def updatewebdata(website):
        webs = ""
        if len(website) > 0:
            webs += website[0]
        try:
            for i in website:
                if i != website[0]:
                    webs += "," + i
        except:
            pass
        if len(webs) > 0:
            webs = "&website=" + webs
        else:
            pass
        # do_log(webs)
        return webs


C = ChromeBrowsing()
group = "dancer"
location = "ahmedabad"
group = keys.randomizer('interests')
location = keys.randomizer('location')
C.setInterest(group, location)
interest = C.getInterest()
do_log(interest)
C.gmaps()

