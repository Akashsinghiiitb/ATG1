from random import randrange as rn
from random import uniform as un
from time import sleep
from selenium import webdriver
import random, pickle
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
#Imports Above
from log_generator import generate_log
from datetime import date, datetime

# Log file name
current_date = date.today()
current_time = datetime.now().strftime("%H:%M").replace(":", ",")
LOG_FILE = f"{current_time} {current_date} UnTwitter"

def do_log(*message):
    output_data = ''
    for i in message:
        output_data += f"{i} "
    print(output_data)
    generate_log(output_data, LOG_FILE)


uname="admin@atg.world"#Username here
pwd="Twitter@123"#Enter Password here

URL="https://www.twitter.com"
URL2=URL+r"/following"

class UnTwitter():
    def __init__(self):
        option=webdriver.FirefoxOptions()
        #option.add_argument("--headless")
        path=r'/usr/local/bin/geckodriver'
        self.browser=webdriver.Firefox(executable_path=path,firefox_options=option)
    def visitURL(self,URL):
        self.browser.get(URL)
    def exitBrowser(self):
        self.browser.quit()
    def check_ele_by_css(self,element):
        delay=1
        try:
            ele=WebDriverWait(self.browser,delay).until(EC.presence_of_element_located((By.CSS_SELECTOR,element)))
        except TimeoutError:
            do_log("sorry not found")
    def ss(self):
        self.browser.save_screenshot("scr.png")
    def login(self,uname,pwd):
        try:
            for cookie in pickle.load(open("TwitterCookies.pkl", "rb")):
                self.browser.add_cookie(cookie)
        except:
            self.check_ele_by_css("input[name='session[username_or_email]']")
            self.check_ele_by_css("input[type='password']")
            uname=self.browser.find_element_by_css_selector("input[name='session[username_or_email]']").send_keys(uname)
            pwd=self.browser.find_element_by_css_selector("input[type='password']").send_keys(pwd)
            try:
                btn=self.browser.find_element_by_css_selector("input[type='submit']").click()
            except:
                btn=self.browser.find_element_by_css_selector("span span").click()
            pickle.dump(self.browser.get_cookies() , open("TwitterCookies.pkl","wb"))
    def scroll(self):
        self.browser.execute_script("window.scrollTo(0, document.body.scrollHeight);")
    def wait(self):
        self.browser.implicitly_wait(random.randint(40,200))
    #New functions below
    def Untwit(self):
        self.visitURL(URL2)
        self.wait()
        self.scrl30()
        self.scale33()
        self.scroll()
        sleep(un(2,30))
        self.scroll()
        sleep(un(1,21.2))
        self.scroll()
        
    def scrl30(self):
        for i in range(random.randint(2,3)):
            sleep(un(20.33,90.77))
            self.pgdwn()
            
    def pgdwn(self):
        self.browser.find_element_by_tag_name('body').send_keys(Keys.PAGE_DOWN)
    def pgup(self):
        self.browser.find_element_by_tag_name('body').send_keys(Keys.PAGE_UP)
    
    def uflist(self):
        flag=0
        tp=self.findeles()
        for i in range(1,len(tp)+1):
            if flag!=30:
                j=i*(-1)
                do_log(j)
                ActionChains(self.browser).move_to_element(tp[j]).click().perform()
                sleep(un(20.7,180.92))
                try:
                    ActionChains(self.browser).move_to_element(self.browser.find_element_by_css_selector("div[data-testid='confirmationSheetConfirm']")).click().perform()
                except:
                    self.pgup()
##                    ActionChains(self.browser).move_to_element(self.browser.find_element_by_css_selector("div[data-testid='confirmationSheetConfirm']")).click().perform()
                else:
                    pass
                sleep(un(10,150.2))
                flag+=1
                
    def scale33(self):
        self.browser.execute_script('document.body.style.MozTransform = "scale(0.33)";')
    def findeles(self):
        temp=self.browser.find_elements_by_css_selector("div[data-testid='UserCell'] div[data-testid$='unfollow'] span span")
        return temp

u=UnTwitter()
u.visitURL(URL)
u.wait()
u.login(uname,pwd)
u.wait()
u.Untwit()
u.wait()
u.uflist()
u.browser.quit()
