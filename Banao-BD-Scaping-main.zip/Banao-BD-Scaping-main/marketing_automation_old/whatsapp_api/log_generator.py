import logging

def setup_logger(log_file):
    # Create a logger
    logger = logging.getLogger('my_logger')
    logger.setLevel(logging.DEBUG)

    # Create a file handler to write log messages to the file
    file_handler = logging.FileHandler(log_file, encoding='utf-8')
    file_handler.setLevel(logging.DEBUG)

    # Create a formatter to specify the log message format
    formatter = logging.Formatter('%(asctime)s  %(message)s')
    file_handler.setFormatter(formatter)

    # Add the file handler to the logger
    logger.addHandler(file_handler)

    return logger

def generate_log(message, file):
    try:
        log_file = f'marketing_automation_old/whatsapp_api/{file}.log'
        logger = setup_logger(log_file)
    except:
        try:
            log_file = f'whatsapp_api/{file}.log'
            logger = setup_logger(log_file)
        except:
            log_file = file
            logger = setup_logger(log_file)

    logger.info(message)