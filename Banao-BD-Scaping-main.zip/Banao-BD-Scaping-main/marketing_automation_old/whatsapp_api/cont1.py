from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import pickle
#from api import login
from log_generator import generate_log
from datetime import date, datetime

# Log file name
current_date = date.today()
current_time = datetime.now().strftime("%H:%M").replace(":", ",")
LOG_FILE = f"{current_time} {current_date} cont1"

def do_log(*message):
    output_data = ''
    for i in message:
        output_data += f"{i} "
    print(output_data)
    generate_log(output_data, LOG_FILE)

 
#returns 1 if number already present in contacts else  0.
import time
def login_wapp(browser):
    try:
        do_log("here")
        for cookie in pickle.load(open("wapp.pkl", "rb")):
            browser.add_cookie(cookie)
    except:
        do_log("please scan QR in ASAP")
        time.sleep(10)
        pickle.dump(browser.get_cookies() , open("wapp.pkl","wb"))

def login_mail(browser,uname,pwd):
    try:
        for cookie in pickle.load(open("email.pkl", "rb")):
            browser.add_cookie(cookie)
    except:
        email = browser.find_element_by_css_selector('#identifierId')
        email.send_keys(uname)
        push = browser.find_element_by_id('identifierNext') 
        #time.sleep(50)
        push.click()
        time.sleep(2)
        password = browser.find_element_by_css_selector('#password > div.aCsJod.oJeWuf > div > div.Xb9hP > input')


        # own password in keys
        password.send_keys(pwd)
        push1 = browser.find_element_by_id('passwordNext') 
        push1.click()
        time.sleep(5)
        #browser.get('https://web.whatsapp.com/')
        #time.sleep(10)
        #sleep(random.randint(1,3))
        pickle.dump(browser.get_cookies() , open("email.pkl","wb"))
def create_send(brows,loginid,password1,name1, surname1,number1):
    #browser = webdriver.Chrome(executable_path="/home/abhishek/Desktop/stg/atg_ui_automation/drivers/chromedriver")
    
    brows.get("https://contacts.google.com/")
    
    time.sleep(2)
    #login_mail(brows,loginid,password)
    #
    brows.maximize_window()
    time.sleep(2)
    crt_con = brows.find_element_by_css_selector("#gb > div.gb_zc.gb_xc.gb_Cc.gb_Dc.gb_na > div.gb_Ec > div > c-wiz > div > div.k831u > div > div > button")
    crt_con.click()


    time.sleep(2)
    check=brows.find_element_by_css_selector("#c18 > div.TNHOSe > div:nth-child(1) > div")
    check.click()
    time.sleep(2)
    #reciever address in send keys#
    name = brows.find_element_by_css_selector("#c18 > div.TNHOSe > div:nth-child(1) > div > div.aCsJod.oJeWuf > div > div.Xb9hP > input")
    name.send_keys(name1)

    #time.sleep(2)
  
    check2=brows.find_element_by_css_selector("#c18 > div.TNHOSe > div:nth-child(3) > div > div.aCsJod.oJeWuf")
    check2.click()
    surname = brows.find_element_by_css_selector("#c18 > div.TNHOSe > div:nth-child(3) > div > div.aCsJod.oJeWuf > div > div.Xb9hP > input")
    surname.send_keys(surname1)

    time.sleep(2)
    check3=brows.find_element_by_css_selector("#c23 > div.qqYQWe.Kvh2zd > div.rFrNMe.RSJo4e.zKHdkd > div.aCsJod.oJeWuf")
    check3.click()
    
    number=brows.find_element_by_css_selector("#c23 > div.qqYQWe.Kvh2zd > div.rFrNMe.RSJo4e.zKHdkd > div.aCsJod.oJeWuf > div > div.Xb9hP > input")
    number.send_keys(number1)

    time.sleep(2)

    save = brows.find_element_by_css_selector("#yDmH0d > div.llhEMd.iWO5td > div > div.g3VIld.G2PfHe.Up8vH.Whe8ub.hFEqNb.J9Nfi.iWO5td > span > div > div.PWsB5e > div > button:nth-child(2)")
    save.click()
    #contact saved succesfully

    do_log("contact saved succesfully , msg will be sent soon")
    brows.get("https://contacts.google.com/")



    "here whatsapp automation starts"
    "sleep time given to get changes done in google contacts save"





    time.sleep(25)
    brows.get('https://web.whatsapp.com/')
    #login_wapp(brows)
    #time.sleep(5)
    #brows.get('https://web.whatsapp.com/')
    time.sleep(5)
    q1=brows.find_element_by_css_selector("#side > div._2HS9r > div > label")
    q1.click()
    search=brows.find_element_by_css_selector("#side > div._2HS9r > div > label > input")
    search.send_keys(name1 ," " , surname1)
    #time.sleep(2)
    result=brows.find_element_by_class_name("_2WP9Q")
    result.click()
    qq=brows.find_element_by_css_selector("#main > footer > div._2i7Ej._14Mgc.copyable-area > div._13mgZ")
    qq.click()
    msg=brows.find_element_by_css_selector("#main > footer > div._2i7Ej._14Mgc.copyable-area > div._13mgZ > div > div._3u328.copyable-text.selectable-text")
    msg.send_keys("this is test message kindly ignore!")
    #send= browser.find_element_by_class_name("_3M-N-")
    #send.click()
    time.sleep(10)
    brows.quit()