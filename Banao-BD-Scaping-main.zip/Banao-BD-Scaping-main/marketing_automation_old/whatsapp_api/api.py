import urllib.request
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import json
import requests
import pickle
# import thread
from log_generator import generate_log
from datetime import date, datetime

# Log file name
current_date = date.today()
current_time = datetime.now().strftime("%H:%M").replace(":", ",")
LOG_FILE = f"{current_time} {current_date} api"

def do_log(*message):
    output_data = ''
    for i in message:
        output_data += f"{i} "
    print(output_data)
    generate_log(output_data, LOG_FILE)

from cont1 import create_send, login_mail
import sys, select

from marketing_automation.getting_server_ip import get_server_ip

# IP fetched from atg.party/ms.txt
SERVER_IP = get_server_ip()

loginid = 'emailid'
passwd = 'password'

browser = webdriver.Chrome(executable_path="/home/abhishek/Desktop/stg/atg_ui_automation/drivers/chromedriver")
browser.get("https://contacts.google.com/")
time.sleep(2)
login_mail(browser, loginid, passwd)
time.sleep(4)


# stopwatch(20)
def is_number_present(browser, number):
    # browser.refresh()
    # browser.quit()
    browser.get("https://contacts.google.com/search/" + str(number))
    time.sleep(5)

    bodyText = browser.find_element_by_tag_name('body').text
    # do_log(bodyText)
    # browser.quit()
    if ("No results in your contacts" in bodyText):
        return 0
    else:
        return 1
    """if(number in  bodyText):
        return 1
    else :
        return 0"""
    # return


def get_api(url):
    response = urllib.request.urlopen(url)  # using urllib for getting data using getapi
    z = response.read()
    y = json.loads(z)
    # do_log(y)
    t = y[0]
    l = []  # made a new list for the addition of id and number
    if (y == "no record found"):
        do_log("no records found kindly search for some other location/ group")
        return l

    number = t["phone"]
    id = t["id"]  # for usage in postAPI.
    if ("business_name" in t):
        business_name = t["business_name"]
    else:
        business_name = ""
    loc = t["location"]
    grp = t["group_name"]

    l.append(number)
    l.append(id)
    l.append(business_name)
    l.append(loc)
    l.append(grp)
    return l


def postAPI(contactid, status):
    post_url = f"http://{SERVER_IP}/api/whatsapp-update/{str(contactid)}/{str(status)}"
    response = requests.post(post_url)  # using requests to postapi


group = "q"
location = "q"

do_log("enter input in 10 seconds")
i, o, e = select.select([sys.stdin], [], [], 10)

if (i):
    group = sys.stdin.readline().strip()
    location = sys.stdin.readline().strip()
    # do_log ("You said", sys.stdin.readline().strip())
else:
    do_log("You didn't enter any input")

do_log("came here")
do_log(group)
do_log(location)

get_url = f"http://{SERVER_IP}/api/whatsapp/{group}/{location}"
get_url1 = f"http://{SERVER_IP}/api/whatsapp?count=1"

if (group != "q" and location != "q"):
    lister = get_api(get_url)
    if (len(lister) == 0):
        do_log("ending coderun")
        sys.exit()

else:
    lister = get_api(get_url1)
    if (len(lister) == 0):
        do_log("ending coderun")
        sys.exit()
    group = lister[4]  # 1st elemennt of list is phone number
    location = lister[3]

# count=1#keeping current count=1

# get_api(count)# list returned by getapi function
number = lister[0]  # 1st elemennt of list is phone number
id = lister[1]  # 2nd element is id
business_name = lister[2]
do_log("phone==>", number)
do_log("id-->", id)
do_log("busisness_name -->", business_name)
# do_log("calling google search for the number obtained through getAPI")
# google_search(number)#calling google search for the number obtained through getAPI


f_name = str(group) + " " + str(location)

do_log("checking for duplicates in google contacts")
check_duplicate = is_number_present(browser, str(number))  # checking for duplicates in google contacts

if (check_duplicate == 0):
    do_log("creating contact and sending msg to that")
    create_send(browser, loginid, passwd, f_name, business_name, number)
    do_log("msg sent to new contact")
else:
    do_log("contact already exist in contact list")

# postAPI(id,1) # posting the whatsapp to be 1 for the already contacted contact

# now i am trying to check whether post API worked succsfully or not , so i will again call get api
# using a count of 1 , and we'll see that a new number with a new id comes up!


"""lister=get_api(count)# list returned by getapi function
number=lister[0]#1st elemennt of list is phone number
id = lister[1]#2nd element is id
do_log(number)
do_log(id)"""
# currently i am again ,making status of this particular contact 0 by post API so that , it comes to its original condition
# calling postAPI again now making status 0.
# postAPI(id,0)
