import requests
from marketing_automation.enviroment_variables import party_url

def get_server_ip():
    response = requests.get(f"{party_url}/ms.txt")
    return response.text


if __name__ == '__main__':
    get_server_ip()