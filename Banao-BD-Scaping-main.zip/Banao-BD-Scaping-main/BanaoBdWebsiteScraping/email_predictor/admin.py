from django.contrib import admin
from email_predictor.models import EmailFormat

@admin.register(EmailFormat)
class EmailFormatAdmin(admin.ModelAdmin):
    list_display = ['id', 'format_json']

# Register your models here.
