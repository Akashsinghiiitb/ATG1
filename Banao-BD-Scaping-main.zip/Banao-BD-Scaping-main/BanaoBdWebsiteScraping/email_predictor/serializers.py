from rest_framework import serializers
from Backend.models import PeopleName

class PeopleDataSerializer(serializers.ModelSerializer):
    domain = serializers.SerializerMethodField()
    first_name = serializers.SerializerMethodField()
    last_name = serializers.SerializerMethodField()

    def get_domain(self, obj):
        if obj.url.website_domain.email_domain:
            return obj.url.website_domain.email_domain
        return obj.url.website_domain.url

    def get_first_name(self, obj):
        name_sp = obj.name.split(". ")[-1].split(" ")[0]
        return name_sp
    
    def get_last_name(self, obj):
        name_sp = obj.name.split(". ")[-1].split(" ")
        if len(name_sp) == 2:
            return name_sp[1]
        if len(name_sp) > 2:
            return name_sp[2]
        return ""

    class Meta:
        model = PeopleName
        fields = ['domain', 'first_name', 'last_name', 'roll', 'roll1', 'department']