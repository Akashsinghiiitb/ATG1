from django.core.management.base import BaseCommand, CommandError
from Backend.models import PeopleName
from email_predictor.serializers import PeopleDataSerializer
from email_predictor.mail_predictor import predict_email
from email_predictor.models import EmailFormat
import json
import time

class Command(BaseCommand):
    help = 'Start predicting emails'

    def add_arguments(self, parser):
        parser.add_argument('--limit',nargs=1,type=int)

    def handle(self, *args, **options): 
        limit=500
        if(options['limit']):
            limit=options['limit'][0]
        formats = EmailFormat.objects.filter(is_active=True).values_list('format_json', flat=True)
        print(formats)
        formats = {
                'variables' : ['first_name', 'last_name', 'roll', 'roll1', 'department', 'domain'],
                'formats' : [json.loads(form) for form in formats]
            }
        print(formats)
        names = PeopleName.objects.filter(email_predicted = False).order_by('-url__website_domain__priority')[:limit]
        for name in names:
            serializer = PeopleDataSerializer(instance=name)
            email_count  = predict_email(serializer.data, formats, name)
            name.email_predicted = True
            name.email_found = email_count
            name.save()
            time.sleep(3)


