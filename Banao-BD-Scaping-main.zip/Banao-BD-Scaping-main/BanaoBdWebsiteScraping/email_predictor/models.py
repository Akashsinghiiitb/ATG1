from django.db import models

# Create your models here.

class EmailFormat(models.Model):
    format_json = models.TextField()
    is_active = models.BooleanField(default=True)

    def __str__(self) -> str:
        return f"{self.id}"