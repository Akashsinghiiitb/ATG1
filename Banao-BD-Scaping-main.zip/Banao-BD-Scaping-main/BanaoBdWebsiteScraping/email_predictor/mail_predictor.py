from Backend.models import People
from Backend.email_validator import validate
import logging
logging.basicConfig(filename='mail_predictor.log', encoding='utf-8', level=logging.DEBUG)
logging.info('So should this')

data = {
    'domain' : 'ghc.ac.in',
    'first_name' : 'isanur',
    'last_name' : 'sardar',
    'roll_no' : '2190168'
}

formats = {
    'variables' : ['first_name', 'last_name', 'roll', 'department'],
    'formats' : [
        {
            "string" : "{first_name}.{last_name}_ghc_{roll_no}",
            "len_constraints" : [-1,-1,[0,2]]
        },
        {
            'string' : '{last_name}.{first_name}_ghc',
            'len_constraints' : [0,-1,[0,2]]
        },
    ]
}


def len_contraints(value_str,length):
    # print(value_str, length)
    try:
        if type(length) == type(0):
            if length < 0:
                return value_str
            return value_str[length]
        elif type(length) == type([1,2]) and len(length) == 2:
            return value_str[length[0]:length[1]]
        raise Exception("Only Int and list of len 2 are accepted in 'len_constraints'")
    except:
        return value_str





def predict_email(data, formats, ins):
    result_l = []
    print(data)
    for form in formats['formats'] :
        try:
            final_val = {}
            i = 0
            for var in formats['variables']:
                try:
                    len_con = form['len_constraints'][i]
                except:
                    len_con = -1
                final_val[var] = len_contraints(data[var],len_con)
                i +=1
            print(">>",final_val)
            email = form['string'].format(**final_val) + "@" + data['domain']
            email = email.lower()
            val = ""
            saved = ""
            if validate(email):
                val = "validated"
                prev_people = People.objects.filter(email=email)
                if prev_people.count() == 0:
                    result_l.append(email)
                    people = People(url=ins.url, name=ins.name, email = email)
                    people.save()
                    saved = "Saved to DB"
                else:
                    saved = "email already exists"
            else:
                val = "not validated"
            log = "predicted_email >> "+ email+"  --- "+ val+ " --- "+ saved
            print(log)
            logging.info(log)
        except Exception as e:
            print('---')
            print(e)
            logging.error(e)

    return len(result_l)


# results = predict_email(data,formats)
# print(results)

