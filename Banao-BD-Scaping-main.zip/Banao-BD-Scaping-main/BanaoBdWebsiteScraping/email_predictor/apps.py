from django.apps import AppConfig


class EmailPredictorConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'email_predictor'
