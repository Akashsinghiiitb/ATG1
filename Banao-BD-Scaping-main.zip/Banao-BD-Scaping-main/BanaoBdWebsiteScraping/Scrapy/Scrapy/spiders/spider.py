from traceback import print_tb
from scrapy.spiders import Spider
from scrapy.linkextractors import IGNORED_EXTENSIONS
import scrapy
import tldextract
import requests
from ..items import ScrapyItem,WebsiteItem
import validators
import logging, coloredlogs
logger = logging.getLogger(__name__)
coloredlogs.install(logger=logger)
from scrapy.spidermiddlewares.httperror import HttpError
from twisted.internet.error import DNSLookupError,TimeoutError

class Crawling(Spider):
    name = 'Crawling'
    IGNORED_EXTENSIONS+=['txt','tbz']
    IGNORED_EXTENSIONS.remove('pdf')
    IGNORED_EXTENSIONS=set(IGNORED_EXTENSIONS)
    custom_settings = {'RETRY_ENABLED': False}
    
    def __init__(self,*args,**kwargs):
        urls_list = kwargs.get('urls_list').split(',')
        self.start_urls =urls_list
        super(Crawling, self).__init__( *args,**kwargs)
        
    def start_requests(self):
        logger.warn(self.start_urls)
        for url in self.start_urls:
            try:
                logger.warn("Start URL :  {}".format(url))
                yield scrapy.Request(url, callback=self.parse_url,errback=self.handle_error,dont_filter=True,meta={'main_url': url[url.index("//")+2:]})
            except Exception as e:
                logger.warn("Exception occur:{}".format(e))

    def parse_url(self, response):
        try:
            if response.status==200:
                extracted_domain = tldextract.extract(response.url)
                logger.warn("Response URL:  {}".format(response.url))
                domain = "{}.{}".format(extracted_domain.domain, extracted_domain.suffix)
                for href in response.css("a::attr('href')"):
                    try:
                        url=response.urljoin(href.extract())
                        extracted_domain = tldextract.extract(url)
                        link_domain = "{}.{}".format(extracted_domain.domain, extracted_domain.suffix)
                        if validators.url(url) and url.split('.')[-1].lower() not in IGNORED_EXTENSIONS and link_domain==domain and "#" not in url:
                            www_index=-1
                            try:
                                www_index=url.lower().index('www.')
                            except:
                                pass
                            if www_index >-1:
                                url=url[www_index+4:]
                            else:
                                url=url[url.index("//")+2:]
                            if(url[-1]=='/'):
                                url=url[:-1]
                            item=ScrapyItem()
                            item['url']=url
                            item['domain']=domain
                            if(url.split(".")[-1].lower().strip()=='pdf'):
                                item['is_pdf']=True
                            else:
                                item['is_pdf']=False
                            yield item
                        
                    except Exception as e:
                        logger.warn("Exception occur:{}".format(e))
        except Exception as e:
            logger.warn("Exception occur:{}".format(e))
        finally:
            logger.error("finally called for {}".format(response.meta.get("main_url")))
            item=WebsiteItem()
            item['url']=response.meta.get("main_url")
            yield item

    def handle_error(self, failure):
        try:
            logger.error(repr(failure))
            item=WebsiteItem()
            item['url']=failure.request.meta.get("main_url")
            yield item
        except:
            logger.error("Error occured in handle_error function")
        

