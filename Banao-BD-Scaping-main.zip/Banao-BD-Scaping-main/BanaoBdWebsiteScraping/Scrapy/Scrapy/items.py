# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class ScrapyItem(scrapy.Item):
    url = scrapy.Field()
    domain= scrapy.Field()
    is_pdf=scrapy.Field()

class WebsiteItem(scrapy.Item):
    url = scrapy.Field()