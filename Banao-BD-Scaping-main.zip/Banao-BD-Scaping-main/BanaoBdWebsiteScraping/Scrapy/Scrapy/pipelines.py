# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
from Backend.models import WebsiteUrl,Website
from .items import WebsiteItem,ScrapyItem

import logging, coloredlogs
logger = logging.getLogger(__name__)
coloredlogs.install(level="WARN", logger=logger)

class ScrapyPipeline:
    def process_item(self, item, spider):
        if isinstance(item, ScrapyItem):
            try:
                WebsiteUrl.objects.create(website_domain=Website.objects.get(url=item['domain']), url=item['url'],is_pdf=item['is_pdf'])
                logger.warn("added url:- {}".format(item['url']))
            except Exception as e:
                pass
                #logger.error("\nFailed to add url, Reason For Failure:{}".format(e))
        if isinstance(item, WebsiteItem):
            try:
                obj=WebsiteUrl.objects.get(url=item['url'])
                obj.crawled_status=True
                obj.save()
                logger.warn("Crawled url:- {}".format(item['url']))
            except Exception as e:
                pass
                #logger.error("Failed to crawled url, Reason For Failure:{}".format(e))
        return item
