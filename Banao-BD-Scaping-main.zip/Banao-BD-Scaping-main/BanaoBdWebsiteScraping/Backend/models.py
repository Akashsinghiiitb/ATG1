from django.db import models
from django.template.defaultfilters import truncatechars 
from django.contrib.auth.models import User

class UserData(models.Model):
    name=models.CharField(max_length=255,null=True,blank=True)
    token=models.CharField(max_length=255,unique=True)
    last_accessed=models.DateTimeField(null=True,blank=True)
    last_fetched=models.DateTimeField(null=True,blank=True)
    people_ids=models.TextField(null=True,blank=True)
    def __str__(self):
        return self.token

class Website(models.Model):
    id=models.AutoField(primary_key=True)
    name=models.CharField(max_length=255,null=True,blank=True)
    state=models.CharField(max_length=255,null=True,blank=True)
    city=models.CharField(max_length=255,null=True,blank=True)
    url=models.CharField(unique=True,max_length=128)
    email_domain = models.CharField(max_length=50,null=True,blank=True)
    domain=models.CharField(max_length=128,null=True,blank=True)
    priority=models.IntegerField(default=0)
    crawled_status=models.BooleanField(default=False)
    def __str__(self):
        return self.url

class WebsiteUrl(models.Model):
    id=models.AutoField(primary_key=True)
    website_domain=models.ForeignKey(Website,to_field='url',db_column='website_domain',on_delete=models.CASCADE )
    url=models.CharField(unique=True,max_length=255)
    crawled_status=models.BooleanField(default=False)
    scraped_status=models.BooleanField(default=False)
    is_pdf=models.BooleanField(default=False)
    people_scarped = models.BooleanField(default=False)
    priority=models.IntegerField(default=0)
    def __str__(self):
        return self.url
    @property
    def website_url(self):
        return truncatechars(self.url, 50)

class People(models.Model):
    id=models.AutoField(primary_key=True)
    url=models.ForeignKey(WebsiteUrl,to_field='url',db_column='url',on_delete=models.CASCADE)
    name=models.CharField(max_length=255,null=True,blank=True)
    email=models.EmailField(unique=True)
    number=models.CharField(max_length=16,null=True,blank=True)
    designation=models.CharField(max_length=128,null=True,blank=True)
    fetched_status=models.BooleanField(default=False)
    added_at = models.DateTimeField(auto_now_add= True)

    @property 
    def website_url(self):
        return truncatechars(self.url, 50)

class PeopleName(models.Model):
    name = models.CharField(max_length=300)
    roll = models.CharField(max_length=30, null=True)
    roll1 = models.CharField(max_length=30, null=True)
    department = models.CharField(max_length=100, null=True)
    url = models.ForeignKey(WebsiteUrl, on_delete=models.CASCADE)
    email_predicted = models.BooleanField(default=False)
    email_found = models.IntegerField(default=0)
    designation=models.CharField(max_length=128,null=True,blank=True)

    def __str__(self):
        return f'{self.name} - {self.roll}'
