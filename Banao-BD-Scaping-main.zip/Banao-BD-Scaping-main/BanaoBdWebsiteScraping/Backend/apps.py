from django.apps import AppConfig
import pytesseract

class BackendConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Backend'

    pytesseract.pytesseract.tesseract_cmd = r'C:/Users/abhis/data/Atg/Tesseract/tesseract.exe'