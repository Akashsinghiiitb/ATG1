from django.shortcuts import render

# Create your views here.
from django.http import JsonResponse,HttpResponse
from rest_framework.views import APIView
from .models import People,UserData, Website
from .serializers import PeopleSerializer, WebsiteSerializer
from rest_framework.response import Response
from rest_framework import status
from drf_excel.renderers import XLSXRenderer
from rest_framework.viewsets import ReadOnlyModelViewSet,ModelViewSet
from drf_excel.mixins import XLSXFileMixin
from .authentication import UserAuthentication
from rest_framework.permissions import IsAuthenticated
from django.http import HttpResponse
from rest_framework.views import APIView
from datetime import datetime,timezone


class PeopleApi(XLSXFileMixin, ReadOnlyModelViewSet):
    authentication_classes = (UserAuthentication,)
    serializer_class =PeopleSerializer
    renderer_classes = [XLSXRenderer]
    filename = 'my_export.xlsx'
    def get_queryset(self):
        limit=self.request.query_params.get('limit', 25)
        website_id=self.request.query_params.get('website_id', None)
        # if website_id is not None:
        #     objs=People.objects.filter(url=)
        token = self.request.query_params.get('token')
        user = UserData.objects.get(token=token) 
        current=datetime.now(timezone.utc)
        
        if user.last_fetched is not None:
            previous=user.last_fetched
            difference=current-previous
            hours=int((difference.total_seconds()/60)/60)
            if hours<24:
                user.last_accessed=current
                user.save()
                people=user.people_ids
                list=[]
                for person in people.split(","):
                    list.append(People.objects.get(id=int(person)))
                return list
        queryset=People.objects.filter(fetched_status=False)[:int(limit)]
        if len(queryset) ==0:
            return queryset
        user.last_fetched=current
        user.last_accessed=current
        str_people=f"{queryset[0].id}"
        queryset[0].fetched_status=True
        queryset[0].save()
        for person in queryset[1:]:
            str_people=f"{str_people},{person.id}"
            person.fetched_status=True
            person.save()
        user.people_ids=str_people
        user.save()
        return queryset

class WebsiteApi(ModelViewSet):      
    queryset = Website.objects.all()
    serializer_class = WebsiteSerializer
