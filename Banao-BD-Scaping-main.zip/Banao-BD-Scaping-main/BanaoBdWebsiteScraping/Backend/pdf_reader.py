from PIL import Image
import pytesseract
import sys
from pdf2image import convert_from_path
import os

pytesseract.pytesseract.tesseract_cmd =  r'C:/Users/abhis/data/Atg/Tesseract/tesseract.exe'
PDF_file = "C:/Users/abhis/data/Atg/mp.pdf"

pages = convert_from_path(PDF_file, poppler_path="C:/Users/abhis/data/Atg/poppler-0.68.0/bin")
image_counter = 1

for page in pages:

	filename = "page_"+str(image_counter)+".jpg"
	page.save(filename, 'JPEG')
	image_counter = image_counter + 1

filelimit = image_counter-1
outfile = "output.csv"
f = open(outfile, "a")

for i in range(1, filelimit + 1):

	filename = "page_"+str(i)+".jpg"
	text = str(((pytesseract.image_to_string(Image.open(filename)))))
	text = text.replace('-\n', '')	
	f.write(text)
f.close()

import pandas as pd
a = pd.read_csv("output.csv",encoding = 'unicode_escape',on_bad_lines='skip')
a.to_html("output.html")



