from django.contrib import admin
from .models import PeopleName, Website, WebsiteUrl,People,UserData
from rangefilter.filters import DateRangeFilter, DateTimeRangeFilter
from django.http import HttpResponse
import csv

class ExportCsvMixin:
    def export_as_csv(self, request, queryset):

        meta = self.model._meta
        field_names = [field.name for field in meta.fields]

        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename={}.csv'.format(meta)
        writer = csv.writer(response)

        writer.writerow(field_names)
        for obj in queryset:
            row = writer.writerow([getattr(obj, field) for field in field_names])

        return response

    export_as_csv.short_description = "Export Selected"

@admin.register(Website)
class WebsiteAdmin(admin.ModelAdmin):
    list_display = ("name","url","state","city","domain","priority","crawled_status")
    search_fields = ['url']
    list_filter = ["crawled_status"]
    ordering = ['-priority']

@admin.register(WebsiteUrl)
class WebsiteUrlAdmin(admin.ModelAdmin):
    list_display = ("website_url", "priority","crawled_status","scraped_status","is_pdf", "people_scarped")
    search_fields = ['url']
    list_filter = ["crawled_status","scraped_status" , "is_pdf","people_scarped"]
    ordering = ['-priority']

@admin.register(People)
class PeopleAdmin(admin.ModelAdmin, ExportCsvMixin):
    list_display = ("name", "email","number",'designation','website_url','fetched_status')
    list_filter = ["fetched_status", 'designation', ('added_at', DateRangeFilter)]
    search_fields = ["name",'email','url__url', 'url__website_domain__name']
    actions = ["export_as_csv"]

@admin.register(PeopleName)
class PeopleNameAdmin(admin.ModelAdmin):
    list_display = ("name", "department", "roll", "roll1", "email_predicted", "email_found")
    search_fields = ("name", "url__url")
    list_filter = ("url__website_domain__url",)

admin.site.register(UserData)