from .models import UserData
from rest_framework import authentication
from rest_framework import exceptions

class UserAuthentication(authentication.BaseAuthentication):
    def authenticate(self, request):
        token = request.query_params.get('token',None)
        if token is None: 
            raise exceptions.AuthenticationFailed('No credentials provided.')
        try:
            user = UserData.objects.get(token=token) 
        except :
            raise exceptions.AuthenticationFailed('No such user') 

        return (user, None) 