# %%
import re
import smtplib
import dns.resolver

def validate(emailaddress):
    regex = '^[a-z0-9]+[\._]?[a-z0-9]+[@]\w+[.]\w{2,3}$'

    # emailaddress = input("Please enter the emailAddress to verify:").strip()

    # if not (re.search(regex, emailaddress)):
    #     print("--")
    #     return False

    splitAddress = emailaddress.split('@')
    domain = str(splitAddress[1])
    # print('Domain:', domain)

    records = dns.resolver.resolve(domain, 'MX')
    mxRecord = records[0].exchange
    mxRecord = str(mxRecord)

    server = smtplib.SMTP()

    fromAddress = 'just_a_place_holder@domain.com'

    server.connect(mxRecord)
    server.helo(server.local_hostname)
    server.mail(fromAddress)
    code, message = server.rcpt(str(emailaddress))
    server.quit()

    if code == 250:
        return True
    else:
        return False

