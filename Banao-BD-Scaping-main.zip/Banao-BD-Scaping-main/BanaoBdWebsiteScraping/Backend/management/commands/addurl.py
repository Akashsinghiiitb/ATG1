from django.core.management.base import BaseCommand, CommandError
from Backend.models import Website
import tldextract
import pandas as pd
import logging, coloredlogs
logger = logging.getLogger(__name__)
coloredlogs.install(logger=logger)

class Command(BaseCommand):
    help = 'Scrape Pages of Specified WebSite'

    def add_arguments(self, parser):
        parser.add_argument('url',nargs=1,type=str)
    
    def handle(self, *args, **options): 
        try:
            url=options['url'][0]
            extracted_domain = tldextract.extract(url)
            domain = "{}.{}".format(extracted_domain.domain, extracted_domain.suffix)
            Website.objects.create(url=domain)
            logger.warn("Added url in Website table :- {}".format(domain))
        except Exception as e :
            logger.error("Failed to add url in Website table, Reason For Failure: {}".format(e))
        

"""
            df=pd.read_csv("C:/Users/abhis/Downloads/College website links - Sheet1.csv")
            for record in df.iterrows():
                college=record[1]['Name of the college']
                url=record[1]["college website"]
                if  pd.isna(url):
                    continue
                extracted_domain = tldextract.extract(url)
                url_domain = "{}.{}".format(extracted_domain.domain, extracted_domain.suffix)
                domain=record[1]["Domain"]
                city=record[1]["City"]
                state=record[1]['State']
                try:
                    Website.objects.create(url=url_domain,name=college,state=state,city=city,domain=domain)
                except:
                    obj=Website.objects.get(url=url_domain)
                    obj.name=college
                    obj.state=state
                    obj.city=city
                    obj.domain=domain
                    obj.save()
            
"""