from django.core.management.base import BaseCommand, CommandError
from Backend.models import Website,WebsiteUrl
import os
from pathlib import Path
import logging
logger = logging.getLogger(__name__)


class Command(BaseCommand):
    help = 'Scraping student list urls from Google'
    django_path = Path(__file__).resolve().parent.parent.parent.parent
    def add_arguments(self, parser):
        parser.add_argument('--limit',nargs=1,type=int)
    
    def handle(self, *args, **options):
        limit=200
        if(options['limit']):
            limit=options['limit'][0]
        names=Website.objects.filter(crawled_status=False).order_by('-website_domain_priority')[:limit]
        if(len(names) == 0):
            logger.warn("No Websites Left")
        url_list = ''
        for name in names:
            url_list += str(name)+','
        logger.warn("number of college names loaded:- {}".format(len(names)))
        os.chdir(str(self.django_path)+"/student_list")
        logger.warn("Crawling Started!")
        os.system(f'scrapy crawl list -a names="{url_list[:-1]}"')
        logger.warn("Crawling Completed!")