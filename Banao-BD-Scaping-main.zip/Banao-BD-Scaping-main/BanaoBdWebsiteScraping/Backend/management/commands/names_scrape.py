from django.core.management.base import BaseCommand, CommandError
import logging, coloredlogs
from flair.data import Sentence
from flair.models import SequenceTagger
from bs4 import BeautifulSoup
from  fake_useragent import UserAgent
from matplotlib.pyplot import text
import requests
logger = logging.getLogger(__name__)
coloredlogs.install(logger=logger)
import re
from Backend.models import WebsiteUrl, PeopleName
import time

class Command(BaseCommand):
    help = 'Names extracting command'

    def add_arguments(self, parser):
        parser.add_argument('--limit',nargs=1,type=int)

    def get_prev_num(self,array,current_pos):
        for i in range(15):
            text_line = array[current_pos - i]
            numbers = re.findall(r'\d{6,20}',text_line)
            if len(numbers)>0:
                return numbers[0]
        return None

    def get_next_num(self,array,current_pos):
        for i in range(15):
            text_line = array[current_pos + i]
            numbers = re.findall(r'\d{6,20}',text_line)
            if len(numbers)>0:
                return numbers[0]
        return None

    def handle(self, *args, **options): 
        limit=50 
        if(options['limit']):
            limit=options['limit'][0]
        self.department_l = ['cse','mec', 'mechanical', 'electrical', 'ece', 'civ', 'aero', 'che', 'marine', 'petrolium', 'industriul', 'bio', 'material', 'mca', 'bca' 'cer', 'apd', 'eee', 'met', 'min', 'mst', 'bce', 'bme', 'app', 'mat']
        tagger = SequenceTagger.load('ner')
        urls = WebsiteUrl.objects.filter(people_scarped=False).order_by('-website_domain__priority')[:limit]
        for url in urls:
            self.scrape(url,tagger)
            url.people_scarped = True
            url.save()
            time.sleep(5)
            # break

    def scrape(self, url_ins, tagger):
        try:
            designations_list=['Faculty','Staff','Student','Dean','Proctor','Director',]
            facutly_titles=['Dr.','Prof.','Ar.']
            url = url_ins.url
            temp_url=url.replace('/',' ')
            print(url)
            designation=None
            for element in designations_list:
                if element in temp_url.title():
                    designation=element
            soup=BeautifulSoup(requests.get('http://'+url, timeout=20,headers={'User-Agent':UserAgent().random}).content,'html.parser',from_encoding="iso-8859-1")
            content_text=soup.get_text(separator='\n').title()
            department=None
            try:
                department=None
                for element in self.department_l:
                    if element.lower() in temp_url.lower():
                        department=element
                        break
            except:
                department = re.findall("DEPARTMENT OF (.*)",content_text, re.IGNORECASE)[0].split(" ")[0]
            if not department:
                try:
                    department = re.findall("DEPARTMENT OF (.*)",content_text, re.IGNORECASE)[0].split(" ")[0]
                except:
                    if not department:
                        department = None
            print(department)
            pos = 0
            for text_line in content_text.split("\n"): 
                # try:
                #     department = re.findall("DEPARTMENT OF (.*)",text_line, re.IGNORECASE)[0].split(" ")[0]
                # except:
                #     pass
                pos += 1
                text_line=text_line.strip().split(",")[0]
                if(len(text_line)==0 or len(text_line.split(" "))>8):
                    continue
                sentence = Sentence(text_line)
                tagger.predict(sentence)
                for entity in sentence.get_spans('ner'):
                    if entity.tag=='PER': 
                        for element in designations_list:
                            if element in text_line.title():
                                designation=element
                        if len(text_line.split(" ")) > 1:
                            prev = self.get_prev_num(content_text.split("\n"), pos - 1)
                            next = self.get_next_num(content_text.split("\n"), pos - 1)
                            for element in facutly_titles:
                                if element in text_line.title():
                                    designation='Faculty'
                            print(designation)
                            if not PeopleName.objects.filter(name=text_line, roll=prev, roll1=next, department=department, url=url_ins, designation=designation).exists():
                                people_name_ins = PeopleName(name=text_line, roll=prev, roll1=next, department=department, url=url_ins, designation=designation)
                                people_name_ins.save()
        except Exception as e :
            logger.error("Failed to add url in Website table, Reason For Failure: {}".format(e))
        