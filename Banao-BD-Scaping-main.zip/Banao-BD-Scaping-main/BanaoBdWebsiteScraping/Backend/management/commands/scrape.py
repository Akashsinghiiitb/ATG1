from django.core.management.base import BaseCommand, CommandError
from Backend.models import Website,WebsiteUrl,People, PeopleName
from pathlib import Path
from flair.models import SequenceTagger
from flair.data import Sentence
from bs4 import BeautifulSoup
from PIL import Image
from  fake_useragent import UserAgent
from pdf2image import convert_from_path
import pandas as pd
import pytesseract
import re
import requests
import logging, coloredlogs
import os
import time
from matplotlib.pyplot import text
logger = logging.getLogger(__name__)
coloredlogs.install(logger=logger)


class Command(BaseCommand):
    help = 'Scrape Pages of Specified WebSite'

    def add_arguments(self, parser):
        parser.add_argument('--limit',nargs=1,type=int)
    
    def handle(self, *args, **options):
        obj=Scraping()
        limit=50
        if(options['limit']):
            limit=options['limit'][0]
        urls=WebsiteUrl.objects.filter(scraped_status=False).order_by('-website_domain_priority')[:limit]
        if(len(urls)==0):
            logger.info("There's no url left to scrape")
            return
        else:
            logger.warn("number of urls loaded:- {}".format(len(urls)))
            logger.warn("Scraping Started!")
            for url in urls:
                logger.warn('Scrape started for: {}'.format(url.url))
                try:
                    obj.scraping(url)
                except Exception as e:
                    logger.error("Error ocurred while scraping: {}".format(e))
                logger.warn("Scraped url:- {}".format(url.url))
                url.scraped_status=True
                url.save()
            logger.warn("Scraping Completed!")




class Scraping:
    titles={"Mr.","Mrs.","Miss","Dr.","Prof.","Ms.","Lady","Sir",'Shri','Shrimati','Kumari','Kumar','Sister'}
    designations_list=['Faculty','Staff','Student','Dean','Proctor','Director',]
    facutly_titles=['Dr.','Prof.','Ar.']
    department_l = ['cse','mec', 'mechanical', 'electrical', 'ece', 'civ', 'aero', 'che', 'marine', 'petrolium', 'industriul', 'bio', 'material', 'mca', 'bca' 'cer', 'apd', 'eee', 'met', 'min', 'mst', 'bce', 'bme', 'app', 'mat']
    headers = {"User-Agent":"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36"}
    def __init__(self):
        self.tagger = SequenceTagger.load('ner')

    def get_prev_num(self,array,current_pos):
        for i in range(15):
            text_line = array[current_pos - i]
            numbers = re.findall(r'\d{6,20}',text_line)
            if len(numbers)>0:
                return numbers[0]
        return None
    
    

    def get_next_num(self,array,current_pos):
        for i in range(15):
            text_line = array[current_pos + i]
            numbers = re.findall(r'\d{6,20}',text_line)
            if len(numbers)>0:
                return numbers[0]
        return None

    def scraping(self,urlObj):
        if urlObj.is_pdf==True:
            self.pdf_converter(urlObj)
        else:
            self.url=urlObj.url
            temp_url=urlObj.url.replace('/',' ')
            designation=None
            for element in self.designations_list:
                if element in temp_url.title():
                    designation=element
            
            soup=BeautifulSoup(requests.get('http://'+self.url, timeout=20,headers=self.headers).content,'html.parser',from_encoding="iso-8859-1")
            try:
                self.recursion(soup.find('body'),designation)
                self.scrape(urlObj)
            except Exception as e:
                logger.warn("Error ocurred in recursion method {}".format(e))


    def pdf_converter(self,urlObj):
        link="https://"+urlObj.url
        response = requests.get(link, timeout=20,headers=self.headers)
        pdf = open("File.pdf", 'wb')
        pdf.write(response.content)
        pdf.close()

        pages = convert_from_path("File.pdf",poppler_path="C:/Users/abhis/data/Atg/poppler-0.68.0/bin")
        os.remove('File.pdf')
        image_counter = 1
        pdfReaderFilesPath=Path.joinpath(Path(__file__).resolve().parent.parent.parent,'PdfReaderFiles')
        for page in pages:
            filename = "page_"+str(image_counter)+".jpg"
            page.save(Path.joinpath(pdfReaderFilesPath, filename), 'JPEG')
            image_counter = image_counter + 1

        filelimit = image_counter-1
        outfile = "output.csv"
        f = open(Path.joinpath(pdfReaderFilesPath, outfile), "a")
        for i in range(1, filelimit + 1):
            filename = "page_"+str(i)+".jpg"
            text = str(((pytesseract.image_to_string(Image.open(Path.joinpath(pdfReaderFilesPath, filename))))))
            text = text.replace('-\n', '')	
            f.write(text)
        f.close()
        a = pd.read_csv(Path.joinpath(pdfReaderFilesPath, outfile),encoding = 'cp1252',on_bad_lines='skip')
        a.to_html(Path.joinpath(pdfReaderFilesPath, "output.html"))
        temp_url=urlObj.url.replace('/',' ')
        designation=None
        for element in self.designations_list:
            if element in temp_url.title():
                designation=element
        with open(Path.joinpath(pdfReaderFilesPath, "output.html"), encoding="utf-8") as f:
            data = f.read()
            soup = BeautifulSoup(data, 'html.parser')
        try:
            self.recursion(soup,designation)
        except Exception as e:
            logger.warn("Error ocurred in recursion method {}".format(e))   

        filelist = [ f for f in os.listdir(pdfReaderFilesPath) ]
        for f in filelist:  
            os.remove(os.path.join(pdfReaderFilesPath, f))
        urlObj.crawled_status=True
        urlObj.save()


    def recursion(self,soup,designation):
        content_text=soup.get_text(separator='\n').title()
        for element in self.designations_list:
            if element in content_text:
                designation=element
                break
        emails=re.findall(r'[\w.+-]+@[\w-]+\.[\w.-]+',content_text)
        if(len(emails)==0):
            return
        if(len(emails)==1):
            email=emails[0].lower()
            name=None
            name_confirm=False
            for text_line in content_text.split("\n"): 
                text_line=text_line.strip().split(",")[0]
                if(len(text_line)==0 or emails[0] in text_line or len(text_line.split(" "))>8):
                    continue
                if(text_line.split(" ")[0] in self.titles):
                    name=text_line
                    break
                sentence = Sentence(text_line)
                self.tagger.predict(sentence)
                for entity in sentence.get_spans('ner'):
                    if entity.tag=='PER': 
                        for k in text_line.split(" "):
                            if(k.lower() in email.split("@")[0]):
                                name=text_line
                                name_confirm=True
                                break
                        if(name_confirm):
                            break
                        name=text_line
                if(name_confirm):
                    break
            numbers=re.findall(r'[\+\(]?[1-9][0-9 .\-\(\)]{8,}[0-9]',content_text)
            if(len(numbers)==0):
                number=None
            else:
                number=numbers[0]
            if name !=None and name.split(" ")[0] in self.facutly_titles:
                designation='Faculty'
            if not People.objects.filter(email=email).exists():
                People.objects.create(email=email,url=WebsiteUrl.objects.get(url=self.url),name=name,number=number,designation=designation)
            else:
                obj=People.objects.get(email=email)
                if(name!=None):
                    obj.name=name
                if(designation!=None):
                    obj.designation=designation
                if(number!=None):
                    obj.number=number
                obj.save()  
                if name==None:
                    return  
        for child in soup.find_all(recursive=False):
            self.recursion(child,designation)

    def scrape(self, url_ins):
        try:
            designations_list=['Faculty','Staff','Student','Dean','Proctor','Director',]
            facutly_titles=['Dr.','Prof.','Ar.']
            url = url_ins.url
            temp_url=url.replace('/',' ')
            print(url)
            designation=None
            for element in designations_list:
                if element in temp_url.title():
                    designation=element
            soup=BeautifulSoup(requests.get('http://'+url, timeout=20,headers={'User-Agent':UserAgent().random}).content,'html.parser',from_encoding="iso-8859-1")
            content_text=soup.get_text(separator='\n').title()
            department=None
            try:
                department=None
                for element in self.department_l:
                    if element.lower() in temp_url.lower():
                        department=element
                        break
            except:
                department = re.findall("DEPARTMENT OF (.*)",content_text, re.IGNORECASE)[0].split(" ")[0]
            if not department:
                try:
                    department = re.findall("DEPARTMENT OF (.*)",content_text, re.IGNORECASE)[0].split(" ")[0]
                except:
                    if not department:
                        department = None
            print(department)
            pos = 0
            for text_line in content_text.split("\n"): 
                # try:
                #     department = re.findall("DEPARTMENT OF (.*)",text_line, re.IGNORECASE)[0].split(" ")[0]
                # except:
                #     pass
                pos += 1
                text_line=text_line.strip().split(",")[0]
                if(len(text_line)==0 or len(text_line.split(" "))>8):
                    continue
                sentence = Sentence(text_line)
                self.tagger.predict(sentence)
                for entity in sentence.get_spans('ner'):
                    if entity.tag=='PER': 
                        for element in designations_list:
                            if element in text_line.title():
                                designation=element
                        if len(text_line.split(" ")) > 1:
                            prev = self.get_prev_num(content_text.split("\n"), pos - 1)
                            next = self.get_next_num(content_text.split("\n"), pos - 1)
                            for element in facutly_titles:
                                if element in text_line.title():
                                    designation='Faculty'
                            print(designation)
                            if not PeopleName.objects.filter(name=text_line, roll=prev, roll1=next, department=department, url=url_ins, designation=designation).exists():
                                people_name_ins = PeopleName(name=text_line, roll=prev, roll1=next, department=department, url=url_ins, designation=designation)
                                people_name_ins.save()
        except Exception as e :
            logger.error("Failed to add url in Website table, Reason For Failure: {}".format(e))
        