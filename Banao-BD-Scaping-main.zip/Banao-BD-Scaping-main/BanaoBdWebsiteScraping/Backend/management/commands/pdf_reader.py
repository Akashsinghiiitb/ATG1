from django.core.management.base import BaseCommand, CommandError
import pytesseract
from Backend.models import Website,WebsiteUrl,People
from flair.data import Sentence
from flair.models import SequenceTagger
from bs4 import BeautifulSoup
import re
from PIL import Image
import requests
import logging, coloredlogs
from  fake_useragent import UserAgent
from pdf2image import convert_from_path
import os
import pandas as pd
from pathlib import Path
logger = logging.getLogger(__name__)
coloredlogs.install(logger=logger)


class Command(BaseCommand):
    help = 'Used to extract data from pdf'

    def add_arguments(self, parser):
        parser.add_argument('--limit',nargs=1,type=int)
    
    def handle(self, *args, **options):
        limit=1
        if(options['limit']):
            limit=options['limit'][0]
        urls=WebsiteUrl.objects.filter(crawled_status=False,is_pdf=True).order_by('-website_domain_priority')[:limit]
        headers = {"User-Agent":"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36"}
        for url in urls:
            link="https://"+url.url

            response = requests.get(link, timeout=20,headers=headers)
    
            pdf = open(r"File.pdf", 'wb')
            pdf.write(response.content)
            pdf.close()

            pages = convert_from_path("File.pdf",poppler_path=r"C:/Users/abhis/data/Atg/poppler-0.68.0/bin")
            os.remove(r'File.pdf')
            image_counter = 1
            pdfReaderFilesPath=Path.joinpath(Path(__file__).resolve().parent.parent.parent,'PdfReaderFiles')
            for page in pages:
                filename = "page_"+str(image_counter)+".jpg"
                page.save(Path.joinpath(pdfReaderFilesPath, filename), 'JPEG')
                image_counter = image_counter + 1

            filelimit = image_counter-1
            outfile = "output.csv"
            f = open(Path.joinpath(pdfReaderFilesPath, outfile), "a")
            for i in range(1, filelimit + 1):
                filename = "page_"+str(i)+".jpg"
                text = str(((pytesseract.image_to_string(Image.open(Path.joinpath(pdfReaderFilesPath, filename))))))
                text = text.replace('-\n', '')	
                f.write(text)
            f.close()
            a = pd.read_csv(Path.joinpath(pdfReaderFilesPath, outfile),encoding = 'cp1252',on_bad_lines='skip')
            a.to_html(Path.joinpath(pdfReaderFilesPath, "output.html"))
            obj=Scraping()
            logger.warn("Scraping Started!")
            obj.scraping(pdfReaderFilesPath,url)
            logger.warn("Scraping Completed!")
            filelist = [ f for f in os.listdir(pdfReaderFilesPath) ]
            for f in filelist:  
                os.remove(os.path.join(pdfReaderFilesPath, f))
            url.crawled_status=True
            url.scraped_status=True
            url.save()

class Scraping:
    titles={"Mr.","Mrs.","Miss","Dr.","Prof.","Ms.","Lady","Sir",'Shri','Shrimati','Kumari','Kumar','Sister'}
    designations_list=['Faculty','Staff','Student','Dean','Proctor','Director',]
    facutly_titles=['Dr.','Prof.','Ar.']
    def __init__(self):
        self.tagger = SequenceTagger.load('ner')
    def scraping(self,pdfReaderFilesPath,url):
        designation=None
        self.url=url
        with open(Path.joinpath(pdfReaderFilesPath, "output.html"), encoding="utf-8") as f:
            data = f.read()
            soup = BeautifulSoup(data, 'html.parser')
        try:
            self.recursion(soup,designation)
        except Exception as e:
            logger.warn("Error ocurred in recursion method {}".format(e))

    def recursion(self,soup,designation):
        content_text=soup.get_text(separator='\n').title()
        for element in self.designations_list:
            if element in content_text:
                designation=element
                break
        emails=re.findall(r'[\w.+-]+@[\w-]+\.[\w.-]+',content_text)
        if(len(emails)==0):
            return
        if(len(emails)==1):
            email=emails[0].lower()
            name=None
            name_confirm=False
            for text_line in content_text.split("\n"): 
                text_line=text_line.strip().split(",")[0]
                if(len(text_line)==0 or emails[0] in text_line or len(text_line.split(" "))>8):
                    continue
                if(text_line.split(" ")[0] in self.titles):
                    name=text_line
                    break
                sentence = Sentence(text_line)
                self.tagger.predict(sentence)
                for entity in sentence.get_spans('ner'):
                    if entity.tag=='PER': 
                        for k in text_line.split(" "):
                            if(k.lower() in email.split("@")[0]):
                                name=text_line
                                name_confirm=True
                                break
                        if(name_confirm):
                            break
                        name=text_line
                if(name_confirm):
                    break
            numbers=re.findall(r'[\+\(]?[1-9][0-9 .\-\(\)]{8,}[0-9]',content_text)
            if(len(numbers)==0):
                number=None
            else:
                number=numbers[0]
            if name !=None and name.split(" ")[0] in self.facutly_titles:
                designation='Faculty'
            if not People.objects.filter(email=email).exists():
                People.objects.create(email=email,url=self.url,name=name,number=number,designation=designation)
            else:
                obj=People.objects.get(email=email)
                if(name!=None):
                    obj.name=name
                if(designation!=None):
                    obj.designation=designation
                if(number!=None):
                    obj.number=number
                obj.save()  
                if name==None:
                    return  
        for child in soup.find_all(recursive=False):
            self.recursion(child,designation)
