from django.core.management.base import BaseCommand, CommandError
from Backend.models import Website,WebsiteUrl
import os
from pathlib import Path
import requests
import logging, coloredlogs
logger = logging.getLogger(__name__)
coloredlogs.install(logger=logger)

class Command(BaseCommand):
    help = 'Crawl Pages of Specified WebSite'
    django_path = Path(__file__).resolve().parent.parent.parent.parent
    def add_arguments(self, parser):
        parser.add_argument('--limit',nargs=1,type=int)
    
    def handle(self, *args, **options):
        limit=200
        if(options['limit']):
            limit=options['limit'][0]
        urls=WebsiteUrl.objects.filter(crawled_status=False,is_pdf=False).order_by('-website_domain_priority')[:limit]
        if(len(urls) == 0):
            logger.warn("No Website URLs Left. Trying to get one from Webiste Table.")
            url=Website.objects.filter(crawled_status=False).order_by('-priority').first()
            if(url==None):
                logger.warn("There's no url left to crawl")
                return
            # full_url= requests.get('http://{}'.format(url.url)).url
            WebsiteUrl.objects.create(url=url.url,website_domain=url)
            url.crawled_status=True
            url.save()
            urls=WebsiteUrl.objects.filter(crawled_status=False, website_domain=url).order_by('-website_domain__priority')[:limit]
        urls_list=''
        logger.warn("number of urls loaded:- {}".format(len(urls)))
        for url in urls:
            urls_list+=str('http://'+url.url)+','
        os.chdir(str(self.django_path)+"/Scrapy")
        logger.warn("Crawling Started!")
        os.system(f'scrapy crawl Crawling -a urls_list="{urls_list[:-1]}"')
        logger.warn("Crawling Completed!")
