# BanaoBdWebsiteScraping

### 1.Command for crawling urls from database
```
python manage.py crawl --limit 50 // limit is optional
```
### 2.Command for Scraping urls from database
```
python manage.py scrape --limit 50 // limit is optional
```
### 3.Command for adding domain in database
```
python manage.py addurl <url>
```
### 4.Api Endpoint for getting excel file of people
```
http://3.108.44.173/api/people_data?token=token_name&limit=limit_value
```
### 5.Api Endpoint for getting Website Urls.
```
http://3.108.44.173/api/website_data
```
### 6.Command for Scraping merit list url from google
```
python manage.py student_list --limit 50 // limit is optional
```
