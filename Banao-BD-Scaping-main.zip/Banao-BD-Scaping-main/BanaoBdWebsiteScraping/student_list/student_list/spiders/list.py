import scrapy
from scrapy.selector import Selector
import time 
import urllib.request  
import logging
from scrapy_selenium import SeleniumRequest
from student_list.items import StudentListItem
import coloredlogs
logger = logging.getLogger(__name__)
coloredlogs.install(logger=logger)

logging.getLogger('scrapy').propagate = logger
logging.getLogger('selenium').propagate = logger
logging.getLogger('urllib3').propagate = logger

url_list=[]
website_domain=[]

class ListSpider(scrapy.Spider):
    name = 'list' 
    start_urls = ['https://www.google.com/']   
    
    def __init__(self,*args,**kwargs):
        names = kwargs.get('names').split(',')
        logger.warn(names)
        for name in names:
            website_domain.append(name)
            params = {'q':name}
            url = f'https://www.google.com/search?{urllib.parse.urlencode(params)}'
            url_list.append(url)
        super(ListSpider, self).__init__( *args,**kwargs)
    
    def parse(self, response):
        item = StudentListItem()
        url = url_list[0]
        url_list.remove(url)
        name = website_domain[0]
        website_domain.remove(name)
        item['website_domain'] = name
        urls=[]
        yield SeleniumRequest(url=url,callback=self.parse_data,meta={'urls':urls,'item':item},dont_filter=True)

    def parse_data(self, response):
        urls = response.request.meta['urls']
        item = response.request.meta['item']
        html = response.request.meta['driver'].page_source
        data = Selector(text=html)
        for i in data.xpath("//div[@class='yuRUbf']/a"):
            href = i.xpath("./@href").get()
            if 'merit' in href or 'admission' in href  or 'list' in href:
                urls.append(href)
        u = data.xpath("//a[@id='pnnext']/@href").extract()
        if u:
            url = 'https://www.google.com'+u[0]
            time.sleep(1)
            yield SeleniumRequest(url=url,meta={'urls':urls,'item':item},callback=self.parse_data,dont_filter = True)
        else:
            for i in urls:
                is_pdf = False
                if 'pdf' in i:
                    is_pdf = True
                item['urls'] = i
                item['is_pdf'] = is_pdf
                yield item
            if(len(url_list)>0):
                yield SeleniumRequest(url='https://www.google.com/',callback=self.parse,dont_filter=True)

