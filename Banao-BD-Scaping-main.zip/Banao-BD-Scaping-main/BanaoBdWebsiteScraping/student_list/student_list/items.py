# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class StudentListItem(scrapy.Item):
    urls = scrapy.Field()
    website_domain = scrapy.Field()
    is_pdf = scrapy.Field()
