# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
from Backend.models import WebsiteUrl,Website
from .items import WebsiteItem,ScrapyItem

import logging, coloredlogs
logger = logging.getLogger(__name__)
coloredlogs.install(level="WARN", logger=logger)

class StudentListPipeline:
    def process_item(self, item, spider):
        try:
            WebsiteUrl.objects.create(website_domain=Website.objects.get(name=item['domain']), url=item['urls'],is_pdf=item['is_pdf'])
            logger.warn("added url:- {}".format(item['url']))
        except Exception as e:
            pass
        return item
