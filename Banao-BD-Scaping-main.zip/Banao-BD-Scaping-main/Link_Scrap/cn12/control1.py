import os

import selenium
from scraping.models import Category,SubCategory,State
from database_interaction.jobs_to_database import jobs_to_database

os.chdir('../Linkedin')
print(os.getcwd())
def scr1():
    states = State.objects.all()

    for st in states:

        if st.jobs_searched==0:
            cat = SubCategory.objects.all()






            for s in cat:
                try:
                    os.system(f'scrapy crawl company -a state="{st.name}" -a category="{s.name}"')
                    jobs_to_database(s.name,st.name)
                except:
                    pass

        State.objects.filter(name=st.name).update(jobs_searched=1)



