from django.apps import AppConfig


class ScraperLogsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'scraper_logs'
