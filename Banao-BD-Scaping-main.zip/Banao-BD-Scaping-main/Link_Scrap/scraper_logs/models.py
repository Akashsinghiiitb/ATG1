from django.db import models

# Create your models here.

class scraping_bot_logs(models.Model):
    name = models.CharField(max_length=30)
    updated = models.DateTimeField(auto_now=False, auto_now_add=True)
    description = models.CharField(max_length=100)
    dvalue = models.IntegerField(default=None,null=True)

    def __str__(self):
        return self.name

class ElasticIP(models.Model):
    username= models.CharField(max_length=200)
    password= models.CharField(max_length=200)
    eip_address= models.CharField(max_length=200)
    eip_allocation_id= models.CharField(max_length=200)

    def __str__(self):
        return self.username