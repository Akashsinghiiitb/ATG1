from django.contrib import admin

from .models import scraping_bot_logs, ElasticIP
# Register your models here.

admin.site.register(scraping_bot_logs)
admin.site.register(ElasticIP)
