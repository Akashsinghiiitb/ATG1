import os
from django.core.wsgi import get_wsgi_application
import pandas as pd
import numpy as np
import math


#os.environ.setdefault("DJANGO_SETTINGS_MODULE", "Link_Scrap.settings")

#application = get_wsgi_application()

from scraping.models import Category,SubCategory,Company,State,Jobs



def jobs_to_database(sub,state):
    headers = ['post','company','url','category']
    df = pd.read_csv(f'data/jobs_{state}.csv', names=headers)

    company = np.array(df['company'])
    state = State.objects.filter(name=state)[0]
    #sub_category='software engineer'
    for x in set(company):
        if Company.objects.filter(name=x).count()==0:
            categories = df[df['company']==x]['category']
            categories = set(np.array(categories))
            category = SubCategory.objects.filter(name=sub)[0]
            print(category)
            obj1 = Company(name=x)
            obj1.save()
            obj1.subcategory.add(category)
            obj1.state.add(state)
    #headers = ['post','company','url','category']

    data = np.array(df)
    for i in data:
        if Jobs.objects.filter(url=i[2]).count()==0:
            category = SubCategory.objects.filter(name=sub)[0]
            state = State.objects.filter(name='delhi ncr')[0]
            url = i[2]
            company = Company.objects.filter(name=i[1])[0]
            if math.isnan(i[0]):
                name = sub
            else:
                name=i[0]

            obj2= Jobs(name=name,state=state,company=company,url=url)
            obj2.save()
            obj2.sub_category.add(category)
        else:
            ob = Jobs.objects.filter(url=i[2])[0]
            category = SubCategory.objects.filter(name=sub)[0]
            ob.sub_category.add(category)




