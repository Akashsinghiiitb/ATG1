import os
from django.core.wsgi import get_wsgi_application
import pandas as pd
import numpy as np

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "Link_Scrap.settings")

application = get_wsgi_application()

from scraping.models import Category,SubCategory

def category_to_database():
    df = pd.read_csv("../../Linkedin/data/category.csv")

    category= df['category']
    category=set(category)
    m=0
    for i in category:
        if Category.objects.filter(name=i).count()==0:
            m = Category(name=i)
            m.save()




    df = np.array(df)
    for i in df:
        if SubCategory.objects.filter(name=i[2]).count()==0:
            obj1 = Category.objects.filter(name=i[1])[0]
            obj2= SubCategory(name=i[2],category=obj1)
            obj2.save()


    print(len(SubCategory.objects.all()))

category_to_database()

