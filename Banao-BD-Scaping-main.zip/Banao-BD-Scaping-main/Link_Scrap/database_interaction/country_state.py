from os import name
import pycountry as pc


def transfer(Country, State):
    all_country = pc.countries
    for country in all_country:
        c_code = country.alpha_2
        if Country.objects.filter(name=country.name.lower()).count() == 0:
            c = Country(name=country.name.lower())
            c.save()
            st = pc.subdivisions.get(country_code=c_code)
            for s in st:
                state_name = s.name.lower()
                if State.objects.filter(name=state_name,country=c).count() == 0:
                    s = State(name=state_name,country=c)
                    s.save()
                else:
                    pass
        
        else:
            pass

