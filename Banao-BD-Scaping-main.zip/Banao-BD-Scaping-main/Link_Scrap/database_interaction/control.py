from scraping.models import Category,SubCategory
from database_interaction.jobs_to_database import jobs_to_database
import os


def get_category():
    obj1 = Category.objects.filter(name= 'it or software')[0]
    print(obj1)


    objects = SubCategory.objects.filter(category=obj1)
    os.chdir("../Linkedin")
    print(os.getcwd())
    for x in objects:
        os.system(f'scrapy crawl company -a category="{x.name}"')
        jobs_to_database(x.name)






