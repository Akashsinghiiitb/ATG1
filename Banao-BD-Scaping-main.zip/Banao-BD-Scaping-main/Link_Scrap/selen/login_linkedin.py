import random
import time
from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from scraping.models import LinkedinAccount
from selenium.webdriver.chrome.options import Options
from .find_company2 import get_ip
from scraper_logs.models import ElasticIP

UA_list = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1 Safari/605.1.15"
]
UA = random.choice(UA_list)
chrome_options = Options()
chrome_options.add_argument('--ignore-certificate-errors')
#chrome_options.add_argument("--disable-extensions")
# chrome_options.add_argument('--headless')
chrome_options.add_argument('--no-sandbox')
# chrome_options.add_argument(f"user-agent={UA}")
# chrome_options.add_argument("--start-maximized")






def login():
    ip = get_ip()
    # account = ElasticIP.objects.get(eip_address=ip)
    driver = webdriver.Chrome(executable_path='/usr/local/bin/chromedriver',chrome_options=chrome_options)

    driver.get("https://www.linkedin.com/login")
    username = "jimaba3603@kyrescu.com"
    password = "Atg@123"
    el1=driver.find_element_by_id("username")
    #el1.send_keys("chaitanyamalik1300@gmail.com")
    # el1.send_keys('timeisgod12@gmail.com')
    # el1.send_keys('datepo1395@d3ff.com')  #blocked
    # el1.send_keys('foset53989@epeva.com') # blocked
    # el1.send_keys('fekaxop825@datakop.com')
    # el1.send_keys('widocov466@d3ff.com') # blocked
    el1.send_keys(username)

    el2=driver.find_element_by_id("password")
    #el2.send_keys("chaitanya#1")
    # el2.send_keys("Srsscthr#1")
    el2.send_keys(password)

    str='//*[contains(concat( " ", @class, " " ), concat( " ", "from__button--floating", " " ))]'
    btn = driver.find_element_by_xpath(str)
    btn.click()
    #driver.get('https://in.linkedin.com/company/novotel-hotels')
    #print(driver.page_source)
    #time.sleep(25)




    return driver


def initiate():
    driver = webdriver.Chrome(executable_path='/usr/local/bin/chromedriver',chrome_options=chrome_options)
    return driver
