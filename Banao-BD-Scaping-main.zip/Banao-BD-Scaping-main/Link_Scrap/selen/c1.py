from scraping.models import Category



def st1():
    print(Category.objects.all())