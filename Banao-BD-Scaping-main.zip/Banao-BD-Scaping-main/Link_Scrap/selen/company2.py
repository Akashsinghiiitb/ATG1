import selenium

from selen.login_linkedin import login
from django.db.models import Q
from bs4 import BeautifulSoup

import time
from pprint import pprint
from scraping.models import CompanyDetails,Company,Jobs

import re
def has_numbers(inputString):
    return re.findall(r'\d', inputString)





def web_format(str1):
    str1 = str1.split()

    return '%20'.join(str1)


def make_abut(link):
    keywords=['about','posts','jobs']
    href = link.split('/')

    href=[i for i in href if i !='']
    print(href)
    hrefs = ["https://"+"/".join(href[1:]+[k]) for k in keywords]
    return hrefs



def get1(driver,href):
    driver.get(href)


    str1='//*[contains(concat( " ", @class, " " ), concat( " ", "overflow-hidden", " " ))]'
    dict3={}
    elements = driver.find_element_by_xpath(str1)

    head =elements.find_elements_by_xpath('//dt')
    attach = elements.find_elements_by_xpath("//dd")
    heads=[h.text for h in head]
    attachs=[a.text for a in attach]
    #print(heads)
    #print(attachs)

    ind = heads.index('Company size')

    print(ind)

    for i in range(ind):
        dict3[heads[i]]=attachs[i]
    m=-1
    for i in reversed(range(ind,len(heads))):

        dict3[heads[i]]=attachs[m]
        m=m-1

    n=has_numbers(dict3['Company size'])
    dict3['Company size']= int(''.join(n))


    description_str='//*[contains(concat( " ", @class, " " ), concat( " ", "mb5", " " )) and contains(concat( " ", @class, " " ), concat( " ", "t-normal", " " ))]'
    dict3['description']=driver.find_element_by_xpath(description_str).text


    return driver,dict3







def get2(driver,href):

    driver.get(href)

    jobs_str = '//*[contains(concat( " ", @class, " " ), concat( " ", "js-focusable-card", " " ))]'

    elements = driver.find_elements_by_xpath(jobs_str)
    print(elements)

    for e in elements:
        features=e.text.split('\n')
        print(f"hi ets  {features}")


    return driver


def company_page(name,driver):




    try:

        print("called at 2")
        driver, folll, href = company_page9(name, driver)

    except :
        url = f'https://www.linkedin.com/search/results/companies/?keywords={web_format(name.lower())}'
        driver.get(url)
        str1='//*[contains(concat( " ", @class, " " ), concat( " ", "mb2", " " )) and (((count(preceding-sibling::*) + 1) = 2) and parent::*)]//*[contains(concat( " ", @class, " " ), concat( " ", "t-black--light", " " ))]'
        element = driver.find_elements_by_xpath(str1)

        print(element)
        #features = element[0].text.split('\n')
        href = element[0].find_element_by_css_selector('a').get_attribute('href')
        #print(features)



        followers_str = '//*[contains(concat( " ", @class, " " ), concat( " ", "reusable-search__result-container", " " )) and (((count(preceding-sibling::*) + 1) = 1) and parent::*)]//*[contains(concat( " ", @class, " " ), concat( " ", "entity-result__secondary-subtitle", " " ))]'

        folll = driver.find_element_by_xpath(followers_str)
        folll=folll.text

        print("called at 1")






    hrefs= make_abut(href)
    print(hrefs)

    keywords = ['about', 'posts', 'jobs']
    driver,dict3 =get1(driver,hrefs[0])
    dict3['followers'] = folll.split()[0]

    #driver =get2(driver,hrefs[2])

    lis3=['Company size','Founded','description','Type','followers','Industry','Website','Headquarters','phone','Specialties']
    keys = list(dict3)
    for l in lis3:
        if l not in list(dict3):
            if l=='Founded':
                dict3[l]=0
            else:
                dict3[l]=''


    pprint(dict3,indent=2,width=150)






    if  Company.objects.filter(name=name).count()==0:
        comp1= Company(name=name)
        comp1.save()
    else:
        comp1=Company.objects.filter(name=name)[0]

    m_mod = ['company', 'headquarters', 'description', 'founded', 'industry', 'website', 'company_size', 'type',
             'specialities', 'followers', 'phone']

    if CompanyDetails.objects.filter(company=comp1).count()==0:

        obj_m= CompanyDetails(
            company = comp1,
            headquarters=dict3['Headquarters'],
            description=dict3['description'],
            founded= dict3['Founded'],
            industry= dict3['Industry'],
            website = dict3['Website'],
            company_size=dict3['Company size'],
            type= dict3['Type'],
            specialities=dict3['Specialties'],
            followers=dict3['followers'],
            phone=dict3['phone']


        )

        obj_m.save()
        print("saved")
    else:
        if CompanyDetails.objects.filter(company=comp1,description__isnull=False).count()==0:
            CompanyDetails.objects.filter(company=comp1).update(
                company=comp1,
                headquarters=dict3['Headquarters'],
                description=dict3['description'],
                founded=dict3['Founded'],
                industry=dict3['Industry'],
                website=dict3['Website'],
                company_size=dict3['Company size'],
                type=dict3['Type'],
                specialities=dict3['Specialties'],
                followers=dict3['followers'],
                phone=dict3['phone']

            )


    return driver


def company_page9(name,driver):

    comp = Company.objects.filter(name=name)[0]
    try:
        job_obj = Jobs.objects.filter(company=comp)[0]
        url = job_obj.url.split('?')[0]
        print("jobs database")
    except:
        obj =CompanyDetails.objects.filter(company=comp)[0]
        url =obj.linkedin_url
        print("dtails database")

    print(url)


    driver.get(url)

    followers = "//div[1]//div[2]//main[1]//div[1]//section[1]//div[1]//div[2]//div[1]//div[1]//div[2]//div[1]//div[1]//div[2]//div[2]"

    followers =driver.find_element_by_xpath(followers).text





    return driver,followers,url





