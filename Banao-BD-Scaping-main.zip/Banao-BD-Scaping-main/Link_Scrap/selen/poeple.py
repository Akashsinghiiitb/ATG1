from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from scraping.models import Search_Urls,Company,State,People
import time
from bs4 import BeautifulSoup
import re
from django.db.models import Q





#driver = webdriver.Chrome(ChromeDriverManager().install())


def save_details(company,driver):

    comp= Company.objects.filter(name=company)[0]
    objects = Search_Urls.objects.filter(company=comp.id)
    print(objects)

    res = 1

    for o in objects:
        try :
            url= o.name.split('?')[0]
            driver.get(url)
            print(url)
            print(o.name)
            dict1={}



            name_str = '//*[contains(concat( " ", @class, " " ), concat( " ", "v-align-middle", " " )) and contains(concat( " ", @class, " " ), concat( " ", "break-words", " " ))]'
            name = driver.find_element_by_xpath(name_str)
            dict1['name']=name.text


            try:
                company_str = "//div[@aria-label='Current company']"
                company = driver.find_element_by_xpath(company_str)
                dict1['company'] =company.text
            except:
                print("Unable to find current company")
                pass

            try:
                position_str = '//*[contains(concat( " ", @class, " " ), concat( " ", "text-body-medium", " " ))]'
                position = driver.find_element_by_xpath(position_str)
                dict1['position']=position.text
            except:
                pass


            state_str="//span[@class='text-body-small inline t-black--light break-words']"

            state = driver.find_element_by_xpath(state_str)
            state_l = state.text.lower().split()
            if len(state_l) == 1:
                states = State.objects.filter(name__icontains=state_l[0])
            elif len(state_l) == 2:
                states = State.objects.filter(Q(name__icontains=state_l[0]) | Q(name__icontains=state_l[1]))
            elif len(state_l) == 3:
                states = State.objects.filter(Q(name__icontains=state_l[0]) | Q(name__icontains=state_l[1]) | Q(name__icontains=state_l[2]))
            elif len(state_l) > 3:
                states = State.objects.filter(Q(name__icontains=state_l[0]) | Q(name__icontains=state_l[1]) | Q(name__icontains=state_l[2]) | Q(name__icontains=state_l[3]))
            else:
                states = []
            if len(states) > 0:
                dict1['state']=states[0]
                print(dict['state'])
            

            button_str ="//a[normalize-space()='Contact info']"
            btn = driver.find_element_by_xpath(button_str)
            btn.click()
            time.sleep(2)

            try:
                contact_str="//div[@class='pv-profile-section__section-info section-info']"
                contact = driver.find_element_by_xpath(contact_str)
                dict1['contact']=contact.text
            except:
                pass





            list1=['company','position','state','contact']

            for l in list1:
                if l not in list(dict1):
                    dict1[l]=''
            print(dict1['company'].lower(),'----',o.company.name.lower())
            if dict1['company'].lower() == o.company.name.lower():
                print("company matched")
                company = Company.objects.filter(name=o.company.name)[0]
                c = People.objects.filter(name=dict1['name'],company=company).count()
                print(c)
                if c==0:
                    print(company)
                    if dict1['state']=='':
                        obj_main = People(name=dict1['name'], position=dict1['position'], contact_info=dict1['contact'],
                                          url=o, company=company)
                    else:
                        obj_main = People(name=dict1['name'],position=dict1['position'],contact_info=dict1['contact'],url=o,state=dict1['state'],company=company)
                    obj_main.save()
        except Exception as e:
            print(e)
            res = res + 1
            pass
        time.sleep(10)
    if res >= len(objects):
        res = 0
    return driver, res



