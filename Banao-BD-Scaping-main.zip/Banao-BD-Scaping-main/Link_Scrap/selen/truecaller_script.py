from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from selenium.common.exceptions import TimeoutException
import time
from selenium.webdriver.chrome.options import Options

delay = 10

accounts = [
    {
        "username": "bomege5509@bomoads.com",
        "password": "Atg@54321",
        "method" : "microsoft"
    },
    {
        "username": "notoroh496@jesdoit.com",
        "password": "Atg@54321",
        "method" : "microsoft"
    },
    {
        "username": "viwifef419@jesdoit.com",
        "password": "Atg@54321",
        "method" : "microsoft"
    },
    {
        "username": "laxawoy906@fretice.com",
        "password": "Atg@54321",
        "method" : "microsoft"
    },
    {
        "username": "jewitik781@d3bb.com",
        "password": "Atg@54321",
        "method" : "microsoft"
    },
]

def start_browser():
    s=Service(ChromeDriverManager().install())
    options = Options()
    options.headless = True
    driver = webdriver.Chrome(service=s,options=options)
    driver.maximize_window()
    driver.get('https://www.truecaller.com/')
    return driver


def truecaller_sign_in(driver,method,username,password):
    try:
        myElem = WebDriverWait(driver, delay).until(EC.element_to_be_clickable((By.XPATH, '//*[@id="side-nav"]/div[1]/a[1]')))
        print("Sign In - Ready to click")
        # driver.find_element(By.XPATH, '//*[@id="side-nav"]/div[1]/a[1]').click()
        driver.get("https://www.truecaller.com/auth/sign-in")
    except TimeoutException:
        print("Loading took too much time!")
        driver.get("https://www.truecaller.com/auth/sign-in")
    if method == "microsoft":
        driver = method_ms(driver,username,password)
    elif method == "google":
        print("for now google login is not working")
        # driver = method_google(driver)
    return driver

def method_google(driver):
    try:
        myElem = WebDriverWait(driver, delay).until(EC.presence_of_element_located((By.XPATH, '/html/body/div/main/div/a[1]')))
        print("Page is ready!")
    except TimeoutException:
        print("Loading took too much time!")
    driver.find_element(By.XPATH, "/html/body/div/main/div/a[1]").click()
    time.sleep(1)
    try:
        myElem = WebDriverWait(driver, delay).until(EC.presence_of_element_located((By.NAME, "identifier")))
        print("Page is ready!")
    except TimeoutException:
        print("Loading took too much time!")
    driver.find_element(By.NAME, "identifier").send_keys('bestday110@gmail.com')
    driver.find_element(By.NAME, "identifier").send_keys(Keys.ENTER)
    time.sleep(3)
    try:
        myElem = WebDriverWait(driver, delay).until(EC.presence_of_element_located((By.ID, "i0118")))
        print("Page is ready!")
    except TimeoutException:
        print("Loading took too much time!")
    driver.find_element(By.ID, "i0118").send_keys('Atg@54321')
    driver.find_element(By.ID, "i0118").send_keys(Keys.ENTER)
    try:
        myElem = WebDriverWait(driver, delay).until(EC.presence_of_element_located((By.ID, "idSIButton9")))
        print("Page is ready!")
    except TimeoutException:
        print("Loading took too much time!")
    driver.find_element(By.ID, "idSIButton9").click()
    return driver


def method_ms(driver,username,password):
    try:
        myElem = WebDriverWait(driver, delay).until(EC.presence_of_element_located((By.XPATH, '/html/body/div/main/div/a[2]')))
        print("Page is ready!")
    except TimeoutException:
        print("Loading took too much time!")
    driver.find_element(By.XPATH, "/html/body/div/main/div/a[2]").click()
    time.sleep(1)
    try:
        myElem = WebDriverWait(driver, delay).until(EC.presence_of_element_located((By.NAME, "loginfmt")))
        print("Page is ready!")
    except TimeoutException:
        print("Loading took too much time!")
    driver.find_element(By.NAME, "loginfmt").send_keys(username)
    driver.find_element(By.NAME, "loginfmt").send_keys(Keys.ENTER)
    time.sleep(3)
    try:
        myElem = WebDriverWait(driver, delay).until(EC.presence_of_element_located((By.ID, "i0118")))
        print("Page is ready!")
    except TimeoutException:
        print("Loading took too much time!")
    driver.find_element(By.ID, "i0118").send_keys(password)
    driver.find_element(By.ID, "i0118").send_keys(Keys.ENTER)
    try:
        myElem = WebDriverWait(driver, delay).until(EC.presence_of_element_located((By.ID, "idSIButton9")))
        print("Page is ready!")
    except TimeoutException:
        print("Loading took too much time!")
    driver.find_element(By.ID, "idSIButton9").click()
    return driver


def search(driver, number,i,accounts=accounts):
    print(number)
    driver.find_element(By.XPATH, "//form/input[1]").send_keys(Keys.CONTROL + "a")
    driver.find_element(By.XPATH, "//form/input[1]").send_keys(number)
    driver.find_element(By.XPATH, "//form/input[1]").send_keys(Keys.ENTER)
    time.sleep(5)
    try:
        myElem = WebDriverWait(driver, delay).until(EC.presence_of_element_located((By.XPATH, "//header/div[2]/h1/span")))
        print("Name eliment located")
        name  = driver.find_element(By.XPATH, "//header/div[2]/h1/span").text
        result = name
        print(name)
    except TimeoutException:
        print("There is no Name eliment on the page")
        try:
            myElem = WebDriverWait(driver, delay).until(EC.presence_of_element_located((By.XPATH, "/html/body/div/main/div/div[1]/div/h3")))
            print("Search Page has a H3")
        except Exception as e:
            print("Loading took too much time! for --",e)
        Res = driver.find_element(By.XPATH, '/html/body/div/main/div/div[1]/div/h3').text
        result = Res
        print(Res)
    driver.find_element(By.XPATH, "//form/input[1]").clear()
    return (driver,result,i)

def truecaller_logout(driver):
    try:
        myElem = WebDriverWait(driver, delay).until(EC.presence_of_element_located((By.XPATH, '/html/body/div[1]/div[1]/nav/div[1]/div[1]/button[1]')))
        print("Page is ready!")
    except TimeoutException:
        print("Loading took too much time!")
    driver.find_element(By.XPATH, '/html/body/div[1]/div[1]/nav/div[1]/div[1]/div[1]').click()
    try:
        button = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.XPATH, '/html/body/div/div[1]/nav/div[1]/div[1]/button')))
        button.click()
    except TimeoutException:
        print('button is not loaded !!!')
    return driver


number_l = ['9609606079','8768757844','9733951536','8016458159','8037811050','7431937620']


def verify_name(name_frm_db,name_frm_truecaller):
    name_frm_db = name_frm_db.lower()
    name_frm_truecaller = name_frm_truecaller.lower()
    name_frm_db_l = []
    name_frm_truecaller_l = []
    for el in name_frm_db.split(" "):
        name_frm_db_l = name_frm_db_l + el.split("'")
    for el in name_frm_truecaller.split(" "):
        name_frm_truecaller_l = name_frm_truecaller_l + el.split("'")
    print(name_frm_truecaller_l)
    print(name_frm_db_l)

    result = False
    for db_name in name_frm_truecaller_l:

        res = set(name_frm_db_l).intersection([db_name])
        if res:
            result = True
    return result


def start_search(number_l,accounts=accounts):
    result_l = []
    driver = start_browser()
    j = 0 # Using 'j' for tracking number list
    i = 0 # Using 'i' variable for tracking account index
    driver = truecaller_sign_in(driver,accounts[i]['method'],accounts[i]['username'],accounts[i]['password'])
    i = i + 1
    while j < len(number_l):
        number = number_l[j]
        try:
            driver,result,i = search(driver,number,i)
            if result != 'Search limit exceeded':
                result_l.append(result)
                j = j + 1
            elif result == 'Search limit exceeded' and i < len(accounts):
                driver.close()
                driver = start_browser()
                driver = truecaller_sign_in(driver,accounts[i]['method'],accounts[i]['username'],accounts[i]['password'])
                i = i + 1
            elif i == len(accounts):
                print('*******************************************')
                print("No account Left for searching")
                print('*******************************************')
                break
        except Exception as e:
            print("Error:",e)
        
    print(result_l)
    driver.close()
    return result_l


start_search(number_l)