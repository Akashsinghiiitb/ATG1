import time

import selenium

from webdriver_manager.chrome import ChromeDriverManager
from pprint import pprint

from selen.login_linkedin import login
from scraping.models import Search_Urls,Search_Type,Company


def get_link(str1):
    str1=str1.lower().split()
    return "%20".join(str1)


def get_people(company,driver):


    objects = Search_Type.objects.all()

    st = [f"{company} {get_link(o.name)}" for o in objects]
    print(st)
    dict1={}
    for o in range(len(st)):
        driver,dict1[objects[o].name]=get_li(st[o],driver)


    comp =  Company.objects.filter(name= company)[0]
    for k,v in dict1.items():
        obj1 = Search_Type.objects.filter(name=k)[0]
        for i in v:
            print(i)
            if Search_Urls.objects.filter(name=i,company=comp).count()==0:
                obj2=Search_Urls(name=i,search_type=obj1,company=comp)
                obj2.save()
                print("saved")


    return driver




def get_li(st,driver):
    print('--------------------------------------------------------------------')
    link = f"https://www.linkedin.com/search/results/people/?keywords={st}"
    driver.get(link)
    time.sleep(5)

    name_str='//*[contains(concat( " ", @class, " " ), concat( " ", "app-aware-link", " " ))]//span'
    state_str = '//*[contains(concat( " ", @class, " " ), concat( " ", "entity-result__secondary-subtitle", " " ))]'
    position_comp_str = '//*[(@id = "main")]//*[contains(concat( " ", @class, " " ), concat( " ", "t-black", " " ))]'

    href_str = 'app-aware-link'

    #name = driver.find_elements_by_xpath(name_str)
    #state_str = driver.find_elements_by_xpath(state_str)
    #position_comp= driver.find_elements_by_xpath(position_comp_str)
    href = driver.find_elements_by_class_name(href_str)

    #names = [n for n in name ]
    #state_str = [s.text for s in state_str]
    #position_comp=[p.text for p in position_comp]
    href=[h.get_attribute('href') for h in href]
    count =2
    q=0
    #print(href)
    mins =[]
    for i in range(1,len(href),2):
        if 'headless' not in href[i]:
            mins.append(href[i])

        q+=1
        if q>count:
            break


    #print(href)
    #time.sleep(20)
    return driver,mins
