from selenium import webdriver
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from bs4 import BeautifulSoup
import datetime
import time  
import re

# chrome_options = webdriver.ChromeOptions()
# prefs = {"profile.default_content_setting_values.notifications" : 2}
# chrome_options.add_experimental_option("prefs",prefs)
browser =webdriver.Chrome("C:/Users/Hp/Downloads/chromedriver.exe")

# browser =webdriver.Firefox(executable_path=r"C:/Users/Hp/Downloads/geckodriver.exe") 

def about_details( ):
    browser.get("https://www.linkedin.com/company/hoganlovells?trk=companies_directory") 
    plinks=WebDriverWait(browser, 10).until(EC.presence_of_all_elements_located((By.XPATH, '//*[contains(concat( " ", @class, " " ), concat( " ", "base-main-card__title", " " ))]')))
    for link in plinks: 
        link=WebDriverWait(link, 10).until(EC.presence_of_element_located((By.CSS_SELECTOR, 'a')))
        link=link.get_attribute("href") 
        print(link)

    



about_details( )