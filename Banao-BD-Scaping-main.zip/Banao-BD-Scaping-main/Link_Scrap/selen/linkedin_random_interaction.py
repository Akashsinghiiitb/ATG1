from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import random
import time

chrome_options = Options()
chrome_options.add_argument('--ignore-certificate-errors')
# chrome_options.add_argument('--headless')
chrome_options.add_argument('--no-sandbox')
# chrome_options.add_argument("--start-maximized")



def login():
    driver = webdriver.Chrome(executable_path='/usr/local/bin/chromedriver',options=chrome_options)

    driver.get("https://www.linkedin.com/login")
    username = "wamovot574@ecofreon.com"
    password = "Atg@123"
    el1=driver.find_element_by_id("username")
    el1.send_keys(username)

    el2=driver.find_element_by_id("password")
    el2.send_keys(password)

    str='//*[contains(concat( " ", @class, " " ), concat( " ", "from__button--floating", " " ))]'
    btn = driver.find_element_by_xpath(str)
    btn.click()
    return driver

def interaction(driver):
    time.sleep(5)
    times_of_scroll = random.randint(1,4)
    for _ in range(times_of_scroll):
        scroll_amount = random.randint(1000,10000)
        if random.randint(0,2)==0:
            scroll_amount = scroll_amount * (-1)
        driver.execute_script(f"window.scrollTo(0, {scroll_amount})")
        time.sleep(random.randint(1,4))

    card_list = driver.find_elements(By.XPATH, '//*[@id="main"]/div[3]/div/div[1]/div')
    card_list_len = len(card_list)
    random_click_count = random.randint(0,10)
    for _ in range(random_click_count):
        i = random.randint(0,card_list_len)
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, f'//*[@id="main"]/div[3]/div/div[1]/div[{i+1}]')))
        card = driver.find_element(By.XPATH, f'//*[@id="main"]/div[3]/div/div[1]/div[{i+1}]')
        actions = ActionChains(driver)
        actions.move_to_element(card).perform()
        post = 1
        try:
            card.find_element(By.CLASS_NAME,'artdeco-carousel__slider')
            post = 0
        except Exception as e:
            post = 1
        if post == 1:
            like = random.randint(0,3)
            try:
                if like == 0: 
                    like_button = card.find_element(By.CLASS_NAME ,f'react-button__trigger')
                    actions = ActionChains(driver)
                    actions.move_to_element(like_button).perform()
                    like_button.click()
            except Exception as e:
                print("Error when reacting",e)
            time.sleep(random.randint(1,3))
            #Inside the profile
            try:
                link = card.find_element(By.CLASS_NAME,'feed-shared-actor')
                actions = ActionChains(driver)
                actions.move_to_element(link).perform()
                link.click()
                print("entered inside profile")
                time.sleep(2)
                try:
                    times_of_scroll = random.randint(1,3)
                    for _ in range(times_of_scroll):
                        scroll_amount = random.randint(700,2000)
                        driver.execute_script(f"window.scrollTo(0, {scroll_amount})")
                        time.sleep(random.randint(1,4))
                    time.sleep(5)
                    try:
                        # container = driver.find_element(By.CLASS_NAME,'pv-profile-pymk__list')
                        # people_list = container.find_elements(By.CLASS_NAME,'pv-pymk-section__member-container')
                        people_list = driver.find_elements(By.XPATH,'/html/body/div[6]/div[3]/div/div[2]/div/div[2]/aside/div/div/div/div/div/div/div/div/section/ul/li[2]/div/div/button')
                        people_list = people_list + driver.find_elements(By.XPATH,'/html/body/div[6]/div[3]/div/div/div/div/div[3]/div/div/aside/div/div[2]/div/section/div/ul/li[1]/div/div/div/button')
                        people_list_len = len(people_list)
                        number_of_random = random.randint(0,people_list_len)
                        print(people_list_len, number_of_random)
                        for _ in range(number_of_random):
                            connect = people_list[random.randint(0,len(people_list)-1)]
                            actions = ActionChains(driver)
                            actions.move_to_element(connect).perform()
                            time.sleep(3)
                            try:
                                WebDriverWait(driver, 10).until(EC.element_to_be_clickable(connect))
                                connect.click()
                                print("connect clicked")
                            except Exception as e:
                                print(e)
                                pass
                    except Exception as e:
                        print("People not found",e)
                        try:
                            xpath = '/html/body/div[5]/div[3]/div/div[2]/div/div[2]/aside/div/div/div/div/div/div/div/div/section/ul/li'
                            page_list = driver.find_elements(By.XPATH,xpath)
                            print(len(page_list))
                        except Exception as e:
                            print('error in page', e)
                        
                except Exception as e:
                    pass
            except Exception as e:
                print("Error when trying to click the profile",e)
            # driver.execute_script("window.history.go(-1)")
        time.sleep(300)
    print(len(card_list))

def start_interaction():
    driver = login()
    interaction(driver)

start_interaction()
time.sleep(200)