import selenium
from scraping.models import SubCategory,State,LinkedinLookup
import time


def get_page(driver,state):

    list1=[1,0,0,0,0,0,0,0]
    link='https://www.linkedin.com/search/results/companies'
    state1=state

    if state=="jammu and kashmir":
        state1='jammu & kashmir'

    link_str="//button[normalize-space()='Locations']"
    #link_str='//*[(@id = "ember94")]'
    time.sleep(3)
    driver.get(link)
    l = driver.find_element_by_xpath(link_str)

    l.click()
    enter_space_str = "//input[@placeholder='Add a location']"
    enter_space= driver.find_element_by_xpath(enter_space_str)
    enter_space.send_keys(f'{state1},India')
    state_star="/html[1]/body[1]/div[6]/div[3]/div[1]/div[2]/section[1]/div[1]/nav[1]/div[1]/ul[1]/li[3]/div[1]/div[1]/div[1]/div[1]/div[1]/form[1]/fieldset[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]"
    time.sleep(5)
    state_fin= driver.find_element_by_xpath(state_star)
    state_fin.click()
    submit_str="//button[@data-artdeco-is-focused='true']//span[@class='artdeco-button__text'][normalize-space()='Show results']"
    submit_str='//*[(@id = "ember99")]'
    time.sleep(2)
    submit_btn = driver.find_element_by_xpath(submit_str)
    submit_btn.click()

    select_size_str = "//button[normalize-space()='Company size']//*[name()='svg']"
    #select_size_str='//*+[(@id = "hoverable-outlet-company-size-filter-value")]//*[contains(concat( " ", @class, " " ), concat( " ", "ember-view", " " ))]//*[contains(concat( " ", @class, " " ), concat( " ", "search-reusables__filter-pill-button", " " ))]'
    time.sleep(2)
    select_size = driver.find_element_by_xpath(select_size_str)
    select_size.click()

    company_size =['B','C','D','E','F','G','H','I']
    for l in range(len(company_size)):
        if list1[l]==1:
            path_m = f"//label[@for='companySize-{company_size[l]}']"
            bt = driver.find_element_by_xpath(path_m)
            bt.click()

    select_size.click()

    url=driver.current_url
    index=url.split('%5')[1]
    index=index[4:-3]
    print(index)
    if state=="delhi":
        stat = State.objects.filter(name='delhi ncr')[0]
    else:
        stat = State.objects.filter(name=state)[0]
    if LinkedinLookup.objects.filter(name=int(index)).count()==0:
        obj = LinkedinLookup(name=int(index),state=stat)
        obj.save()







    return driver



def get_lookup(driver):

    states = State.objects.all()

    for s in states:
        if LinkedinLookup.objects.filter(state=s).count()==0:
            if s.name == 'delhi ncr':
                driver=get_page(driver,'delhi')
            else:
                driver = get_page(driver,s.name)

    return driver


