import selenium
from scraping.models import LinkedinLookup,State,CompanyDetails,Company,EmployeSearch
from scraper_logs.models import scraping_bot_logs
import time
from bs4 import BeautifulSoup
import requests
def get_ip():
    ip = requests.get('https://checkip.amazonaws.com').text.strip()
    return ip

count = 1

def get_companies(state,driver,list1, count=count):
    print(state)
    ip = get_ip()
    print(ip)
    stat = State.objects.filter(name=state)[0]
    lookup = LinkedinLookup.objects.filter(state=stat)[0]

    searc= EmployeSearch.objects.all()
    list2 = ['"B"', '"C"', '"D"', '"E"', '"F"', '"G"', '"H"', '"I"']
    mape={}
    for i in range(len(searc)):
        mape[list2[i]]=searc[i]



    list_make = [list2[i]  for i in range(len(list1)) if list1[i]==1]
    print(list_make)
    print(mape)
    url_in='%2C'.join(list_make)

    url_in=url_in.rstrip('"')
    url_in=url_in.lstrip('"')
    print(url_in)
    duplicates = 0
    new = 0
    primary_url = f'companySize=%5B%22{url_in}%22%5D&origin=FACETED_SEARCH'
    print(primary_url)
    for i in range(1,6):



        
        url =f'https://www.linkedin.com/search/results/companies/?companyHqGeo=%5B%22{lookup.name}%22%5D&companySize=%5B%22D%22%5D&origin=FACETED_SEARCH&page={i}'
        url = f'https://www.linkedin.com/search/results/companies/?companyHqGeo=%5B%22{lookup.name}%22%5D&{primary_url}&page={i}'

        driver.get(url)

        time.sleep(3)



        name_company_str='//*[contains(concat( " ", @class, " " ), concat( " ", "t-16", " " ))]//*[contains(concat( " ", @class, " " ), concat( " ", "app-aware-link", " " ))]'

        selements = driver.find_elements_by_xpath('//*[contains(concat( " ", @class, " " ), concat( " ", "t-16", " " ))]//*[contains(concat( " ", @class, " " ), concat( " ", "app-aware-link", " " ))]')
        print('----------------------------------------------------------------------------------')
        print(ip,'------',count)
        count = count + 1
        for s in selements:

            try:

                if Company.objects.filter(name=s.text).count()==0:
                    comp = Company(name=s.text)

                    comp.save()
                    new = new + 1

                else:
                    comp = Company.objects.filter(name=s.text)[0]
                    duplicates = duplicates + 1


                comp.state.add(stat)
                for k,v in mape.items():
                    if k in list_make:
                        comp.employee_size.add(v)

                if CompanyDetails.objects.filter(company=comp).count()==0:

                    detail = CompanyDetails(company=comp,linkedin_url=s.get_attribute('href'))
                    detail.save()
                else:
                    if CompanyDetails.objects.filter(company=comp,linkedin_url=s.get_attribute('href')).count()==0:
                        CompanyDetails.objects.filter(company=comp).update(linkedin_url=s.get_attribute('href'))
            except Exception as e:
                new_log = scraping_bot_logs(name="Element error in Company",description=e[0:100])
                new_log.save()
                pass

    new_log_n = scraping_bot_logs(name="Number of new companies scraped",description=state,dvalue=new)
    new_log_n.save()
    new_log_d = scraping_bot_logs(name="Number of Duplicates ",description=state,dvalue=duplicates)
    new_log_d.save()



    time.sleep(20)
    return driver

