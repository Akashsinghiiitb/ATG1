import selenium

from login_linkedin import login

import time





def web_format(str1):
    str1 = str1.split()

    return '%20'.join(str1)


def make_abut(link):
    keywords=['about','posts','jobs']
    href = link.split('/')

    href=[i for i in href if i !='']
    print(href)
    hrefs = ["https://"+"/".join(href[1:]+[k]) for k in keywords]
    return hrefs



def get1(driver,href):
    driver.get(href)
    description_str = '//*[contains(concat( " ", @class, " " ), concat( " ", "mb5", " " )) and contains(concat( " ", @class, " " ), concat( " ", "t-normal", " " ))]'

    element = driver.find_element_by_xpath(description_str)
    description = element.text
    company_contacts_str = '//*[contains(concat( " ", @class, " " ), concat( " ", "overflow-hidden", " " ))]'
    element = driver.find_element_by_xpath(company_contacts_str)
    contacts = element.text
    print(description)
    print(contacts)
    print(len(contacts.split('\n')))

    return driver


def get2(driver,href):

    driver.get(href)

    jobs_str = '//*[contains(concat( " ", @class, " " ), concat( " ", "js-focusable-card", " " ))]'

    elements = driver.find_elements_by_xpath(jobs_str)
    print(elements)

    for e in elements:
        features=e.text.split('\n')
        print(f"hi ets  {features}")


    return driver


def company_page(name):
    driver = login()
    url =f'https://www.linkedin.com/search/results/companies/?keywords={web_format(name.lower())}'
    driver.get(url)
    str1='//*[contains(concat( " ", @class, " " ), concat( " ", "mb2", " " )) and (((count(preceding-sibling::*) + 1) = 2) and parent::*)]//*[contains(concat( " ", @class, " " ), concat( " ", "t-black--light", " " ))]'
    element = driver.find_elements_by_xpath(str1)

    print(element)
    features = element[0].text.split('\n')
    href = element[0].find_element_by_css_selector('a').get_attribute('href')

    print(f"am here {features}")

    #driver.get(href)
    str2='//*[contains(concat( " ", @class, " " ), concat( " ", "t-20", " " ))] | //*[contains(concat( " ", @class, " " ), concat( " ", "overflow-hidden", " " ))] | //*[contains(concat( " ", @class, " " ), concat( " ", "t-normal", " " ))]'
    str3='//*[contains(concat( " ", @class, " " ), concat( " ", "mb2", " " )) and (((count(preceding-sibling::*) + 1) = 2) and parent::*)]//*[contains(concat( " ", @class, " " ), concat( " ", "t-black--light", " " ))] | //*[contains(concat( " ", @class, " " ), concat( " ", "mb2", " " )) and (((count(preceding-sibling::*) + 1) = 2) and parent::*)]//*[contains(concat( " ", @class, " " ), concat( " ", "t-normal", " " ))] | //*[contains(concat( " ", @class, " " ), concat( " ", "mb2", " " )) and (((count(preceding-sibling::*) + 1) = 2) and parent::*)]//*[contains(concat( " ", @class, " " ), concat( " ", "display-flex", " " ))]'
    #elements =driver.find_elements_by_xpath(str2)


    #time.sleep(10)

    hrefs= make_abut(href)
    keywords = ['about', 'posts', 'jobs']
    driver =get1(driver,hrefs[0])

    #driver =get2(driver,hrefs[2])



    driver.quit()


company_page('the digital divide')

company_page('swiggy')


#make_abut('https://www.linkedin.com/company/swiggy-in/')