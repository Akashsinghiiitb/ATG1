from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
import time
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import *
from fake_useragent import UserAgent
from proxyscrape import create_collector


collector = create_collector('my-collector', 'http')

delay = 5

def start_browser():
    proxy = collector.get_proxy()
    # PROXY = f'{proxy[0]}:{proxy[1]}'
    PROXY = "52.183.8.192:3128"
    print(PROXY)
    s=Service(ChromeDriverManager().install())
    options = Options()
    ua = UserAgent()
    userAgent = ua.random
    print(userAgent)
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument(f'user-agent={userAgent}')
    options.add_argument('--proxy-server=%s' %PROXY)
    # webdriver.DesiredCapabilities.CHROME['proxy']={
    #     "httpProxy":PROXY,
    #     "ftpProxy":PROXY,
    #     "sslProxy":PROXY,
    #     "proxyType":"MANUAL", 
    # }
    # options.headless = True
    driver = webdriver.Chrome(service=s,options=options)
    driver.maximize_window()
    time.sleep(1)
    try:
        driver.get('https://tools.emailhippo.com/')
    except WebDriverException as e:
        print(e)
        driver.close()
        start_browser()
    return driver

def search(driver,email):
    time.sleep(1)
    try:
        myElem = WebDriverWait(driver, delay).until(EC.presence_of_element_located((By.ID, 'input-email-address')))
        print("Page is ready!")
        driver.find_element(By.ID, "input-email-address").send_keys(Keys.CONTROL + 'a')
        driver.find_element(By.ID, "input-email-address").send_keys(email)
        driver.find_element(By.ID, "input-email-address").send_keys(Keys.ENTER)
        time.sleep(1)
    except TimeoutException:
        driver.close()
        driver = start_browser()
        print("Loading took too much time!")
    try:
        myElem = WebDriverWait(driver, delay).until(EC.presence_of_element_located((By.XPATH, '//*[@id="dt-grid1"]/tbody/tr/td[2]')))
        print("Page is ready!")
        res = driver.find_element(By.XPATH, '//*[@id="dt-grid1"]/tbody/tr/td[2]').text
    except TimeoutException:
        print("Loading took too much time!")
        res = "Not Found"

    return res

email_l = ['sardarisanur@gmail.com','sardarisanur2001@gmail.com','sardarisanur5@gmail.com']

driver = start_browser()
for email in email_l:
    res = search(driver,email)
    print(f"{email}--{res}")