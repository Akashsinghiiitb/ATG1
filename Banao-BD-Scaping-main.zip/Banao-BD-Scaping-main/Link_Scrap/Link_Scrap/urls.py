"""Link_Scrap URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from re import L
from django.contrib import admin
from django.urls import path,include
from scraping import views
 
urlpatterns = [
    path('admin/', admin.site.urls),
    # path('',views.home_company,name='home'),
    # path('subcategory',views.filter,name='filtersubcat'),
    # path('search/',views.search,name='search'),
    # path('company_detail/<int:id>/', views.company_detail,name='company_detail'),
    # path('filteredsearch/',views.filter,name='submitform'),
    # path('people/<int:id>/',views.people,name='people'),
    path('config/',views.config,name='config'),
    path('api/',include('scraping.api.urls')),
    path('captain/',include('Api.urls')),
]
