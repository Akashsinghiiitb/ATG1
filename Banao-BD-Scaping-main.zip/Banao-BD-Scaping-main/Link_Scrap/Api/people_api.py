import requests

import json

# URL="http://127.0.0.1:8000/studentapi/?name=Snehal&count=2"
# URL="http://127.0.0.1:5000/api/filter/?state=delhi ncr"
headers={'content-Type':'application/json'}

def post_data():
    # URL="http://127.0.0.1:8000/api/filter/?state=goa&count=1 'Authorization:Token d4432cf6c3ccb90a44e9b4c419a8a46d51502036'"
    URL= "http://127.0.0.1:8000/api/filter/?state=assam&count=1 'Authorization:Token d4432cf6c3ccb90a44e9b4c419a8a46d51502036'"

    print(URL)


    headers={'content-Type':'application/json'}
    r=requests.post(url=URL,headers=headers)
    people=r.json()
    print(people) 
    data=r.json()
    print(data)

post_data()


# def get_data(id=None):
#     data={}
#     if id is not None:
#         data={'id':id}
#     json_data = json.dumps(data)
#     r=requests.get(url=URL,headers=headers,data=json_data)
#     data=r.json()
#     print(data)

# get_data(3)

