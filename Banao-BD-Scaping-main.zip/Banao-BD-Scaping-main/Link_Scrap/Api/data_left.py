from .models import Api
from scraping.models import People
from scraping.models import State 
class data :
    def data_left():
        # print("---------------------------------------------------------------------------")
        data_left=[]
        apis=Api.objects.all().order_by("created_at").reverse()
        for api in apis :
            data=[]
            name=api.user.username
            data.append(name)
            # print("name :",api)
            api=api.api 
            data.append(api)
            # print("api :", api)
            param=api.split("&")
            # print(api,"-------------",param)
            for p in param:
                if "state" in p :
                    s=p.split("=")
                    s.remove("state") 
                else:
                    s=list() 
                # print("s", s) 
                if len(s)!=0 :
                    if "," in s[0] :
                        s=s[0].split(",") 
            state_list=s
            # print("state_list : ", state_list) 
            if len(state_list)!=0 :    
                state_q=State.objects.filter(name__in=state_list) 
                no_people=People.objects.filter(state__id__in=state_q,acessed=0).count()  
            else :                   
                no_people=People.objects.filter(acessed=0).count()
            
            data.append(no_people)
            data_left.append(data)
            # print("no_people :",no_people)
            # print(data)

        # print(data_left) 
        return data_left 