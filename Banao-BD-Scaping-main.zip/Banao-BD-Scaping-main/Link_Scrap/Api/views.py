from django.http.response import HttpResponseRedirectBase
from django.http import HttpResponseRedirect
from django.shortcuts import render
from scraping.models import State 
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate, login
from django.contrib.auth import logout
from django.contrib.auth.decorators import login_required
from rest_framework.permissions import IsAuthenticated
from rest_framework.authtoken.models import Token
from django.contrib.auth.models import User
from .models import Api
from scraping.models import People
from django.http import HttpResponse
from django.contrib import messages 
import datetime 
from .data_left import data 
# Create your views here.

 

def  logi(request):
    
    if request.method=='POST':   
        data_left = data.data_left() 
        # print("request.user:",type(request.user))
        username=request.POST['username']
        form = AuthenticationForm(data=request.POST)
        if form.is_valid()  :
            username = request.POST['username']
            password = request.POST['password']
            user = authenticate(request, username=username, password=password)
            login(request,user)
            # print(type(user)) 
            # print("request.user:", request.user)
            if  request.user.is_staff:
                state=State.objects.all()
                users=User.objects.all()
                return render(request,'Api/api_form.html',{ 'users':users, 'states':state,'username':user,"data_left":data_left })
            else:
                
                form = AuthenticationForm() 
                return render(request,'Api/login.html',{'form':form,'not_auth':True})
        else:
            
            form = AuthenticationForm() 
            return render(request,'Api/login.html',{'form':form,'error':True})
    else:
        logout(request)
        form = AuthenticationForm()  
        return render(request,'Api/login.html',{'form':form,'error':False})
 


def handleregister(request):
    state=State.objects.all()
    users=User.objects.all()
    if request.method=="POST":
        user=request.user
        Username=request.POST['username']
        First_name=request.POST['first_name']
        Last_name=request.POST['last_name']
        Email=request.POST['email']
        Password=request.POST['password']
        Cpassword = request.POST['cpassword']


        users_q=User.objects.all()
        data_left = data.data_left()
        for u in users_q:
          
            if Username ==u.username:
                messages.error(request,f"Username {Username} Already exists try another one !")
                return render(request,'Api/api_form.html',{'users':users, 'states':state,'username':user,"data_left":data_left })
 
       
        if len(Username)>10:
            messages.error(request,"Username must be less than 10 characters")
            return render(request,'Api/api_form.html',{'users':users, 'states':state,'username':user,"data_left":data_left })


        if Password!=Cpassword:
            messages.error(request,"Confirmed password not match with passwod you entered ! ")
            return render(request,'Api/api_form.html',{'users':users, 'states':state,'username':user,"data_left":data_left })

        cr_user=User.objects.create_user(Username,Email,Password)
        cr_user.first_name=First_name
        cr_user.last_name=Last_name
        cr_user.save()
        Token.objects.create(user=cr_user)
        messages.success(request,f"New user {Username} created !")
        return render(request,'Api/api_form.html',{'users':users, 'states':state,'username':user,"data_left":data_left })
            
    else:
        
        return HttpResponseRedirect("/captain/login/")
 
 
@login_required(login_url="/captain/login/") 
def api_filter(request):

    username=request.user
    state=State.objects.all()
    users=User.objects.all() 
    data_left = data.data_left()
    if request.method=='GET':
        r_state_s =request.GET.getlist('state',None)
        state_s = ",".join(r_state_s)
        # r_state=request.GET.get('state') 
        r_count=request.GET.get('count') 
        
        r_test= request.GET.get('test')
        if r_test=="False":
            r_test=False
        if r_test=="True":
            r_test=True

        # print("r_test:",r_test)
        r_user_id=int(request.GET.get('user_select') ) 
        if r_user_id ==0 : 
            # data_left = data.data_left()
            return render(request,'Api/api_form.html',{'users':users, 'states':state, 'state_select_error': "State",'user_select_error': "User",'username':username,"data_left":data_left })

        if r_user_id !=0 :

            # if not r_state_s:
            #     return render(request,'Api/api_form.html',{'users':users, 'states':state, 'state_select_error': "State",'username':username })
            if not r_count:
                data_left = data.data_left()
                return render(request,'Api/api_form.html',{'users':users, 'states':state, 'count_select_error': "Count",'username':username,"data_left":data_left })
                 
            r_user=User.objects.get(id=r_user_id).username
            # print('r_states :',r_state_s)
            # print('r_count :',r_count)
            print('r_user_id :',r_user_id)
            # print('r_test :',r_test)
            user_token = Token.objects.filter(user_id=r_user_id)
            api_q=Api.objects.filter(user_id=r_user_id)
            if api_q:
                no_hits=api_q[0].no_hits
                user_token = Token.objects.filter(user_id=r_user_id)
                if no_hits !=0: 
                    new_key = user_token[0].generate_key()
                    user_token.update(key=new_key)
            
            if user_token :
                token=user_token[0]
            else :
                return HttpResponse("NO token for selected user!") 
            host=request.get_host()
            
            # if r_test:
            #     api=f"http://{host}/api/filter/?token={token}&state={state_s}&count={r_count}&test={r_test}"
                
            # else:
            #     api=f"http://{host}/api/filter/?token={token}&state={state_s}&count={r_count}"
            api=f"http://{host}/api/filter/?token={token}&count={r_count}"

            if r_test and state_s:
                api= api+f"&state={state_s}&test={r_test}"
            elif r_test  and not state_s :
                api=api+f"&test={r_test}"
            elif r_test== False and state_s  :
                api=api+f"&state={state_s}" 
            

            # URL=f"http://127.0.0.1:8000/api/filter/?state={state_s}&count={r_count}"

            current_dt=datetime.datetime.now(datetime.timezone.utc)

            if r_test==False :
                exist_user_q=Api.objects.filter(user_id=r_user_id)
                if exist_user_q: 
                    exist_user_q.update(created_at=current_dt,api=api,no_hits=0) 
                else:
                    user_api=Api.objects.create(user_id=r_user_id,created_at=current_dt ,api=api)
                    # print("user_api :",user_api) 
            data_left = data.data_left()
            return render(request,'Api/api_form.html',{'users':users, 'states':state,'api':api,'user_select':r_user,'username':username,"data_left":data_left })
             
       
        if r_user_id ==0 :
            # return HttpResponse("<h4> select user !</h4>")    
            # data_left = data.data_left()
            return render(request,'Api/api_form.html',{'users':users, 'states':state, 'user_select_error': "User",'username':username,"data_left":data_left })



@login_required(login_url="/captain/login/")
def refresh_data(request):
    username=request.user
    state=State.objects.all()
    users=User.objects.all()
    data_left = data.data_left()
    return render(request,'Api/api_form.html',{'users':users, 'states':state,'username':username,"data_left":data_left })








        
 
