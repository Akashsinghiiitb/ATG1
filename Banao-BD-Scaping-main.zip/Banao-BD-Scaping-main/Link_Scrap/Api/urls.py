from django.urls import path,include
from Api import views
 
urlpatterns = [
     
    # path('home/',views.filter_params),
    # path('f/<username>/',views.api_filter,name='api_filter'),
    path('f/',views.api_filter,name='api_filter'),  
    path('login/',views.logi,name='login'), 
    path('user/register/',views.handleregister,name='register'), 
    path('login/refresh/',views.refresh_data, name="refresh"),
    

]  