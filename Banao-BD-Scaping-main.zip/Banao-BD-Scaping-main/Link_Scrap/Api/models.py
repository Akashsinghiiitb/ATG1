from django.db import models
from django.contrib.auth.models import User
 
# Create your models here.




class Api(models.Model):

    user = models.ForeignKey(User,on_delete=models.CASCADE)
    api = models.URLField() 
    created_at=models.DateTimeField()
    no_hits=models.IntegerField(default=0)

    def __str__(self):
        return self.user.username
