from django.core.management.base import BaseCommand, CommandError
from scraping.models import Category
from database_interaction.control import get_category

class Command(BaseCommand):
    help = 'Closes the specified poll for voting'

    #def add_arguments(self, parser):
        #parser.add_argument('poll_ids', nargs='+', type=int)


    def handle(self, *args, **options):
        get_category()
