from django.core.management.base import BaseCommand, CommandError
from scraping.models import Category,Company
from selen.company2 import company_page
from selen.login_linkedin import login
class Command(BaseCommand):
    help = 'Closes the specified poll for voting'

    #def add_arguments(self, parser):
        #parser.add_argument('poll_ids', nargs='+', type=int)


    def handle(self, *args, **options):
        driver = login()
        companies= Company.objects.all()
        print(companies)


        for c in companies:

            try:
                if c.details_searched==0:
                    print(c.name)
                    driver=company_page(c.name,driver)
                    Company.objects.filter(name=c.name).update(details_searched=1)
                    print("done")


            except:
                pass

                














        driver.quit()