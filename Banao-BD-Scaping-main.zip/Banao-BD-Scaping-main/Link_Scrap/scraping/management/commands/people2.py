from django.core.management.base import BaseCommand, CommandError
from scraping.models import Category
from selen.poeple import save_details
from scraping.models import Company
from webdriver_manager.chrome import ChromeDriverManager
from selenium import webdriver
from selen.login_linkedin import login, initiate
import time
from scraper_logs.models import scraping_bot_logs


class Command(BaseCommand):
    help = 'Closes the specified poll for voting'

    #def add_arguments(self, parser):
        #parser.add_argument('poll_ids', nargs='+', type=int)


    def handle(self, *args, **options):
        companies = Company.objects.filter(details_searched=0)
        driver = login()
        for c in companies:
            try:
                driver,res =save_details(c.name,driver)
                current_url = driver.current_url
                print(current_url)
                if "authwall" not in current_url and "login" not in current_url and "checkpoint" not in current_url:
                    comp = Company.objects.filter(name=c.name)[0]
                    comp.details_searched=1
                    comp.save()
                else:
                    print("Account got blocked")
                    driver.quit()
                    break
            except Exception as e:
                print(e)
                new_log = scraping_bot_logs(name="get Details log in people2",description=e[0:100])
                new_log.save()

        driver.quit()
