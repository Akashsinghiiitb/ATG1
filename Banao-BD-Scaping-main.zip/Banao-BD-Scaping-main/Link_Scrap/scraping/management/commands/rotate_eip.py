from django.core.management.base import BaseCommand, CommandError
from scraper_logs.models import ElasticIP, scraping_bot_logs
from aws.ip_rotation import rotate_eip

class Command(BaseCommand):
    help = 'Changes the IP to the next ip of last used ip'

    #ip change log name - last ip used
    def handle(self, *args, **options):

        eips = ElasticIP.objects.all()
        total_eip = eips.count()
        ip_log = scraping_bot_logs.objects.filter(name="last ip used")
        count = ip_log.count()
        if count == 0:
            last_ip = ip_log[count - 1].dvalue
            last_ip_obj = ElasticIP.objects.get(eip_address=last_ip)
            last_ip_ind = list(eips).index(last_ip_obj)
            if last_ip_ind >= total_eip:
                new_ip = eips[0]
            else:    
                new_ip = eips[last_ip_ind + 1]
        else:
            new_ip = eips[0]

        new_log = scraping_bot_logs(name="last ip used",description="Allocating this ip",dvalue=new_ip.eip_address)
        new_log.save()
        rotate_eip(new_ip.eip_allocation_id)