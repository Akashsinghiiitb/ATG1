from django.core.management.base import BaseCommand, CommandError
from fs.facebook_company_scrape import search_comp,login_facebook
from scraping.models import Company
class Command(BaseCommand):
    help = 'Closes the specified poll for voting'

    #def add_arguments(self, parser):
        #parser.add_argument('poll_ids', nargs='+', type=int)


    def handle(self, *args, **options):

        companies = Company.objects.all()
        browser = login_facebook()
        headers =['Domain','Website','Phone_No','Follower','Comments','Shares','Last_Posted']
        for c in companies[:5]:

            browser,company_detail=search_comp(c.name,browser)


        browser.quit()

