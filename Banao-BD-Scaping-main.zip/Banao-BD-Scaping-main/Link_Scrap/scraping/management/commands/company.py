from os import name
from django.core.management.base import BaseCommand, CommandError
from selen.login_linkedin import login
from selen.find_company import get_page,get_lookup
from selen.find_company2 import get_companies
from scraper_logs.models import scraping_bot_logs
import json

class Command(BaseCommand):
    help = 'Closes the specified poll for voting'

    #def add_arguments(self, parser):
        #parser.add_argument('poll_ids', nargs='+', type=int)



    def handle(self, *args, **options):



        try:
            driver = login()
        except Exception as e:
            print(e)
            new_log = scraping_bot_logs(name="Login_Error",description=e[0:100])
            new_log.save()
            return None
        with open("selen/confi/c1.json","r") as f:
            con = json.load(f)
            f.close()
        try:
            obj = scraping_bot_logs.objects.filter(name="employee_size")
            count = obj.count()
            emp_size = obj[count-1].dvalue
        except Exception as e:
            print(e)
            emp_size = 1
        num = self.get_it(emp_size)
        increase = 2000
        if num == 1:
            increase = 40
        elif num == 2:
            increase = 150
        elif num == 3:
            increase = 300
        elif num == 4:
            increase = 500
        elif num == 5:
            increase = 4000
        elif num == 6:
            increase = 5000
        else :
            increase = 99
        if increase == 99:
            emp_size = 1
        else:
            emp_size = emp_size + increase
        list1=[]
        for i in range(num):
            list1.append([0 if i!=m else 1 for m in range(8)])
        print(list1)

        for s in con['state']:
            for l in list1:
                print(s)
                try:
                    driver = get_companies(s, driver,l)
                except Exception as e:
                    print(e)
                    new_log = scraping_bot_logs(name="get_companies_log in company",description=e[0:100])
                    new_log.save()
        new_log = scraping_bot_logs(name="employee_size",description="Changinf employee size for next search",dvalue=emp_size)
        new_log.save()


        #driver= get_lookup(driver)

        #driver=get_companies("delhi ncr",driver)

        driver.quit()


    def get_it(self,size):
        if size<11:
            return 1
        elif size<51:
            return 2
        elif size<201:
            return 3
        elif size<501:
            return 4
        elif size<1001:
            return 5
        elif size<5001:
            return 6
        elif size<10001:
            return 7
        else:
            return 8
