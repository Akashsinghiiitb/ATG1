from selen.login_linkedin import login
import time
from django.core.management.base import BaseCommand, CommandError
from cn12.control1 import scr1


class Command(BaseCommand):
    help = 'Closes the specified poll for voting'

    #def add_arguments(self, parser):
        #parser.add_argument('poll_ids', nargs='+', type=int)


    def handle(self, *args, **options):

        #driver = login()
        scr1()
        #driver.quit()