from django.core.management.base import BaseCommand, CommandError
from scraping.models import Company,CompanyDetails

class Command(BaseCommand):
    help = 'Closes the specified poll for voting'

    #def add_arguments(self, parser):
        #parser.add_argument('poll_ids', nargs='+', type=int)


    def handle(self, *args, **options):

        companies = Company.objects.all()
        print(companies)

        for c in companies:
            Company.objects.filter(name=c.name).update(people_searched=0)

