from django.core.management.base import BaseCommand, CommandError
from scraping.models import Category
from selen.people_details import get_people
from selen.login_linkedin import login
from scraping.models import Company
import time
from scraper_logs.models import scraping_bot_logs
class Command(BaseCommand):
    help = 'Closes the specified poll for voting'

    #def add_arguments(self, parser):
        #parser.add_argument('poll_ids', nargs='+', type=int)


    def handle(self, *args, **options):
        objects = Company.objects.filter(people_searched=0)
        # objects = Company.objects.all()
        objects = reversed(list(objects))
        driver = login()
        for o in objects:
            try:
                driver =get_people(o,driver)
                time.sleep(2)
                o.people_searched=1	
                o.save()
                print("--")
            except Exception as e:
                print(e)
                new_log = scraping_bot_logs(name="get people log in people",description=e[0:100])
                new_log.save()

            time.sleep(5)
        driver.quit()
