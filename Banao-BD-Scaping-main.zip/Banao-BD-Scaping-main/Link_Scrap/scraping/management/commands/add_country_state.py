from django.core.management.base import BaseCommand, CommandError
from database_interaction.country_state import transfer
from scraping.models import Country, State


class Command(BaseCommand):
    help = "Polluted Country(Except INDIA) and their States model from pycountry pkg --- Dond run if you don't know"

    def handle(self, *args, **options):
        transfer(Country,State)
        print("Completed")