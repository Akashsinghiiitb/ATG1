from django.db import models
from django.contrib.auth.models import User
import datetime

# Create your models here.
class Country(models.Model):

    name = models.CharField(max_length=200)

    def __str__(self):

        return self.name

class State(models.Model):

    country = models.ForeignKey(Country,default=1,on_delete=models.CASCADE)
    name = models.CharField(max_length=200)
    jobs_searched = models.IntegerField(default=0)

    def __str__(self):
        return self.name

class Category(models.Model):
    name = models.TextField(max_length=200)

    def __str__(self):
        return self.name

class SubCategory(models.Model):
    name = models.TextField(max_length=200)
    category = models.ForeignKey(Category,on_delete=models.CASCADE)

    def __str__(self):
        return self.name




class EmployeSearch(models.Model):
    name = models.CharField(max_length=200)

    def __str__(self):
        return self.name


class Company(models.Model):
    name = models.CharField(max_length=200)
    state= models.ManyToManyField(State)
    subcategory=models.ManyToManyField(SubCategory)
    employee_size=models.ManyToManyField(EmployeSearch,default=None,null=True)
    details_searched = models.IntegerField(default=0)
    people_searched=models.IntegerField(default=0)

    def __str__(self):
        return self.name

class Jobs(models.Model):
    name = models.CharField(max_length=200)
    state = models.ForeignKey(State,on_delete=models.CASCADE)
    company = models.ForeignKey(Company,on_delete=models.CASCADE)
    sub_category = models.ManyToManyField(SubCategory)
    url = models.URLField()

    def __str__(self):
        return self.company.name

class CompanyDetails(models.Model):

    company = models.ForeignKey(Company,on_delete=models.CASCADE,default=None)
    headquarters = models.CharField(max_length=200,default=None,null=True)
    description = models.TextField(default=None,null=True)
    founded = models.IntegerField(default=None,null=True)
    industry = models.CharField(max_length=200,default=None,null=True)
    website = models.URLField(default=None,null=True)
    company_size = models.IntegerField(default=None,null=True)
    type = models.CharField(max_length=200,default=None,null=True)
    specialities = models.CharField(max_length=500,default=None,null=True)
    followers = models.CharField(max_length=200,default=None,null=True)
    phone = models.CharField(max_length=200,default=None,null=True)
    linkedin_url = models.URLField(default=None,null=True)
    facebook_followers=models.IntegerField(default=0,null=True)
    fb_comments = models.IntegerField(default=0,null=True)
    last_post_shares = models.IntegerField(default=0,null=True)
    last_posted = models.CharField(max_length=200,null=True)


    #list1=['company','headquarters','description','founded','industry','website','company_size','type','specialities','followers','phone']

    def __str__(self):
        return self.company.name



class Search_Type(models.Model):

    name = models.CharField(max_length=200)


    def __str__(self):
        return self.name


class Search_Urls(models.Model):

    name = models.URLField()
    search_type = models.ForeignKey(Search_Type,on_delete=models.CASCADE)
    company = models.ForeignKey(Company,on_delete=models.CASCADE)


    # def __str__(self):
    #     return self.company.name
    def __int__(self):
        return self.name



class People(models.Model):

    url = models.ForeignKey(Search_Urls,on_delete=models.CASCADE)
    company = models.ForeignKey(Company,on_delete=models.CASCADE)
    state = models.ForeignKey(State,on_delete=models.CASCADE,default=None,null=True)
    name = models.CharField(max_length=200,null=True)
    position = models.CharField(max_length=500,null=True)
    contact_info = models.TextField(default=None,null=True)
    acessed = models.IntegerField(default=0,null=True)
    repetition = models.IntegerField(default=0,null=True)



    # def __str__(self):
    #     return f"{self.company.name} {self.url.search_type.name}"
    def __str__(self):
        return self.url.name


class LinkedinLookup(models.Model):

    name = models.IntegerField()
    state= models.ForeignKey(State,on_delete=models.CASCADE)


    def __str__(self):
        return self.state.name



class LinkedinAccount(models.Model):

    username= models.CharField(max_length=200)
    password= models.CharField(max_length=200)

    def __str__(self):
        return self.username



class Toke(models.Model):

    user = models.ForeignKey(User,on_delete=models.CASCADE)
    token = models.TextField()
    reset_times = models.IntegerField(default=0)

    def __str__(self):
        return self.user



class Log_t(models.Model):

    user = models.ForeignKey(User,on_delete=models.CASCADE)
    created=models.DateTimeField(default=None,null=True)
    updated=models.DateTimeField(default=None,null=True)
    last_used = models.DateTimeField(default=None,null=True)
    indexes = models.ManyToManyField(People)


    def __str__(self):
        return self.user.username

