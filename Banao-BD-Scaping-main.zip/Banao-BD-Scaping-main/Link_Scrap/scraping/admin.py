from django.contrib import admin
from .models import State,SubCategory,Category,Company,Jobs,CompanyDetails,Search_Type,Search_Urls,People,EmployeSearch,LinkedinAccount,LinkedinLookup,Log_t,Toke
admin.site.register(State)
admin.site.register(Category)
admin.site.register(SubCategory)
admin.site.register(Company)
admin.site.register(Jobs)
admin.site.register(CompanyDetails)
admin.site.register(Search_Type)
admin.site.register(Search_Urls)
admin.site.register(People)
admin.site.register(EmployeSearch)
admin.site.register(LinkedinLookup)
admin.site.register(LinkedinAccount)
admin.site.register(Toke)
admin.site.register(Log_t)
# Register your models here.
