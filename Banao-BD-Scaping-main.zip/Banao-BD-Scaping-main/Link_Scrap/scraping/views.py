from django.db.models import manager
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
# from Link_Scrap import scraping
from .models import *
from django.http.response import HttpResponseRedirect
# Create your views here.
import json

 
def is_valid_queryparam(param):
    empt_list=[]
    return param != '' and param is not None and param !=empt_list 
# print("---------------all company objects--------",company,"--------------------------")
state=State.objects.all()
category=Category.objects.all()
emp_size=EmployeSearch.objects.all()

@login_required(login_url="/captain/login/")
def home_company(request):
    user=request.user
    company=Company.objects.all()
    state=State.objects.all()
                         # category=Category.objects.all()
    emp_size=EmployeSearch.objects.all()
    
    config_click=False

    return render(request,'scraping/company.html',{'companies':company,'states':state,'categories':category,'emp_sizes':emp_size,'config_click':config_click})



@login_required(login_url="/captain/login/")
def config(request):
    user=request.user
    company=Company.objects.all()
    config_click=True
    conf_state=request.GET.getlist('state')
    conf_emp_size=request.GET.get('emp_size')
    # print("states : ",conf_state)
    # print("emp_size : ",conf_emp_size)
    configur=False
    if conf_state or conf_emp_size:

        if conf_emp_size:
           conf_emp_size=int(conf_emp_size)
        else:
            conf_emp_size=0
        configur=True 
        Q_state=State.objects.filter(pk__in=conf_state)
        # print("Q_states : ",Q_state)
        state_list=[]
        for  st in Q_state:
            state_list.append(st.name)

        # print(state_list)

        conf_dict={'State':state_list,
                    'employee_size':conf_emp_size
                  }
        conf_json=json.dumps(conf_dict,indent = 2)
        with open("selen/confi/c1.json", "w") as outfile:
           outfile.write(conf_json)
    

    return render(request,'scraping/company.html',{'companies':company,'states':state,'categories':category,'emp_sizes':emp_size,'config':configur,'config_click':config_click})

 


@login_required(login_url="/captain/login/")

def search(request):
    user=request.user
    search_key=None
    results=[]
    if request.method=="GET":
        search_key=request.GET.get('search')
        results=Company.objects.filter(name__icontains=search_key)
    return render(request,'scraping/company.html',{'query':search_key, 'companies':results ,'states':state,'categories':category,'emp_sizes':emp_size, })

@login_required(login_url="/captain/login/")
def company_detail(request,id):
    user=request.user
    company=Company.objects.get(pk=id)
    company_detail=company.companydetails_set.all() 
    # company_detail=CompanyDetails.objects.filter(company_id=id)
    return render(request,'scraping/company_detail.html',{'company_details':company_detail,'company':company})



@login_required(login_url="/captain/login/")
def filter(request):
    user=request.user

    # state_ids=request.GET.getlist('state',None)
    # subcate_ids=request.GET.getlist('subcategory')
    # empsize_ids=request.GET.getlist('emp_size',None)
    company=Company.objects.all()
    # print("state check",is_valid_queryparam(state_ids))
 
    
    category_ids=request.GET.getlist('category')     
    
    if  is_valid_queryparam(category_ids):
        Q_category=Category.objects.filter(pk__in=category_ids)
        subcategory=SubCategory.objects.filter(category__id__in=Q_category).distinct()
    else:
        subcategory=''
        Q_category='' 




    if "submit_subcat" in request.GET:
        # print("---------------------------submit_subcat clicked----",Q_category,"---------------------")
        state_ids=[]
        subcate_ids= []
        empsize_ids= []




    if   "submit_Go"  in request.GET:
        # print("--------------------------- Go clicked----",Q_category,"---------------------")
        state_ids=request.GET.getlist('state',None)
        subcate_ids=request.GET.getlist('subcategory')
        empsize_ids=request.GET.getlist('emp_size',None)
        



        
    category=Category.objects.exclude(id__in=category_ids)

    if  is_valid_queryparam(state_ids) and  is_valid_queryparam(empsize_ids) and is_valid_queryparam(subcate_ids):
        Q_state=State.objects.filter(pk__in=state_ids)
        Q_empsize=EmployeSearch.objects.filter(pk__in=empsize_ids)
        Q_subcate=SubCategory.objects.filter(pk__in=subcate_ids)
        company=Company.objects.filter(state__id__in=Q_state).distinct()
        company=company.filter(employee_size__id__in=Q_empsize).distinct()
        company=company.filter(subcategory__id__in=Q_subcate).distinct()
        # print("subcat_ids:",subcate_ids)
        # print("Subcategory query:",Q_subcate)
        # print("company:",company)
    
    elif is_valid_queryparam(state_ids) and is_valid_queryparam(subcate_ids):
        # print("----------check empsize id -----------",is_valid_queryparam(empsize_ids))
        Q_state=State.objects.filter(pk__in=state_ids)
        Q_subcate=SubCategory.objects.filter(pk__in=subcate_ids)
        company=Company.objects.filter(state__id__in=Q_state).distinct()
        company=company.filter(subcategory__id__in=Q_subcate).distinct()

    elif  is_valid_queryparam(state_ids) and  is_valid_queryparam(empsize_ids):
        Q_state=State.objects.filter(pk__in=state_ids)
        Q_empsize=EmployeSearch.objects.filter(pk__in=empsize_ids) 
        company=Company.objects.filter(state__id__in=Q_state).distinct()
        # print("company:",company)
        company=company.filter(employee_size__id__in=Q_empsize).distinct()

    elif is_valid_queryparam(subcate_ids) and  is_valid_queryparam(empsize_ids):
        Q_subcate=SubCategory.objects.filter(pk__in=subcate_ids)
        Q_empsize=EmployeSearch.objects.filter(pk__in=empsize_ids)
        company=Company.objects.filter(subcategory__id__in=Q_subcate).distinct()
        company=company.filter(employee_size__id__in=Q_empsize).distinct()

    elif  is_valid_queryparam(state_ids):
        Q_state=State.objects.filter(pk__in=state_ids)
        # print(Q_state)
        company=Company.objects.filter(state__id__in=Q_state).distinct()# filtering if any one state in Q_state associated with Company
        
    elif  is_valid_queryparam(empsize_ids) :
        Q_empsize=EmployeSearch.objects.filter(pk__in=empsize_ids)
        company=Company.objects.filter(employee_size__id__in=Q_empsize).distinct()

    elif is_valid_queryparam(subcate_ids):
        Q_subcate=SubCategory.objects.filter(pk__in=subcate_ids)
        company=Company.objects.filter(subcategory__id__in=Q_subcate).distinct()
   
    return render(request,'scraping/company.html',{'companies':company,'states':state,'categories':category,'emp_sizes':emp_size,'selectcat':Q_category,'subcategories':subcategory })

@login_required(login_url="/captain/login/")
def people(request,id):
    user=request.user
    company=Company.objects.get(pk=id)
    search_url=company.search_urls_set.all()

    Q_search_type_manager=Search_Type.objects.filter(name="manager")
    Q_manager=search_url.filter(search_type__in=Q_search_type_manager)
    manager=People.objects.filter(url__in=Q_manager)
    # print( manager)

    Q_search_type_ceo=Search_Type.objects.filter(name="ceo")
    Q_ceo=search_url.filter(search_type__in=Q_search_type_ceo)
    ceo=People.objects.filter(url__in=Q_ceo)

    Q_search_type_ctx=Search_Type.objects.filter(name="ctx")
    Q_ctx=search_url.filter(search_type__in=Q_search_type_ctx)
    ctx=People.objects.filter(url__in=Q_ctx)
    # print(Q_search_type_manager)
    

    # for m in manager:
        # print("----------------------------------------------")
        # print(m.position,"\n", m.name,"\n",m.company,"\n",m.state,"\n",m.url,"\n",m.contact_info)
        # print("----------------------------------------------")
    # for m in ceo:
    #     print("----------------------------------------------")
    #     print(m.search_type,m.name,m.company)
    #     print("----------------------------------------------")

    # for m in ctx:
    #     print("----------------------------------------------")
    #     print(m.search_type,m.name,m.company)
    #     print("----------------------------------------------")

    # print(search_url) 
    return render(request,'scraping/people.html',{'company':company,'managers':manager,'ceo_s':ceo,'ctx_s':ctx, })

    
 

     
         