from django.contrib import admin
from django.urls import path,include
 
from scraping.api import views
urlpatterns = [
 
    path('filter/',views.people_api),
    
   
]
