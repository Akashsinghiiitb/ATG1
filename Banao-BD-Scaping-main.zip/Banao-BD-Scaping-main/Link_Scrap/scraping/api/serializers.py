from rest_framework import serializers
from scraping.models import People

class PeopleSerializer(serializers.ModelSerializer):
    state = serializers.CharField()
    company = serializers.CharField(source='company.name')
    url = serializers.URLField(source='url.name')
    class Meta:
        model = People
        fields=['url','company','position','name','state','contact_info',] 
