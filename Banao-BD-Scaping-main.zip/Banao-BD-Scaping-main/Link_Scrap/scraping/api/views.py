from django.contrib.auth.models import User
from Api.models import Api
from django.http.response import HttpResponse, HttpResponseNotAllowed
from django.shortcuts import render
from rest_framework import serializers
from rest_framework.authtoken.models import Token
from rest_framework.decorators import api_view 
from rest_framework.response import Response
# from Link_Scrap.scraping.models import Search_Urls
from scraping.models import People,State,Log_t,Search_Urls
from .serializers import PeopleSerializer 
from django.conf import settings
from excel_response import ExcelResponse
import datetime 
import math
 

@api_view([ 'GET', ])
 
def people_api(request):  
    # People.objects.all().update(acessed=0) 
    current_dt=datetime.datetime.now(datetime.timezone.utc)  
    if request.method =='GET':
       
        data=request.query_params
        # print(data)
        if "state" in data:
            state=data['state']  
            state_list= state.split(',')
            # print('state  :',state )
            # print('state_list  :',state_list )
        else:
            state_list=[]
            # print('state_list  :',state_list )
        count=int(data['count']) 
        token_r=data['token']
        if "test" in data : 
            # test=data['test']
            test=True 
        else:
            test=False  

        token =Token.objects.filter(key=token_r)
        if token :
            # token =Token.objects.get(key=token_r)
            token=token[0]
            # print('token  :',token )
            users_id=token.user_id
            # print("user_id from token query :",type(users_id)) 
            #  
            api_q=Api.objects.filter(user_id=users_id)

            if state_list:
                state_q=State.objects.filter(name__in=state_list).values('id') 
            # print("state_q :",state_q)
                people_q=People.objects.filter(state__id__in=state_q)

                if not people_q:
                    return HttpResponse("<h4> No people data for current Api !  </h4>") 
            is_log=Log_t.objects.filter(user_id=users_id)
            if not is_log:
                # print("uses is not in log table")  
                # people_q=People.objects.filter(state__id__in=state_q).order_by("id")[:count]   
                if state_list: 
                    people_q=People.objects.filter(state__id__in=state_q,acessed=0).order_by("id")[:count] 
                else:
                    people_q=People.objects.filter(acessed=0).order_by("id")[:count] 


                if not people_q:
                    if state_list: 
                        new_people_q=People.objects.filter(state__id__in=state_q)
                    else:
                        new_people_q=People.objects.all()
                    # print("new_people_q : ",new_people_q)
                    for p in new_people_q:
                        p.repetition+=1
                        p.acessed = 0
                        if p.state_id==0:
                            p.state_id=None
                        p.save() 

                    if state_list: 
                        people_q=People.objects.filter(state__id__in=state_q,acessed=0).order_by("id")[:count] 
                    else:
                        people_q=People.objects.filter(acessed=0).order_by("id")[:count]   

                if test==False: 
                    log_q=Log_t.objects.create(user_id=users_id,updated=current_dt,last_used=current_dt,created=current_dt)
                    log_q.indexes.set(people_q) 
                    # print("people_q url  :" ,people_q[0].url_id)
                    for people_o in people_q:
                        people_o.acessed=1
                        url=people_o.url.name
                        if "?" in url:
                            i=url.index("?")
                            Search_Urls.objects.filter(name=url).update(name=url[:i]) 
                            people_o.url.name=url[:i]  
                        if people_o.state_id==0:
                            people_o.state_id=None 
                        people_o.save()
                    for q in api_q:
                        q.no_hits+=1
                        q.save()
                    
                   
                
                serializer =PeopleSerializer(people_q,many=True) 
                # return Response(serializer.data)
                return ExcelResponse(serializer.data)  

                
            else: 
                log_q=Log_t.objects.get(user_id=users_id)
                # print(" updated time :" ,log_q.updated)
                # print("current_dt :",current_dt)
                log_t_diff=current_dt - log_q.updated
                # print("log_t_diff :",log_t_diff)
                # print(log_t_diff.total_seconds())
                # print("diff_sec :",log_t_diff.total_seconds())
                diff_hr=(log_t_diff).total_seconds()/ 3600 
                # print("diff_hr:",diff_hr)
                if diff_hr<=24 :  
                    no_hits=api_q[0].no_hits
                    if no_hits==0 or test==True:
                        if state_list:
                            people_q=People.objects.filter(state__id__in=state_q,acessed=0).order_by("id")[:count] 
                        else:
                            people_q=People.objects.filter(acessed=0).order_by("id")[:count]


                        if not people_q:
                            if state_list:
                                new_people_q=People.objects.filter(state__id__in=state_q)
                            else:
                                new_people_q=People.objects.all() 
                            # print("new_people_q : ",new_people_q)
                            for p in new_people_q:
                                p.repetition+=1
                                p.acessed=0
                                if p.state_id==0:
                                    p.state_id=None 
                                p.save() 

                            if state_list:
                                people_q=People.objects.filter(state__id__in=state_q,acessed=0).order_by("id")[:count] 
                            else:
                                people_q=People.objects.filter(acessed=0).order_by("id")[:count]  

                        if test==False:
                            log_q.updated=current_dt
                            log_q.last_used=current_dt 
                            log_q.save()
                            log_q.indexes.set(people_q) 
                            for people_o in people_q:
                                people_o.acessed= 1 
                                url=people_o.url.name
                                if "?" in url:
                                    i=url.index("?")
                                    people_o.url.name=url[:i]
                                    Search_Urls.objects.filter(name=url).update(name=url[:i]) 
                                if people_o.state_id==0:
                                    people_o.state_id=None 
                                people_o.save()#update_fields=["url","acessed"]
                            for q in api_q:
                                q.no_hits+=1
                                q.save()
                    
                        # print(people_q)     
                        serializer =PeopleSerializer(people_q,many=True) 
                        # return Response(serializer.data)
                        return ExcelResponse(serializer.data)
                        
                    else:
                        log_q.last_used=current_dt 
                        log_q.save()
                        # print("last used" ,log_q.last_used)
                        people_q_p=log_q.indexes.all() 
                        for q in api_q:
                            q.no_hits+=1
                            q.save() 
                        serializer =PeopleSerializer(people_q_p,many=True)
                        # return Response(serializer.data)
                        return ExcelResponse(serializer.data) 
                            
                if diff_hr>24 :
                    if state_list:
                        people_q=People.objects.filter(state__id__in=state_q,acessed=0).order_by("id")[:count] 
                    else:
                        people_q=People.objects.filter(acessed=0).order_by("id")[:count]


                    if not people_q:
                        if state_list:
                            new_people_q=People.objects.filter(state__id__in=state_q)
                        else:
                            new_people_q=People.objects.all() 
                        # print("new_people_q : ",new_people_q)
                        for p in new_people_q:
                            p.repetition+=1
                            if p.state_id==0:
                                    p.state_id=None 
                            p.acessed=0
                            p.save() 

                        if state_list:
                            people_q=People.objects.filter(state__id__in=state_q,acessed=0).order_by("id")[:count] 
                        else:
                            people_q=People.objects.filter(acessed=0).order_by("id")[:count]  

                    if test==False:
                        log_q.updated=current_dt
                        log_q.last_used=current_dt 
                        log_q.save()
                        log_q.indexes.set(people_q)
                        for people_o in people_q:
                            people_o.acessed= 1
                            url=people_o.url.name
                            if "?" in url:
                                i=url.index("?")
                                Search_Urls.objects.filter(name=url).update(name=url[:i])
                                people_o.url.name=url[:i]  
                            if people_o.state_id==0:
                                people_o.state_id=None 
                            people_o.save()
                        for q in api_q:
                            q.no_hits+=1
                            q.save()
                
                    # print(people_q)     
                    serializer =PeopleSerializer(people_q,many=True)  
                    # return Response(serializer.data)
                    return ExcelResponse(serializer.data)
                
            
        else :
            return HttpResponse("<h4> Api Token is not valid ! </h4>")