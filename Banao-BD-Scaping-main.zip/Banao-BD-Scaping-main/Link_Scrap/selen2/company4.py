import requests
from time import sleep
from selenium import webdriver
import chromedriver_binary
from webdriver_manager.chrome import ChromeDriverManager

driver = webdriver.Chrome(ChromeDriverManager().install())

sleep(5)

driver.maximize_window()
sleep(5)
driver.get("https://www.linkedin.com/directory/companies")
sleep(5)

print(driver.title)
print(driver.page_source)
driver.close()