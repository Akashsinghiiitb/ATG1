import time

import requests
from time import sleep
from selenium import webdriver
import chromedriver_binary
from webdriver_manager.chrome import ChromeDriverManager
from pprint import pprint



url ='https://www.google.com/search?q=company+directory+linkedin'



driver = webdriver.Chrome(ChromeDriverManager().install())

driver.get(url)
time.sleep(2)

elems = driver.find_elements_by_xpath("//a[@href]")
hrefs=[]
for elem in elems:
    if "linkedin.com" in elem.get_attribute('href'):hrefs.append(elem)

hrefs[0].click()
sleep(5)
path_str='//*[contains(concat( " ", @class, " " ), concat( " ", "listings__entry-link", " " ))]'
elemnts=driver.find_elements_by_xpath(path_str)



'''

companies = {}
for el in elemnts:
   companies[el.text.lower()]=''
for el in elemnts:
    companies[el.text.lower()]=el

pprint(companies,indent=2,width=150)

for k,

'''

elemnts[0].click()
time.sleep(5)
employee_str ='//*[contains(concat( " ", @class, " " ), concat( " ", "base-main-card__title", " " ))]'

elements =driver.find_elements_by_xpath(employee_str)

for el in elements:
    el.click()
    time.sleep(2)
    driver.back()
    time.sleep(10)
#for e in elements:
    #print(e)
    #print(e.text)


time.sleep(10)
driver.close()