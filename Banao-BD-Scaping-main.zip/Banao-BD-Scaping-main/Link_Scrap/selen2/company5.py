import requests
from time import sleep
from selenium import webdriver
import chromedriver_binary
from webdriver_manager.chrome import ChromeDriverManager

driver = webdriver.Chrome(ChromeDriverManager().install())

sleep(5)

driver.maximize_window()
sleep(5)
driver.get("https://www.linkedin.com/")
sleep(5)

cookies_dict = {}

for cookie in driver.get_cookies():

    cookies_dict[cookie['name']]=cookie['value']

print(cookies_dict)

driver.close()

user_agents= {
            "accept" : "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
            "accept-encoding" : "gzip, deflate, sdch, br",
            "accept-language" : "en-US,en;q=0.8,ms;q=0.6",
            "user-agent" : "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36"
                    }


resp = requests.get("https://www.linkedin.com/directory/companies",cookies=cookies_dict,
                    headers=user_agents)

html = resp.text

html_path="c1.html"
with open(html_path,"w",encoding="utf-8") as f:
    f.write(html)
