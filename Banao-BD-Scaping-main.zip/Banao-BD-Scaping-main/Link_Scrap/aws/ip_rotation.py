import boto3

access_key = "AKIASDVNDJH2OF6K3ZXW"
secret_key = "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"
instance_id = "i-05fdcbadd964e9a57"

def rotate_eip(eip_allocation_id):
    client = boto3.client('ec2', region_name="ap-southeast-1",aws_access_key_id=access_key,
                                aws_secret_access_key=secret_key)
    response = client.associate_address(AllocationId=eip_allocation_id,
                                        InstanceId=instance_id)

