import csv
from datetime import datetime
from selenium.webdriver import Firefox, FirefoxOptions
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

LINK = "https://www.naukri.com/fresher-jobs"

# selectors for the small card in the search index
selectors_card = {
    "container": ".srp-jobtuple-wrapper",
    "title": ".title",  # href -> link to job's page
    "company": ".comp-name",
    "experience": ".exp span",
    "salary": ".sal",
    "location": ".loc",
    "tags": ".tags-gt",  # 1 per li in .tags-gt
    "when": ".job-post-day",
    "breadcrumb": "#lastCompMark",
}

# selectors for a particular job's page
selectors_job = {
    "otherdetails": ".styles_other-details__oEN4O",  # "Role", "Employment Type"
    "education": ".styles_education__KXFkO",  # "UG", "PG"
    "item": ".styles_details__Y424J",
    "breadcrumb": ".styles_breadcrumb__1emXD",
}


class Job:
    link: str = None  # link to job's main page
    title: str = None  # job title
    company: str = None
    experience: str = None  # in years
    salary: str = None  # salary *range*
    location: str = None
    tags: list[str] = []
    when: str = None

    role: str = None
    employment_type: str = None
    education_UG: str = None
    education_PG: str = None


def get_job_details_from_card(card: WebElement) -> dict:
    # pretty straightforward
    # all information is scraped from a given "card"
    job = Job()

    title = card.find_element(By.CSS_SELECTOR, selectors_card["title"])

    print(f"scraping basic details for {title.text}")

    job.link = title.get_attribute("href")
    job.title = title.text

    job.company = card.find_element(By.CSS_SELECTOR, selectors_card["company"]).text

    job.experience = card.find_element(
        By.CSS_SELECTOR, selectors_card["experience"]
    ).text

    job.salary = card.find_element(By.CSS_SELECTOR, selectors_card["salary"]).text

    job.location = card.find_element(By.CSS_SELECTOR, selectors_card["location"]).text

    tags_elements = card.find_elements(By.CSS_SELECTOR, selectors_card["tags"])
    job.tags = [tag.text for tag in tags_elements]

    job.when = card.find_element(By.CSS_SELECTOR, selectors_card["when"]).text

    print(f"scraping done for {title.text}")

    return job


# scrapes details from the job's page itself
def get_more_job_details(job: Job, job_page: WebElement) -> dict:
    """
    generic overview:
    for every element in a block of elements:
        if element.<label> is not UG or PG (for example):
            do nothing
        else modify job
    """
    print(f"scraping in depth for {job.title}")

    other_details_elements = job_page.find_element(
        By.CSS_SELECTOR, selectors_job["otherdetails"]
    ).find_elements(By.CSS_SELECTOR, selectors_job["item"])

    for element in other_details_elements:
        label = element.find_element(By.CSS_SELECTOR, "label").text
        if label not in ["Role:", "Employment Type:"]:
            continue
        detail = element.find_element(By.CSS_SELECTOR, "span").text
        # not the cleanest trick but yeah
        setattr(job, label[:-1].lower().replace(" ", "_"), detail)

    education_elements = job_page.find_element(
        By.CSS_SELECTOR, selectors_job["education"]
    ).find_elements(By.CSS_SELECTOR, selectors_job["item"])

    for element in education_elements:
        label = element.find_element(By.CSS_SELECTOR, "label").text.strip()
        if label not in ["UG:", "PG:"]:
            continue
        detail = element.find_element(By.CSS_SELECTOR, "span").text.strip()
        setattr(job, f"education_{label[:-1].upper()}", detail)

    print(f"finished scraping in depth for {job.title}")

    return job


def save_jobs_to_csv(jobs):
    timestamp = datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
    outpath = f"job.details.{timestamp}.csv"
    with open(outpath, mode="w", newline="", encoding="utf-8") as csv_file:
        csv_writer = csv.writer(csv_file)

        header_row = [
            "Title",
            "Company",
            "Experience",
            "Salary",
            "Location",
            "Tags",
            "When",
            "Role",
            "Employment Type",
            "UG",
            "PG",
        ]
        csv_writer.writerow(header_row)

        for job in jobs:
            row = [
                job.title,
                job.company,
                job.experience,
                job.salary,
                job.location,
                ", ".join(job.tags),  # TODO better way to store tags?
                job.when,
                job.role,
                job.employment_type,
                job.education_UG,
                job.education_PG,
            ]
            csv_writer.writerow(row)

    print(f"Job details have been saved to {outpath}")


# for scraping one page
def scrape_single_search_page(link, driver):
    jobs: list[Job] = []
    driver.get(link)

    WebDriverWait(driver, 5).until(
        EC.presence_of_element_located((By.CSS_SELECTOR, selectors_card["breadcrumb"]))
    )
    cards = driver.find_elements(By.CSS_SELECTOR, selectors_card["container"])

    # first append all the jobs to the array
    for card in cards:
        job = get_job_details_from_card(card)
        jobs.append(job)

    # now for every job, scrape job.link and append back to job
    # deliberately using indexed iterations since changes are made
    for i in range(len(jobs)):
        driver.get(jobs[i].link)
        # this is to make sure that our content is surely loaded
        try:
            WebDriverWait(driver, 5).until(
                EC.presence_of_element_located(
                    (By.CSS_SELECTOR, selectors_job["breadcrumb"])
                )
            )
        except Exception as e:
            print(f"exception handling {jobs[i].title}")
            continue
        jobs[i] = get_more_job_details(jobs[i], driver)

    return jobs


if __name__ == "__main__":
    jobs: list[Job] = []

    # replace firefox if needed
    options = FirefoxOptions()
    # deliberately commented out for now
    # options.add_argument("-headless")
    driver = Firefox(options=options)

    for i in range(1, 11):
        job_list = scrape_single_search_page(f"{LINK}-{i}", driver)
        jobs += [job for job in job_list if job is not None]

    driver.quit()

    save_jobs_to_csv(jobs)
