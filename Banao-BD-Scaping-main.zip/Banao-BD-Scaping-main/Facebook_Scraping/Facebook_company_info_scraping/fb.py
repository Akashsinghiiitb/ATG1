from selenium import webdriver
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from bs4 import BeautifulSoup
import datetime
import time  
import re

# chrome_options = webdriver.ChromeOptions()
# prefs = {"profile.default_content_setting_values.notifications" : 2}
# chrome_options.add_experimental_option("prefs",prefs)
browser =webdriver.Chrome("C:/Users/Hp/Downloads/chromedriver.exe")

# browser =webdriver.Firefox(executable_path=r"C:/Users/Hp/Downloads/geckodriver.exe") 

def about_details(search_key):
    browser.get(f"https://www.facebook.com/public?query={search_key}&type=pages&init=dir&nomc=0") 
    reaction=WebDriverWait(browser, 10).until(EC.presence_of_element_located((By.ID, 'BrowseResultsContainer'))) 
    link=WebDriverWait(reaction, 10).until(EC.presence_of_element_located((By.CSS_SELECTOR, 'a')))
    search_link=link.get_attribute("href")     # first link of search query 

    browser.find_element_by_tag_name('body').send_keys(Keys.COMMAND + 't') # change tab as about is not loaded in same tab
    time.sleep(2)
    browser.get(search_link)
    try :
        about=WebDriverWait(browser, 10).until(EC.presence_of_element_located((By.CLASS_NAME, '_u9q'))) 
    except:
        browser.find_element_by_tag_name('body').send_keys(Keys.COMMAND + 't') # if non fiind element again change tab
        browser.get(search_link)
        about=WebDriverWait(browser, 10).until(EC.presence_of_element_located((By.CLASS_NAME, '_u9q'))) 
    about=about.text
    

    """ Extract Email """
    # about=about.text # for testing remove when running this function
    email = re.findall(r'([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9_-]+)',about)
    if email:
        email=email
    else:
        email = [] 


    """ Extract Phone """
    phone=re.findall(r'\d{4,5}\s\d{4,5}',about)
    phone
    if phone:
            phone=phone
    else:
        phone = []

    about=about.split("\n")

     
    # print(about)
    for a in about: 
        n_about='https://'+a

        """ Extract website """

        website = re.findall(r'(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})',n_about) 

        if website:
            website=website
            break
        else:
            website =  [] 



    """ Extract location """

    try:# //*[contains(concat( " ", @class, " " ), concat( " ", "_2wzd", " " ))]
        # Location_path=WebDriverWait(browser, 10).until(EC.presence_of_element_located((By.XPATH, '/html/body/div[1]/div[3]/div[1]/div/div/div[2]/div[2]/div/div[3]/div[1]/div/div/div[1]/div/div/div[1]/div/div[2]/div[2]/div/div[2]/div')))
        Location_path=WebDriverWait(browser, 10).until(EC.presence_of_element_located((By.XPATH, '/html/body/div[1]/div[3]/div[1]/div/div/div[2]/div[2]/div/div[3]/div[1]/div/div/div[1]/div/div/div[2]/div/div[2]/div[3]/div/div[2]/div[1]')))
        
        location=Location_path.text
        print(location,": location")
    except:

        try:
            Location_path=WebDriverWait(browser, 10).until(EC.presence_of_element_located((By.XPATH, '/html/body/div[1]/div[3]/div[1]/div/div/div[2]/div[2]/div/div[3]/div[1]/div/div/div[1]/div/div/div[1]/div/div[2]/div[2]/div/div[2]/div')))
            location=Location_path.text
            print(location,": location")

        except:
        
            location=""




    """ Extract domain """

    domain_path=WebDriverWait(browser, 10).until(EC.presence_of_element_located((By.XPATH, '//*[contains(concat( " ", @class, " " ), concat( " ", "_4bl7", " " ))]//a'))) 
    domain= domain_path.text

    """ Extract Followers """
    try:
        followers_ele=WebDriverWait(browser, 10).until(EC.presence_of_all_elements_located((By.CLASS_NAME, '_4bl9')))
        for f in followers_ele:
            follower=f.text
            if 'people follow this' in follower:
                    followers=follower
                    break
        follower=int(followers[:-19].replace(',',''))
    except:
        follower=0

   
        
    browser.execute_script("window.scrollTo(0, 3000)")   # scroll for loading posts
    time.sleep(2) 
    time.sleep(2) 
     

    soup=BeautifulSoup(browser.page_source,features="lxml")
    soup=BeautifulSoup(browser.page_source,features="lxml")
    
    html=soup.prettify()  
    file=open("myfile.text","w",encoding="utf-8")
    file.write(html)
    post=soup.find_all("div", class_="_5va1 _427x")
     
    pinned_post=soup.find(attrs={"data-tooltip-content": "Pinned Post"})
 
    if pinned_post: # 
        post=post[1]
    else:
        post=post[0] 
    post_list=[text for text in post.stripped_strings]
    # print(post_list)
    print("---------------------------------------------------------------------")
    print("---------------------------------------------------------------------")
    last_posted = post_list[1]
        
    date_y=re.findall(r'[a-zA-Z]{3,9} [0-9]{2}, [0-9]{4}',last_posted)
    
    todays_date=datetime.datetime.now()

    if date_y:
        last_posted=last_posted

    else:   

        if  'day'in last_posted and not 'Yesterday'in last_posted  :
            # Last_posted=last_posted.rstrip(last_posted[-1])
            i=last_posted.index(" ")
            days_ago=int(last_posted[:i])
            last_posted = todays_date - datetime.timedelta(days=days_ago) 
            last_posted=last_posted.strftime("%B %d, %Y")

        if 'Yesterday' in last_posted :
            last_posted = todays_date - datetime.timedelta(days=1)
            last_posted=last_posted.strftime("%B %d, %Y")

        
        elif 'hr' in last_posted :
            # Last_posted=last_posted.rstrip('hrs')
            i=last_posted.index(" ")
            hr_ago=int(last_posted[:i])
            last_posted =todays_date - datetime.timedelta(hours = hr_ago)
            last_posted=last_posted.strftime("%B %d, %Y") 
    
        elif 'min' in last_posted:
            last_posted=todays_date
            last_posted=last_posted.strftime("%B %d, %Y")   #re.findall(r'\d{4,5}\s\d{4,5}',info)

        else :
            last_posted= last_posted + ", " + str(todays_date.year)
    comments=0
    shares=0
    for x in post_list:
        if "comment" in x:
            comments=x

            c_i=comments.index(' ')         
            comments=comments[:c_i]
            if comments[-1]=='K':
                if '.' in comments:
                    comments=int(float(comments[:-1])*1000)
                else:
                    comments=int(comments[:-1])*1000
            else :
                comments=int(comments)
                
        if "share" in x:
            shares=x

            s_i=shares.index(' ') 
            shares=shares[:s_i]
            if shares[-1]=='K':
                if '.' in shares:
                    shares=float(shares[:-1])*1000
                else:
                    shares=int(shares[:-1])*1000
            else :
                shares=int(shares)

  


    detail_dict={"email":email,"website":website, "phone":phone, "location ":location,"domain":domain,"followers":follower,"last_posted ":last_posted,"Comments":comments,"Shares ":shares}


    return detail_dict
    browser.close()


search_key="Planet Organic India"#Planet Organic India

details=about_details(search_key)
print(details)




 