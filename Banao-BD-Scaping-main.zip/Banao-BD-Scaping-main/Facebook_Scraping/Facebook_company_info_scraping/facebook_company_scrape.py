from selenium import webdriver
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import datetime
import time  
import re

chrome_options = webdriver.ChromeOptions()
prefs = {"profile.default_content_setting_values.notifications" : 2}
chrome_options.add_experimental_option("prefs",prefs)
# browser =webdriver.Chrome("C:/Users/Hp/Downloads/chromedriver_win32/chromedriver.exe",options=chrome_options)

browser =webdriver.Firefox(executable_path=r"C:/Users/Hp/Downloads/geckodriver.exe")

browser.get("https://en-gb.facebook.com/")
browser.maximize_window()
username = WebDriverWait(browser, 10).until(EC.presence_of_element_located((By.ID, "email")))
password = WebDriverWait(browser, 10).until(EC.presence_of_element_located((By.ID, "pass")))
username.send_keys('7248931939')
password.send_keys('')
browser.find_element_by_xpath("//button[@type='submit']").click()
time.sleep(1)

def search_comp(Search_Key):


    url=browser.current_url 
    url=url+"search/pages/?q="+Search_Key    # search pass on url
    browser.get(url)



    # search=browser.find_element_by_xpath("//input[@type='search']")
    # time.sleep(1)
    # search.send_keys(Search_Key)#  sending company to search
    # time.sleep(1)
    # # search.send_keys(Keys.ENTER)     
  
    # all_a=WebDriverWait(browser, 10).until(EC.presence_of_all_elements_located((By.CSS_SELECTOR,"a")))
    # for a in all_a :
    #     # print(a.text)
    #     if 'Search for' in a.text :
    #         a.click()  #click search for to search
    #         break
    # time.sleep(1)
    # all_a=WebDriverWait(browser, 10).until(EC.presence_of_all_elements_located((By.XPATH,"//div[@class='rq0escxv l9j0dhe7 du4w35lb j83agx80 cbu4d94t pfnyh3mw d2edcug0 aahdfvyu tvmbv18p']//div[@data-visualcompletion='ignore-dynamic']//a")))
    # # all_a=browser.find_elements_by_xpath("//div[@class='rq0escxv l9j0dhe7 du4w35lb j83agx80 cbu4d94t pfnyh3mw d2edcug0 aahdfvyu tvmbv18p']//div[@data-visualcompletion='ignore-dynamic']//a")
    # for a in all_a:
    #     # print(a.text)
    #     if a.text=='Pages':
    #         a.click()    #click link for pages
    #         break
                        
    time.sleep(2) 
    title=WebDriverWait(browser, 10).until(EC.presence_of_element_located((By.XPATH,"//div[@class='sjgh65i0']//a")))
       
    time.sleep(1)
    title.click()  #click first link for searched company(link index for first link may need to change ) 

    company_detail=comp_detail()  #run for scraping about in company
    posts_detail=post_detail()    #run for scraping post comment,share and comment
    Merge(posts_detail,company_detail)
    print("--------------------------------------------------------------------------------------------")
    print(company_detail)
    print("--------------------------------------------------------------------------------------------") 

##########################################################################################################
def comp_detail(): 
    time.sleep(2)  
    url=browser.current_url
    if url[-1]=="/":
        url+='about'
    else:
        url+='/about'
    browser.get(url)  #go to about url
    time.sleep(2)  
    followers=WebDriverWait(browser, 10).until(EC.presence_of_all_elements_located((By.XPATH,"//div[@class='je60u5p8']//div[@class='taijpn5t cbu4d94t j83agx80']")))
    for f in followers:
        follower=f.text
        if 'people follow this' in follower:
            followers=follower
            break
  
    domain=WebDriverWait(browser, 10).until(EC.presence_of_element_located((By.XPATH,"//div[@class='je60u5p8']//div[@class='j83agx80']")))
    domain=domain.text
    time.sleep(1)
    info=browser.find_elements_by_xpath("//div[@class='je60u5p8']")
   

    for inf in info:
        info=inf.text
        # info=info.upper()
        # print(info)
        if "ADDITIONAL CONTACT INFO" in info.upper():
            email = re.findall(r'([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9_-]+)',info)
            if email:
                email=email
            else:
                email = []
         
            
            website = re.findall(r'(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})',info)
            if website:
                website=website
            else:
                website =  []
      
    
            phone=re.findall(r'\d{4,5}\s\d{4,5}',info)
            phone
            if phone:
                 phone=phone
            else:
                phone = []
                 
    try:
        location=WebDriverWait(browser, 10).until(EC.presence_of_element_located((By.XPATH,"//div[@class='rq0escxv l9j0dhe7 du4w35lb j83agx80 pfnyh3mw jifvfom9 ll8tlv6m owycx6da btwxx1t3 hv4rvrfc dati1w0a jb3vyjys b5q2rw42 lq239pai mysgfdmx hddg9phg']//span[@class='a8c37x1j ni8dbmo4 stjgntxs l9j0dhe7']"))) 
        location=location.text
 
    except:
        location =''
    url=browser.current_url 
    url=url.replace('about','?ref=page_internal')
    browser.get(url)    # go to home page
    follower=int(followers[:-19].replace(',',''))
    company_detail={'Domain':domain,'Website':website,'Email':email,'Phone_No':phone,'Location':location,'Follower':follower}
    return company_detail 
##########################################################################################################
def post_detail():
  
    time.sleep(1)
    daten=WebDriverWait(browser, 10).until(EC.presence_of_all_elements_located((By.XPATH,"//div[@class='du4w35lb k4urcfbm l9j0dhe7 sjgh65i0']//a[@class='oajrlxb2 g5ia77u1 qu0x051f esr5mh6w e9989ue4 r7d6kgcz rq0escxv nhd2j8a9 nc684nl6 p7hjln8o kvgmc6g5 cxmmr5t8 oygrvhab hcukyx3x jb3vyjys rz4wbd8a qt6c0cv9 a8nywdso i1ao9s8h esuyzwwr f1sip0of lzcic4wl gmql0nx0 gpro0wi8 b1v8xokw']")))
    time.sleep(1)
    reacts=WebDriverWait(browser, 10).until(EC.presence_of_all_elements_located((By.CSS_SELECTOR,"[class='bp9cbjyn j83agx80 pfnyh3mw p1ueia1e']")))
    
    try:
        pin=WebDriverWait(browser, 10).until(EC.presence_of_element_located((By.XPATH,"//div[@class='f10w8fjw ocgrx2df tmqn73lw']")))
        # pinned=pin.text
        # print("------------------------",pinned,"---------------------------")      
        post_on=daten[1].get_attribute('aria-label')
        reaction=WebDriverWait(reacts[1], 10).until(EC.presence_of_all_elements_located((By.CSS_SELECTOR,"[class='gtad4xkn']"))) 

        
    except:
        post_on=daten[0].get_attribute('aria-label') 
        
    date_y=re.findall(r'[a-zA-Z]{3,9} [0-9]{2}, [0-9]{4}',post_on)
    
    todays_date=datetime.datetime.now()

    if date_y:
        post_on=post_on

    else:     
        if  post_on[-1]=='d' :
            Last_posted=post_on.rstrip(post_on[-1])
            days_ago=int(Last_posted)
            post_on = todays_date - datetime.timedelta(days=days_ago) 
            post_on=post_on.strftime("%B %d, %Y")

        elif post_on[-1]=='h' :
            Last_posted=post_on.rstrip(post_on[-1])
            hr_ago=int(Last_posted)
            post_on =todays_date - datetime.timedelta(hours = hr_ago)
            post_on=post_on.strftime("%B %d, %Y") 
    
        elif post_on[-1]=='m':
            post_on=todays_date
            post_on=post_on.strftime("%B %d, %Y")   #re.findall(r'\d{4,5}\s\d{4,5}',info)
        
        elif 'Yesterday' in post_on:
            post_on = todays_date - datetime.timedelta(days=1)
            post_on=post_on.strftime("%B %d, %Y")

        else :
            post_on= post_on + ", " + str(todays_date.year)


    try:          
        reaction=WebDriverWait(reacts[0], 10).until(EC.presence_of_all_elements_located((By.CSS_SELECTOR,"[class='gtad4xkn']"))) 
        reaction_text=reacts[0].text
        # print("reaction_text :",reaction_text)
        if not reaction_text:
            comments='0 Comment'
            shares='0 Share'

        time.sleep(1)
        # print(reaction)
        reaction=reaction_text.split("\n")
        print(reaction)
        if len(reaction)==2:    
            comments=reaction[0]
            # print(reaction[0].text)
            shares=reaction[1]
            # print(reaction[1].text)
            # print("if block")
        else:
            # print("else block")
            reaction=reaction[0]
            if 'Comment' in reaction:
                print("if if  block")
                comments=reaction
                # print("comment is 0")
                shares='0 Share'
            else:
                # print("else else block")
                shares=reaction
                comments='0 Comment'
    except:
        # print("except block")
        comments='0 Comment'
        shares='0 Share'
   
    c_i=comments.index(' ')         
    comments=comments[:c_i]
    if comments[-1]=='K':
        if '.' in comments:
            comments=int(float(comments[:-1])*1000)
        else:
            comments=int(comments[:-1])*1000
    else :
        comments=int(comments)

    s_i=shares.index(' ') 
    shares=shares[:s_i]
    if shares[-1]=='K':
        if '.' in shares:
            shares=float(shares[:-1])*1000
        else:
            shares=int(shares[:-1])*1000
    else :
        shares=int(shares)

    posts_detail={"Comments":comments,"Shares":shares,"Last_Posted":post_on}
    browser.close()
    # print(posts_detail)
    return posts_detail
###########################################################################################################
def Merge(posts_detail, company_detail):
    merge=company_detail.update(posts_detail)
    return merge

search_comp('amazon.ca')#Planet Organic India
# company_detail=comp_detail()
# posts_detail=post_detail() 
# Merge(posts_detail,company_detail)
# print("--------------------------------------------------------------------------------------------")
# print(company_detail)
# print("--------------------------------------------------------------------------------------------") 



 
 