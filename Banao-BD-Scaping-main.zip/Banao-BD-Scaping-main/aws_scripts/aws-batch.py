import boto3

client = boto3.client('batch', region_name='us-west-1', aws_access_key_id="AKIASDVNDJH2JL6ODCMQ",aws_secret_access_key="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")

qs = client.describe_job_queues()

print(qs.keys())
print(len(qs['jobQueues']))
jqs = qs['jobQueues']

active_qs = []
inactive_qs = []
ces = []

RUNNABLE = []
PENDING = []
SUCCEEDED = []
RUNNING = []
STARTING = []
SUBMITTED = []

for q in jqs:
    if q['state'] == 'DISABLED':
        inactive_qs.append(q['jobQueueArn'])
    else:
        active_qs.append(q['jobQueueArn'])
        
    for ce in q['computeEnvironmentOrder']:
        ces.append(ce['computeEnvironment'])
        
print(f"active: {len(active_qs)} || inactive: {len(inactive_qs)}")
     
def get_jobs():
    for q in inactive_qs + active_qs:
        jobs = client.list_jobs(jobQueue=q, jobStatus='RUNNABLE', maxResults=1000)
        for job in jobs['jobSummaryList']:
            RUNNABLE.append(job['jobId'])

def terminate_runnnable_jobs():
    get_jobs()
    for job in RUNNABLE:
        client.terminate_job(jobId=job, reason="terminated by program")
    
def activate():
    for q in inactive_qs:
        client.update_job_queue(jobQueue=q, state='ENABLED')
        
def activate_ces():
    for ce in ces:
        client.update_compute_environment(computeEnvironment=ce, state='ENABLED')

def deactivate_ces():
    for ce in ces:
        client.update_compute_environment(computeEnvironment=ce, state='DISABLED')
        
def deactivate():
    for q in active_qs:
        client.update_job_queue(jobQueue=q, state='DISABLED')
        
deactivate()
deactivate_ces()
# terminate_runnnable_jobs()
# activate_ces()
# activate()

# print(jqs[0])