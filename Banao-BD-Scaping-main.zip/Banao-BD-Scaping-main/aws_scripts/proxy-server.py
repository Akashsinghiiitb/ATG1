import socket
import threading


def handle_client(client_socket, client_address):
    request = client_socket.recv(1024)
    destination_host = request.split(b'\n')[1].split(b' ')[1].strip()
    # get_domain(request)
    destination_port = 443

    print(destination_host)
    destination_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    destination_socket.connect((destination_host, destination_port))
    destination_socket.sendall(request)

    response = destination_socket.recv(4096)
    client_socket.sendall(response)
    print('done')

    destination_socket.close()
    client_socket.close()

def start_server():
    proxy_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    proxy_socket.bind(('127.0.0.1', 8889))
    proxy_socket.listen(10)
    print('started')
    i = 0
    while True:
        print(i)
        client_socket, client_address = proxy_socket.accept()
        threading.Thread(target=handle_client, args=(client_socket, client_address)).start()
        i += 1

if __name__ == '__main__':
    start_server()
