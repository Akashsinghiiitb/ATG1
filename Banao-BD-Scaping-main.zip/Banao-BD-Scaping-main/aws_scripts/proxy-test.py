import requests

http_proxy  = "http://127.0.0.1:8889"
https_proxy = "https://10.10.1.11:1080"
ftp_proxy   = "ftp://10.10.1.10:3128"

proxies = { 
              "http"  : http_proxy, 
            }

r = requests.get("http://bbd.atg.party/userStatsDash/", proxies=proxies)
print(r.text)