import scrapy 
class Category(scrapy.Spider):

    name = "category"



    start_urls =['https://www.careerguide.com/career-options']



    def parse(self, response, **kwargs):

        str1='//*[contains(concat( " ", @class, " " ), concat( " ", "col-md-4", " " ))]//a'
        str2='//*[contains(concat( " ", @class, " " ), concat( " ", "col-md-4", " " ))]//a'

        el = response.xpath(str2)
        i=0
        categories=[]
        subcategories=[]
        for x in el:
            sub_cat=x.css('a::attr("title")').extract()[0].lower()
            cat=x.css("a::attr('href')").extract()[0].split('/')[2]
            cat=cat.split('-')
            cat = " ".join(cat).lower()
            if cat in ["institutes in india","exams and syllabus","www.careerguide.com","study abroad"]:
                pass
            else:
                categories.append(cat)
                subcategories.append(sub_cat)

        yield {'category':categories,"sub_category":subcategories}