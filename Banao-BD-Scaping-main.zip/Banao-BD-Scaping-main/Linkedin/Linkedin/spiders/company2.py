import scrapy
from scrapy import FormRequest


class Comp(scrapy.Spider):


    name="company2"

    start_urls=['https://www.linkedin.com/jobs/search/?geoId=&keywords=software&location=delhi%20india&start=0']

    def parse(self, response, **kwargs):

        str2='//*[contains(concat( " ", @class, " " ), concat( " ", "relative", " " )) and contains(concat( " ", @class, " " ), concat( " ", "ember-view", " " ))] | //*[contains(concat( " ", @class, " " ), concat( " ", "job-card-container__company-name", " " ))] | //*[contains(concat( " ", @class, " " ), concat( " ", "job-card-list__title", " " ))]'
        str3='//*[contains(concat( " ", @class, " " ), concat( " ", "relative", " " )) and contains(concat( " ", @class, " " ), concat( " ", "ember-view", " " ))] | //*[contains(concat( " ", @class, " " ), concat( " ", "job-card-list__title", " " ))]'
        elements = response.xpath(str3)
        print(elements)
        for e in elements:
            print(e.extract())
