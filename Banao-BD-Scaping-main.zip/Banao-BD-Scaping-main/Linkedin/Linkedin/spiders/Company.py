import scrapy
from scrapy import FormRequest
from pprint import pprint
import os


class Company(scrapy.Spider):

    name= "company"
    #allowed_domains = ["linkedin.com"]
    #user_name = 'timeisgod12@gmail.com'
    #passwd = 'Srsscthr#1'





    def __init__(self,state,category):
        super(Company, self).__init__()
        m = self.web_format(state.lower())
        c = self.web_format(category.lower())
        self.state=state
        print(os.getcwd())
        if os.path.exists(f"data/jobs_{self.state}.csv"):
            os.system(f"rm -rf data/jobs_{self.state}.csv")

        self.category=category






        self.start_urls=[f"https://www.linkedin.com/jobs/search/?geoId=&keywords={c}&location={m}%20india&start={i}" for i in range(0,200,25)]








    def parse(self, response, **kwargs):
        print(response.css('title'))
        str=' //*[contains(concat( " ", @class, " " ), concat( " ", "base-search-card__title", " " ))] | //*[contains(concat( " ", @class, " " ), concat( " ", "hidden-nested-link", " " ))]'
        elements = response.xpath(str)

        str2='//*[contains(concat( " ", @class, " " ), concat( " ", "job-card-list--underline-title-on-hover", " " ))]//*[(((count(preceding-sibling::*) + 1) = 1) and parent::*)]'
        elements2=response.xpath(str2)
        i=0
        dict1={}
        dict1['post']=[]
        dict1['company']=[]
        dict1['url']=[]
        dict1['category']=[]
        for e in elements:
            i+=1
            post = e.css('h3::text').extract()
            url = e.css('a::attr(href)').extract()
            comp = e.css('a::text').extract()

            post = post[0].replace('\n','').lstrip().rstrip() if len(post)!=0 else None
            comp=comp[0].replace('\n','').lstrip().rstrip() if len(comp)!=0 else None
            url = url[0] if len(url)!=0 else None
            #post.replace('\n','')
            #comp.replace('\n','')

            if comp is not None:
                dict1['post'].append(post)
                dict1['url'].append(url)
                dict1['company'].append(comp)
                dict1['category'].append(self.category)
                #yield {"post":post,"url":url,"comp":comp}

        yield dict1


    def web_format(self,str1):
        str1=str1.split()

        return '%20'.join(str1)