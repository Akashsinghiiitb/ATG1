# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
import pandas as pd


class LinkedinPipeline:
    def process_item(self, item, spider):

        if spider.name == "category":
            data = pd.DataFrame(data=item)
            data.to_csv("data/category.csv")

        if spider.name == 'company':
            data = pd.DataFrame(data=item)
            data.to_csv(f'data/jobs_{spider.state}.csv',mode='a',header=False)

        return item
