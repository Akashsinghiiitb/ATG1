import time
import linkedin_api as lp
import json
import os
from log_generator import generate_log
from datetime import date, datetime

# Log file name
current_date = date.today()
current_time = datetime.now().strftime("%H:%M").replace(":", ",")
LOG_FILE = f"{current_time} {current_date} linkedin_scrape"

def do_log(*message):
    output_data = ''
    for i in message:
        output_data += f"{i} "
    print(output_data)
    generate_log(output_data, LOG_FILE)


while True:
    try:
        user = input("email > ")
        password = input("password > ")
        api = lp.Linkedin(user,password)
        break
    except Exception as e:
        do_log("error logging in ")
        time.sleep(2) 
        os.system('cls')
        
#Get current user details 
profile = api.get_user_profile()
with open('profile_info.json','w') as f:
    json.dump(profile,f,indent=4)
profile_urn = profile['miniProfile']['entityUrn'].split(':')[-  1]
#Enter the messages urn_id here instead of 2-MW.... 
data = api.get_conversation('2-MWZkNmFkZWEtYjExMS00OWEyLWEwNDUtZTY0YWEwZmI2ZjM2XzAxMg==')
messages = []
public_identifier = profile["miniProfile"]["publicIdentifier"]

do_log("Public Identifier:", public_identifier)
do_log(data)
# Extract necessary information from the JSON data
for element in data['elements']:
    sender = element['from']['com.linkedin.voyager.messaging.MessagingMember']['nameInitials']
    receiver = ''
    for participant in data['metadata']['participants']:
        if participant != sender:
            receiver = participant
            break
    message = element['eventContent']['com.linkedin.voyager.messaging.event.MessageEvent']['attributedBody']['text']
    
    # Add formatted message to the list
    messages.append(f"Sender: {sender}\nReceiver: {receiver}\nMessage: {message}\n")

# Print the formatted list of messages
for message in messages:
    do_log(message)

do_log("\n\nConnections:\n",api.get_profile_network_info(public_identifier))